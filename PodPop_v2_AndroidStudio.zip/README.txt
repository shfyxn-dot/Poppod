PodPop v4 Premium

The popup now uses the supplied pro2.png reference artwork bundled in
app/src/main/res/drawable-nodpi. It does not download anything at runtime.
The GitHub Actions workflow first attempts to fetch pro2.png from the MAIN
branch and falls back to the bundled image when the remote file is unavailable.

Build locally:
1. Open this project folder in Android Studio.
2. Allow Gradle sync (JDK 17; Android Gradle Plugin 8.7.3; Gradle 8.9).
3. Build > Build Bundle(s) / APK(s) > Build APK(s), or run:
   gradle --no-daemon assembleDebug
4. APK output: app/build/outputs/apk/debug/app-debug.apk

Setup on device:
- Grant Bluetooth access (Android 12+).
- Allow PodPop to display over other apps.
- Start PodPop from the app.
- Test popup now checks the configured device's active A2DP/Headset profile
  connected-device lists; pairing by itself is not considered connected.

Notes:
- Configured Bluetooth address is retained: 41:42:84:7B:08:D6.
- Android does not expose charging-case battery consistently; unavailable
  readings are shown as an empty battery outline/dash.
- Popup timeout is configured by MonitorService.POPUP_TIMEOUT_MS (3 seconds).
- The bundled PNG has an opaque graphite background as in the supplied image.
