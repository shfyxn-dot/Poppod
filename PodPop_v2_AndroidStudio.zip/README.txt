PodPop v2 source project

Install/build:
1. Install Android Studio on a computer.
2. Open this extracted folder as a project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Transfer app/build/outputs/apk/debug/app-debug.apk to your vivo Y16 and install.
6. Open PodPop. Allow "Display over other apps", allow Bluetooth access, tap Start PodPop.

The app filters to Bluetooth address 41:42:84:7B:08:D6 from your screenshot.
It listens while the foreground service is running. Android may stop it due to battery management;
set PodPop battery use to Unrestricted / allow background activity if your Funtouch OS offers that setting.

Battery limitation:
Only a battery level Android broadcasts for this Bluetooth device can be shown. This app cannot
read the case battery unless the clone exposes it. A 3D-like original illustration rotates; it is
not Apple's original proprietary animation or asset. It displays a single reported battery level,
not separate left/right/case values unless the clone reports them separately.

This is a source project, not a prebuilt APK.
