PodPop v2.1 - builds an APK automatically on GitHub (no computer needed).
Push to GitHub -> Actions tab -> "Build PodPop APK" -> Releases page has app-debug.apk.
Filters to Bluetooth address 41:42:84:7B:08:D6. Shows only battery values Android reports;
the case battery is never guessed.
