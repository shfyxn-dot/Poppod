package com.example.podpop

import android.app.*
import android.bluetooth.BluetoothDevice
import android.content.*
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.RemoteViews

class MonitorService : Service() {
    private var receiver: BroadcastReceiver? = null
    override fun onCreate() {
        super.onCreate()
        val channel = "podpop_monitor"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "PodPop connection monitor", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = Notification.Builder(this, channel)
            .setContentTitle("PodPop is active")
            .setContentText("Watching for your Pro2 earbuds")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true).build()
        startForeground(42, notification)

        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val device = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else @Suppress("DEPRECATION") (intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE))
                val address = try { device?.address } catch (_: SecurityException) { null }
                if (!address.equals(TARGET_MAC, ignoreCase = true)) return
                when (intent.action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> showPopup(-1)
                    BluetoothDevice.ACTION_BATTERY_LEVEL_CHANGED -> {
                        val level = intent.getIntExtra(BluetoothDevice.EXTRA_BATTERY_LEVEL, -1)
                        showPopup(level)
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothDevice.ACTION_BATTERY_LEVEL_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
    }

    private fun showPopup(level: Int) {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val popup = PodPopupView(this, level)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.90f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (28 * resources.displayMetrics.density).toInt() }
        try {
            wm.addView(popup, params)
            popup.postDelayed({ try { wm.removeView(popup) } catch (_: Exception) {} }, 5000)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        receiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val TARGET_MAC = "41:42:84:7B:08:D6" }
}
