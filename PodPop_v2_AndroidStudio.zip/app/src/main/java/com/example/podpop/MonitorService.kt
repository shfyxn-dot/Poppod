package com.example.podpop

import android.app.*
import android.bluetooth.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var receiver: BroadcastReceiver? = null
    private var popup: PodPopupView? = null
    private val hideRunnable = Runnable { hidePopup() }
    private var currentBattery = -1

    override fun onCreate() {
        super.onCreate()
        val channel = "podpop_monitor"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channel, "PodPop connection monitor", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setContentTitle("PodPop is active").setContentText("Watching for your Pro2 earbuds")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setOngoing(true).build()
        startForeground(42, notification)

        val r = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == Intent.ACTION_CONFIGURATION_CHANGED) {
                    if (popup != null) { hidePopup(); showPopup(currentBattery) }
                    return
                }
                val device = deviceFrom(intent) ?: return
                val address = try { device.address } catch (_: SecurityException) { null }
                if (!TARGET_MAC.equals(address, true)) return
                when (intent.action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> {
                        // Reconcile the ACL event against the device-specific active profile list.
                        handler.postDelayed({
                            if (isTargetAclConnected()) {
                                showPopup(readBattery(device))
                                handler.postDelayed({ if (isTargetAclConnected()) updateBattery(readBattery(device)) }, 1800)
                                handler.postDelayed({ if (isTargetAclConnected()) updateBattery(readBattery(device)) }, 4000)
                            }
                        }, 700)
                    }
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                        currentBattery = -1
                        popup?.setBattery(-1)
                        hidePopup()
                    }
                    ACTION_BATTERY_LEVEL_CHANGED -> {
                        if (lastKnownConnected && isTargetAclConnected()) updateBattery(intent.getIntExtra(EXTRA_BATTERY_LEVEL, -1))
                    }
                }
            }
        }
        receiver = r
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(ACTION_BATTERY_LEVEL_CHANGED)
            addAction(Intent.ACTION_CONFIGURATION_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(r, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra(EXTRA_TEST, false) == true) verifyTestConnection()
        return START_STICKY
    }

    private fun verifyTestConnection() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            showMessage("Bluetooth permission required"); return
        }
        val adapter = try { getSystemService(BluetoothManager::class.java)?.adapter } catch (_: SecurityException) { null }
        if (adapter == null || !adapter.isEnabled) { showMessage("Bluetooth unavailable"); return }
        val device = try { adapter.getRemoteDevice(TARGET_MAC) } catch (_: Exception) { null }
        if (device == null) { showMessage("Configured AirPods not found"); return }
        // A device-specific ACL query is the authoritative link state; bonded/paired is not connected.
        if (isTargetAclConnected()) {
            showPopup(readBattery(device))
        } else {
            currentBattery = -1
            popup?.setBattery(-1)
            hidePopup()
            showMessage("AirPods not connected")
        }
    }

    private fun showMessage(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }

    private fun isTargetAclConnected(): Boolean {
        return try {
            val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return false
            if (!adapter.isEnabled) return false
            val manager = getSystemService(BluetoothManager::class.java) ?: return false
            // Query device-specific active profile lists; pairing alone is never treated as connected.
            val a2dp = manager.getConnectedDevices(BluetoothProfile.A2DP)
            val headset = manager.getConnectedDevices(BluetoothProfile.HEADSET)
            (a2dp + headset).any { TARGET_MAC.equals(it.address, ignoreCase = true) }
        } catch (_: SecurityException) { false } catch (_: Exception) { false }
    }

    @Suppress("DEPRECATION")
    private fun deviceFrom(intent: Intent): BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
    else intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    private fun readBattery(device: BluetoothDevice?): Int {
        if (device == null) return -1
        return try {
            val value = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(device) as? Int
            value?.takeIf { it in 0..100 } ?: -1
        } catch (_: Exception) { -1 } catch (_: LinkageError) { -1 }
    }

    private fun updateBattery(level: Int) {
        currentBattery = level.takeIf { it in 0..100 } ?: -1
        popup?.setBattery(currentBattery)
    }

    private fun showPopup(level: Int) {
        currentBattery = level.takeIf { it in 0..100 } ?: -1
        if (!Settings.canDrawOverlays(this)) { showMessage("Allow display over other apps for PodPop"); return }
        handler.removeCallbacks(hideRunnable)
        val current = popup
        if (current != null) {
            current.setBattery(level)
            handler.postDelayed(hideRunnable, POPUP_TIMEOUT_MS)
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = PodPopupView(this, level) { hidePopup() }
        val width = (resources.displayMetrics.widthPixels * 0.92f).toInt()
        val params = WindowManager.LayoutParams(width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            val bottomInset = (resources.displayMetrics.density * 38f).toInt()
            y = bottomInset
        }
        try {
            wm.addView(view, params)
            popup = view
            handler.postDelayed(hideRunnable, POPUP_TIMEOUT_MS)
        } catch (_: Exception) { popup = null }
    }

    private fun hidePopup() {
        handler.removeCallbacks(hideRunnable)
        val view = popup ?: return
        popup = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view) } catch (_: Exception) { }
    }

    override fun onDestroy() {
        hidePopup()
        handler.removeCallbacksAndMessages(null)
        receiver?.let { try { unregisterReceiver(it) } catch (_: Exception) { } }
        receiver = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val TARGET_MAC = "41:42:84:7B:08:D6"
        const val EXTRA_TEST = "podpop_test"
        const val POPUP_TIMEOUT_MS = 3_000L
        const val ACTION_BATTERY_LEVEL_CHANGED = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY_LEVEL = "android.bluetooth.device.extra.BATTERY_LEVEL"
    }
}
