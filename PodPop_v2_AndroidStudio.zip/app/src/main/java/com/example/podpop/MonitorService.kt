package com.example.podpop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

class MonitorService : Service() {
    private var receiver: BroadcastReceiver? = null
    private val handler = Handler(Looper.getMainLooper())
    private var popup: PodPopupView? = null
    private val hideRunnable = Runnable { hidePopup() }

    override fun onCreate() {
        super.onCreate()
        val channel = "podpop_monitor"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channel, "PodPop connection monitor", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channel)
            .setContentTitle("PodPop is active")
            .setContentText("Watching for your Pro2 earbuds")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .build()
        startForeground(42, notification)

        val r = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val device = deviceFrom(intent)
                val address = try { device?.address } catch (e: SecurityException) { null }
                if (!TARGET_MAC.equals(address, ignoreCase = true)) return
                when (intent.action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> {
                        showPopup(readBattery(device))
                        // Battery info often arrives a moment after connecting; re-check.
                        handler.postDelayed({ updateBattery(readBattery(device)) }, 2000)
                        handler.postDelayed({ updateBattery(readBattery(device)) }, 4500)
                    }
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> hidePopup()
                    ACTION_BATTERY_LEVEL_CHANGED ->
                        updateBattery(intent.getIntExtra(EXTRA_BATTERY_LEVEL, -1))
                }
            }
        }
        receiver = r
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(ACTION_BATTERY_LEVEL_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(r, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra(EXTRA_TEST, false) == true) {
            val device = try {
                getSystemService(BluetoothManager::class.java)?.adapter?.getRemoteDevice(TARGET_MAC)
            } catch (e: Exception) { null }
            showPopup(readBattery(device))
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun deviceFrom(intent: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
        }

    /** Battery level Android currently knows for this device, or -1 if unknown. */
    private fun readBattery(device: BluetoothDevice?): Int {
        if (device == null) return -1
        return try {
            val v = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(device) as? Int
            if (v != null && v in 0..100) v else -1
        } catch (e: Throwable) {
            -1
        }
    }

    private fun updateBattery(level: Int) {
        if (level in 0..100) popup?.setBattery(level)
    }

    private fun showPopup(level: Int) {
        if (!Settings.canDrawOverlays(this)) return
        handler.removeCallbacks(hideRunnable)
        val existing = popup
        if (existing != null) {
            if (level in 0..100) existing.setBattery(level)
            handler.postDelayed(hideRunnable, 7000)
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = PodPopupView(this, level)
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.90f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (28 * resources.displayMetrics.density).toInt()
        }
        try {
            wm.addView(view, params)
            popup = view
            handler.postDelayed(hideRunnable, 7000)
        } catch (e: Exception) {
            popup = null
        }
    }

    private fun hidePopup() {
        handler.removeCallbacks(hideRunnable)
        val view = popup ?: return
        popup = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (e: Exception) {
            // already removed
        }
    }

    override fun onDestroy() {
        hidePopup()
        handler.removeCallbacksAndMessages(null)
        receiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        receiver = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val TARGET_MAC = "41:42:84:7B:08:D6"
        const val EXTRA_TEST = "podpop_test"
        // These two constants are hidden from the public Android SDK, so they must be plain strings.
        const val ACTION_BATTERY_LEVEL_CHANGED = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY_LEVEL = "android.bluetooth.device.extra.BATTERY_LEVEL"
    }
}
