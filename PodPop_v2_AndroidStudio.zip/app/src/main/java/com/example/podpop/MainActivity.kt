package com.example.podpop

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var pendingTest = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        val foreground = if (isDark) Color.WHITE else Color.rgb(30, 30, 34)
        val muted = if (isDark) Color.rgb(170, 170, 178) else Color.rgb(100, 100, 108)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(26, 30, 26, 24)
            setBackgroundColor(if (isDark) Color.rgb(12, 12, 14) else Color.rgb(248, 248, 250))
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.podpop_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(154, 154).apply { bottomMargin = 12 }
            contentDescription = "PodPop AirPods logo"
        })
        root.addView(TextView(this).apply {
            text = "PodPop"
            textSize = 30f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextColor(foreground)
        })
        root.addView(TextView(this).apply {
            text = "A premium AirPods connection popup."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, 10, 0, 22)
        })
        addAction(root, "1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addAction(root, "2. Allow Bluetooth access") {
            if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12) else startMonitor()
        }
        addAction(root, "3. Start PodPop") { startMonitor() }
        addAction(root, "4. Allow background activity (battery)") {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { }
        }
        addAction(root, "Test popup now", true) { startMonitor(test = true) }
        root.addView(TextView(this).apply {
            text = "Selected device: AirPods Pro\nBluetooth ID: 41:42:84:7B:08:D6\n\nBattery readings appear only when Android receives them from your earbuds. Case battery is marked unavailable when it cannot be read."
            textSize = 13f
            setTextColor(Color.rgb(145,145,153))
            setPadding(2, 20, 2, 0)
        })
        setContentView(root)
    }

    private fun addAction(root: LinearLayout, label: String, primary: Boolean = false, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(if (primary) Color.WHITE else Color.rgb(235,235,240))
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (primary) Color.rgb(48,112,245) else Color.rgb(43,43,48)))
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 52).apply { bottomMargin = 9 }
        })
    }

    private fun startMonitor(test: Boolean = false) {
        pendingTest = test
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12); return
        }
        val i = Intent(this, MonitorService::class.java).putExtra(MonitorService.EXTRA_TEST, test)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 12 && grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) startMonitor(pendingTest)
    }
}
