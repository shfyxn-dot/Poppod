package com.example.podpop

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(26, 38, 26, 24)
            setBackgroundColor(Color.rgb(247,247,249))
        }
        root.addView(TextView(this).apply {
            text = "PodPop"
            textSize = 32f
            setTextColor(Color.rgb(25,25,30))
        })
        root.addView(TextView(this).apply {
            text = "A connection popup for your selected Pro2 Bluetooth device."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "2. Allow Bluetooth access"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12)
                else startMonitor()
            }
        })
        root.addView(Button(this).apply {
            text = "3. Start PodPop"
            setOnClickListener { startMonitor() }
        })
        root.addView(TextView(this).apply {
            text = "Selected device: Pro2\nBluetooth ID: 41:42:84:7B:08:D6\n\nKeep PodPop running in the background. Battery data appears only if your earbuds send it to Android."
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
    }
    private fun startMonitor() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12); return
        }
        val i = Intent(this, MonitorService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 12 && grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) startMonitor()
    }
}
