package com.example.podpop

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class PodPopupView(context: Context, initialBattery: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var angle = 0f
    private var battery = initialBattery
    private val density = resources.displayMetrics.density

    private val animator: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 2200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { angle = it.animatedValue as Float; invalidate() }
    }

    init {
        // Software layer so the card shadow draws reliably on every device.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        animator.start()
    }

    fun setBattery(level: Int) {
        battery = level
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Without this the view would measure 0px tall and never appear.
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (220f * density).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = density
        val w = width.toFloat()
        val h = 220f * d
        val card = RectF(8f * d, 4f * d, w - 8f * d, h - 12f * d)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.setShadowLayer(14f * d, 0f, 5f * d, 0x44000000)
        canvas.drawRoundRect(card, 28f * d, 28f * d, p)
        p.clearShadowLayer()

        p.color = Color.rgb(35, 35, 40)
        p.textSize = 17f * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        canvas.drawText("AirPods Pro", 28f * d, 36f * d, p)
        p.color = Color.GRAY
        p.textSize = 12f * d
        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        canvas.drawText("Connected", 28f * d, 56f * d, p)

        // Rotating case + two earbuds (original artwork).
        val cx = w * 0.50f
        val cy = 114f * d
        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(abs(cos(Math.toRadians(angle.toDouble())).toFloat()).coerceAtLeast(0.18f), 1f)
        p.color = Color.rgb(232, 233, 237)
        canvas.drawRoundRect(-58f * d, -8f * d, 58f * d, 38f * d, 16f * d, 16f * d, p)
        p.color = Color.rgb(205, 208, 214)
        canvas.drawRoundRect(-58f * d, -15f * d, 58f * d, 4f * d, 13f * d, 13f * d, p)
        p.color = Color.rgb(160, 164, 172)
        canvas.drawCircle(0f, 17f * d, 2.5f * d, p)
        canvas.restore()

        for (i in 0..1) {
            val sign = if (i == 0) -1f else 1f
            val a = Math.toRadians((angle * sign).toDouble())
            val ex = cx + (sign * 78f * d * cos(a)).toFloat()
            val ey = cy - 13f * d + (sin(a).toFloat() * 5f * d)
            canvas.save()
            canvas.translate(ex, ey)
            canvas.rotate(sign * angle * 0.35f)
            p.color = Color.rgb(244, 245, 248)
            canvas.drawRoundRect(-7f * d, -17f * d, 7f * d, 17f * d, 7f * d, 7f * d, p)
            p.color = Color.rgb(220, 222, 227)
            canvas.drawRoundRect(-3f * d, 8f * d, 3f * d, 27f * d, 3f * d, 3f * d, p)
            canvas.restore()
        }

        val known = battery in 0..100
        p.color = Color.rgb(75, 75, 82)
        p.textSize = 13f * d
        canvas.drawText(if (known) "Earbuds  $battery%" else "Earbuds  battery not reported yet", 28f * d, 180f * d, p)

        // Battery bar
        val left = w - 108f * d
        val right = w - 28f * d
        val top = 168f * d
        val bottom = 178f * d
        p.color = Color.rgb(226, 228, 233)
        canvas.drawRoundRect(left, top, right, bottom, 5f * d, 5f * d, p)
        if (known) {
            p.color = if (battery <= 20) Color.rgb(255, 59, 48) else Color.rgb(48, 209, 88)
            canvas.drawRoundRect(left, top, left + (right - left) * battery / 100f, bottom, 5f * d, 5f * d, p)
        }

        // Honest note: the case level is never guessed.
        p.color = Color.rgb(140, 140, 148)
        p.textSize = 11f * d
        canvas.drawText("Case  not reported by these earbuds", 28f * d, 199f * d, p)
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }
}
