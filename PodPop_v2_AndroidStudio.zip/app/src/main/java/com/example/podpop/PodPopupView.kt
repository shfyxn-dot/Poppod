package com.example.podpop

import android.content.Context
import android.graphics.*
import android.view.View
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator
import kotlin.math.*

class PodPopupView(context: Context, private val battery: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var angle = 0f
    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 2200; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { angle = it.animatedValue as Float; invalidate() }; start()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = 220f * resources.displayMetrics.density
        val d = resources.displayMetrics.density
        val r = RectF(0f, 0f, w, h)
        p.color = Color.WHITE; p.setShadowLayer(18f, 0f, 7f, 0x33000000); canvas.drawRoundRect(r, 28f*d, 28f*d, p); p.clearShadowLayer()
        p.color = Color.rgb(35,35,40); p.textSize = 17f*d; p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        canvas.drawText("AirPods Pro", 24f*d, 36f*d, p)
        p.color = Color.GRAY; p.textSize = 12f*d; p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        canvas.drawText("Connected", 24f*d, 56f*d, p)
        // Rotating illustrated case + two earbuds, deliberately original artwork.
        val cx = w*0.50f; val cy = 119f*d
        canvas.save(); canvas.translate(cx, cy); canvas.scale(abs(cos(Math.toRadians(angle.toDouble())).toFloat()).coerceAtLeast(0.18f), 1f)
        p.color = Color.rgb(232,233,237); canvas.drawRoundRect(-58f*d, -8f*d, 58f*d, 38f*d, 16f*d, 16f*d, p)
        p.color = Color.rgb(205,208,214); canvas.drawRoundRect(-58f*d, -15f*d, 58f*d, 4f*d, 13f*d, 13f*d, p)
        p.color = Color.rgb(160,164,172); canvas.drawCircle(0f, 17f*d, 2.5f*d, p)
        canvas.restore()
        // earbuds rotate in opposing small arcs
        for (i in 0..1) {
            val sign = if (i==0) -1f else 1f
            val a = Math.toRadians((angle*sign).toDouble())
            val ex = cx + (sign*78f*d*cos(a)).toFloat()
            val ey = cy - 13f*d + (sin(a).toFloat()*5f*d)
            canvas.save(); canvas.translate(ex, ey); canvas.rotate(sign*angle*0.35f)
            p.color = Color.rgb(244,245,248); canvas.drawRoundRect(-7f*d,-17f*d,7f*d,17f*d,7f*d,7f*d,p)
            p.color = Color.rgb(220,222,227); canvas.drawRoundRect(-3f*d,8f*d,3f*d,27f*d,3f*d,3f*d,p)
            canvas.restore()
        }
        p.color = Color.rgb(75,75,82); p.textSize = 13f*d
        val batteryText = if (battery in 0..100) "$battery%" else "Battery unavailable"
        canvas.drawText(batteryText, 24f*d, 190f*d, p)
        p.color = Color.rgb(52,120,246); canvas.drawRoundRect( w-95f*d, 177f*d, w-24f*d, 184f*d, 4f*d,4f*d,p)
        if (battery in 0..100) {
            p.color = Color.rgb(52,120,246); canvas.drawRoundRect(w-95f*d,177f*d,w-95f*d+71f*d*battery/100f,184f*d,4f*d,4f*d,p)
        }
    }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }
}
