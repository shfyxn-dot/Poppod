package com.example.podpop

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.sin

/** Premium AirPods-inspired connection card. Unknown levels are shown explicitly, never guessed. */
class PodPopupView(context: Context, initialBattery: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var earbudsBattery = initialBattery.takeIf { it in 0..100 } ?: -1
    private var floatPhase = 0f
    private val d = resources.displayMetrics.density
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600L
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener { floatPhase = it.animatedValue as Float; invalidate() }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null); anim.start() }
    fun setBattery(level: Int) { earbudsBattery = level.takeIf { it in 0..100 } ?: -1; invalidate() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(width, (390f * d).toInt())
    }

    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, face: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = color; p.textSize = size * d; p.typeface = face; p.textAlign = Paint.Align.CENTER
        c.drawText(value, x, y, p)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val card = RectF(5f*d, 5f*d, w-5f*d, h-7f*d)
        p.shader = LinearGradient(0f, card.top, w, card.bottom, intArrayOf(Color.rgb(34,34,37), Color.rgb(24,24,26), Color.rgb(29,29,32)), null, Shader.TileMode.CLAMP)
        p.setShadowLayer(22f*d, 0f, 10f*d, 0x99000000.toInt())
        canvas.drawRoundRect(card,  thirty(), thirty(), p)
        p.clearShadowLayer(); p.shader = null

        // Subtle top sheen gives the popup a glassy, dimensional finish.
        p.shader = LinearGradient(0f, card.top, 0f, card.top+95f*d, 0x22FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(card, thirty(), thirty(), p); p.shader = null

        text(canvas, "AirPods Pro", w/2f, 66f*d, 27f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL))
        text(canvas, "CONNECTED", w/2f, 88f*d, 9f, Color.rgb(158,158,165), Typeface.create("sans-serif-medium", Typeface.NORMAL))
        val bob = sin(floatPhase * Math.PI * 2).toFloat() * 3f*d
        drawEarbud(canvas, w*0.25f, 188f*d+bob, -28f)
        drawEarbud(canvas, w*0.43f, 188f*d-bob, 28f)
        drawCase(canvas, w*0.73f, 195f*d-bob*0.35f)

        val baseline = 292f*d
        drawBattery(canvas, w*0.25f, baseline, earbudsBattery, "EARBUDS")
        // Android exposes one aggregate device battery at best; case level is not independently available.
        drawBattery(canvas, w*0.73f, baseline, -1, "CASE")
        text(canvas, "Battery levels are shown only when reported by your device", w/2f, 365f*d, 9f, Color.rgb(133,133,141))
    }

    private fun thirty() =  thirtyValue()
    private fun thirtyValue() = 30f*d

    private fun drawEarbud(c: Canvas, x: Float, y: Float, rotation: Float) {
        c.save(); c.translate(x,y); c.rotate(rotation)
        // Stem and polished silicone body, layered to create a 3D look.
        p.shader = LinearGradient(-12f*d, 0f, 12f*d, 0f, intArrayOf(0xFFBFC1C7.toInt(), 0xFFFFFFFF.toInt(), 0xFFD7D9DE.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(-7f*d, 5f*d, 7f*d, 73f*d, 6f*d, 6f*d, p); p.shader = null
        p.color = 0xFFE8E9ED.toInt(); c.drawRoundRect(-5f*d, 14f*d, 5f*d, 69f*d, 4f*d, 4f*d, p)
        p.shader = LinearGradient(-25f*d,-27f*d,22f*d,24f*d, intArrayOf(0xFFFFFFFF.toInt(),0xFFE9EAF0.toInt(),0xFFBFC2CA.toInt()), null, Shader.TileMode.CLAMP)
        c.drawOval(RectF(-27f*d,-35f*d,27f*d,25f*d),p); p.shader = null
        p.color = Color.rgb(70,72,78); c.drawRoundRect(-16f*d,-25f*d,4f*d,-18f*d,4f*d,4f*d,p)
        p.color = Color.rgb(195,198,204); c.drawCircle(18f*d,1f*d,5f*d,p)
        c.restore()
    }

    private fun drawCase(c: Canvas, x: Float, y: Float) {
        c.save(); c.translate(x,y)
        val r = RectF(-67f*d,-42f*d,67f*d,45f*d)
        p.shader = LinearGradient(-60f*d,-45f*d,65f*d,55f*d,intArrayOf(0xFFFFFFFF.toInt(),0xFFE4E5EA.toInt(),0xFFBFC1C8.toInt()),null,Shader.TileMode.CLAMP)
        p.setShadowLayer(10f*d,0f,7f*d,0x77000000); c.drawRoundRect(r,25f*d,25f*d,p); p.clearShadowLayer(); p.shader=null
        p.color = 0xFFD0D2D8.toInt(); c.drawRoundRect(RectF(-66f*d,-17f*d,66f*d,-13f*d),2f*d,2f*d,p)
        p.color = 0xFFB4B7BF.toInt(); c.drawCircle(0f,20f*d,2.3f*d,p)
        p.color = 0xFF70D68A.toInt(); c.drawCircle(0f,20f*d,1.2f*d,p)
        c.restore()
    }

    private fun drawBattery(c: Canvas, centerX: Float, y: Float, level: Int, label: String) {
        val left = centerX-23f*d; val top = y-12f*d; val right = centerX+19f*d; val bottom = y+10f*d
        p.style=Paint.Style.STROKE; p.strokeWidth=1.7f*d; p.color=0xFF777980.toInt()
        c.drawRoundRect(RectF(left,top,right,bottom),5f*d,5f*d,p); c.drawRoundRect(RectF(right+2f*d,y-5f*d,right+5f*d,y+3f*d),1f*d,1f*d,p); p.style=Paint.Style.FILL
        if(level in 0..100) {
            val fillColor=if(level<=20) 0xFFFF625B.toInt() else 0xFF35D66F.toInt()
            p.color=fillColor; c.drawRoundRect(RectF(left+3f*d,top+3f*d,left+3f*d+(right-left-6f*d)*level/100f,bottom-3f*d),3f*d,3f*d,p)
        } else {
            text(c,"🚫",centerX-9f*d,y+6f*d,15f,Color.WHITE)
        }
        text(c, if(level in 0..100) "$level%" else "—", centerX, y+39f*d, 20f, Color.WHITE, Typeface.create("sans-serif-medium",Typeface.NORMAL))
        p.textAlign=Paint.Align.CENTER
        text(c,label,centerX,y+57f*d,9f,0xFF9B9BA2.toInt(),Typeface.create("sans-serif-medium",Typeface.NORMAL))
        p.textAlign=Paint.Align.LEFT
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}
