package com.example.podpop

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Static reference-art popup. The PNG is bundled locally; no runtime network access is used. */
class PodPopupView(context: Context, initialBattery: Int, private val onClose: () -> Unit) : FrameLayout(context) {
    private val batteryText: TextView
    private val batteryGlyph: TextView
    private val dark: Boolean get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val dp: (Float) -> Int = { (it * resources.displayMetrics.density).toInt() }

    init {
        val cardColor = if (dark) Color.rgb(27, 27, 30) else Color.rgb(248, 248, 250)
        val textColor = if (dark) Color.WHITE else Color.rgb(30, 30, 34)
        background = GradientDrawable().apply {
            setColor(cardColor)
            cornerRadius = dp(26f).toFloat()
            setStroke(dp(1f), if (dark) 0x33FFFFFF else 0x18000000)
        }
        elevation = dp(18f).toFloat()
        clipToOutline = true

        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(10f), dp(10f), dp(10f), dp(15f))
        }
        val artwork = ImageView(context).apply {
            setImageResource(R.drawable.pro2)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(43, 43, 47)) // matches the supplied image's graphite backdrop
            contentDescription = "AirPods and charging case"
        }
        content.addView(artwork, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(116f)))
        val status = TextView(context).apply {
            text = "CONNECTED"
            textSize = 10f
            letterSpacing = .16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(if (dark) 0xFF9B9BA3.toInt() else 0xFF73737B.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(12f), 0, dp(5f))
        }
        content.addView(status)
        val batteryRow = LinearLayout(context).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        batteryGlyph = TextView(context).apply {
            text = "▱"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (dark) Color.WHITE else Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        batteryText = TextView(context).apply {
            textSize = 20f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(textColor)
            gravity = Gravity.CENTER
            setPadding(dp(7f), 0, 0, 0)
        }
        batteryRow.addView(batteryGlyph, LinearLayout.LayoutParams(dp(27f), dp(30f)))
        batteryRow.addView(batteryText)
        content.addView(batteryRow)
        addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        val close = TextView(context).apply {
            text = "×"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(if (dark) Color.WHITE else Color.DKGRAY)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (dark) 0x66333338 else 0x66FFFFFF)
            }
            contentDescription = "Close popup"
            isClickable = true
            isFocusable = false
            setOnClickListener { onClose() }
        }
        addView(close, LayoutParams(dp(30f), dp(30f), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(8f); marginEnd = dp(8f)
        })
        setBattery(initialBattery)
    }

    fun setBattery(level: Int) {
        val valid = level in 0..100
        batteryText.text = if (valid) "$level%" else "—"
        batteryGlyph.text = if (valid) "▰" else "▱"
        batteryGlyph.setTextColor(if (valid && level <= 20) 0xFFFF625B.toInt() else if (dark) Color.WHITE else Color.DKGRAY)
    }
}
