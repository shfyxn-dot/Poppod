# SurvivalVerse Stickman Studio plugin port

This build ports the usable creative workflow from `SurvivalVerse_Stickman_Studio_v3.plugin` into the Android app while retaining the app's existing native MP4 renderer and GrowKaz visual engine.

## Integrated
- Survival Series tab with DAY 1+ episode planning, zombie and supernatural branches, protagonist/location/visual identity, threat, supplies and previous-episode context.
- Offline episode-script builder with 60/90/120-second planning modes, survival hook, emergency signal, decision point, resource checklist, cliffhanger and meaningful A/B choices.
- Series continuity ledger stored in WebView local storage; episode records include day, runtime, genre, location, resources, cliffhanger, vote options and script.
- Series bible JSON export for backup or moving continuity to another device.
- Existing recurring character PNG library, background library, auto-directed shots, camera directions, SFX/music, captions, SRT, storyboard/contact-sheet export, six colour looks and native MP4 rendering remain intact.
- Production QC checklist based on the plugin's character, geography, resource, animation and cliffhanger requirements.

## Platform adaptations / limitations
- The source `.plugin` is a Claude Code skill package, not an Android installable plugin. Its markdown skills and Node/Python desktop renderer cannot execute directly inside this Android app.
- The episode builder is deterministic and offline, not an LLM. It creates an editable first-draft structure; creator must verify story logic, exact narration duration, resource continuity and visual details.
- The plugin's standalone Node/Three.js rendering pipeline was not substituted for the existing Kotlin MP4 export path. This preserves the working Android render workflow and avoids shipping a second incompatible renderer.
- Series continuity is stored separately from the normal episode project JSON. Export the Series Bible JSON when backing up or transferring the story universe.
- The app still requires the existing Android build workflow to compile the APK; this source ZIP contains the updated project, not a verified APK.

## Source skill concepts represented
`survival-series`, `new-video`, `video-styles`, `video-sound`, `render-video`, `make-2d-video` and their story/style/sound/QC references.
