# SurvivalVerse Studio v4.1

Script + (optional) narration/SRT -> finished 1080x1920 30fps MP4, fully offline.


## New in v4.1 (SurvivalVerse plugin port)
- New Survival Series tab: offline DAY 1+ episode-draft builder for zombie and supernatural survival, with 60/90/120-second planning, protagonist identity, location, threat, resources, hook, cliffhanger and A/B choices.
- Series continuity ledger stored on-device; save episode records and export a portable Series Bible JSON. Later days can carry forward the previous saved episode's cliffhanger and vote context.
- Survival production QC checklist for character consistency, location geography, resource continuity, purposeful shot direction and cliffhangers.
- Existing renderer, contact sheets, style presets, audio, SRT, library and Kotlin MP4 export remain the production path. See `docs/PLUGIN_PORT.md` for what was adapted and what remains platform-specific.

## New in v4 (GrowKaz engine)
- Studio look: GrowKaz rig2d/fx2d engine ported in (round-head character, red scarf, big eyes, GrowKaz-style captions: Fredoka, 3-4 word groups, gold active word). Settings -> Look: Studio / Classic, Colour style.
- Each shot gets its own composition: wide, medium, close-up (big face), over-the-shoulder, low angle, dialog, door-handle insert, peephole, feet insert; camera drifts per shot.
- New lit sets: room, door, hallway, alley, elevator (opening doors / inside), stairwell, bunker, city, forest, plus your imported backgrounds.
- Crash fix (AppCompat theme), app logo, .srt picker fix.

## v3
- Auto-director: plain script becomes many shots (~1 shot per 3-4 s), locations auto-picked (door, elevator, stairs, hallway, alley, bunker, forest, room, city).
- Library tab: save character PNGs (idle/talk/walk/run/fall/expressions) once; they persist across stories. Add your own backgrounds with keywords.
- Lip-sync: mouth/sprite flaps while narrator or character speaks. Tags: `[narrator] text`, `[Marina] text`.
- A/B choice cards + "COMMENT A OR B" ending; new heartbeat/noise HUD.
- Built-in synth SFX + music (heartbeat, knock, footsteps, door, elevator ding, riser...). Import your own too.
- Voices tab: offline Android TTS, different voice per speaker, exact SRT generated.
- SRT / JSON pickers now accept any file name (.srt works).

## Build
Push to GitHub; Actions builds the debug APK. Kotlin (encoder + TTS bridge) is not compiled in the authoring sandbox - report any build error.
