PodPop 3.3 - optional Nearby AirPods detection (Bluetooth LE case-open signal) + Scan test. Popup design unchanged.

PodPop 3.2 - setup steps show a tick when done; popup time (3/6/10/15 s) and vibration tick options. Popup design unchanged.

PodPop 3.1 - new: choose which part of the wallpaper shows (left/right, top/bottom, zoom) with a live preview in the app; AirPods size slider; videos show a still frame instantly so there is no lag; large-video tip.

PodPop v3.0

- Popup: name on top ("AirPods Pro 2"), taller, floating AirPods (transparent cut-out), batteries at
  the bottom, X button, auto-dismiss after 6 s.
- Custom popup wallpaper (PNG / JPG / GIF / MP4). Videos loop automatically and are muted.
  "Floating AirPods on wallpaper" switch decides if the AirPods image floats on top of it.
  "Use default look" removes the wallpaper.
- "Preview popup" shows the popup without earbuds (labelled "Preview", never "Connected").
- Stop button (app + notification), status line.
Build on GitHub: commit this zip + .github/workflows/build.yml, then download app-debug.apk from Releases.


PodPop Universal BLE diagnostics update
- Scan Test now uses an unfiltered BLE scan (no manufacturer/service filters).
- Shows advertised name, address when Android permits it, RSSI, manufacturer IDs/data,
  service UUIDs, service data, and raw advertisement bytes.
- Apple-format parsing remains in ProximityScanner.kt as a separate Apple-only path.
- The scan screen is diagnostic only; it does not infer lid-open state or invent battery values.
- Android 12+ requires the Nearby devices / BLUETOOTH_SCAN runtime permission.
- The manifest retains neverForLocation. Android documents that this flag can filter some
  beacon results. Do not remove it unless the app's location-use and permission model is
  deliberately redesigned and tested.
- A scan can run while audio earbuds are connected; connection does not generally disable
  BLE scanning. Validate on-device in both connected and disconnected states.
- Compare case-closed and case-open captures. Only add automatic nearby triggering after
  identifying a repeatable, device-specific pattern.
