package com.example.podpop

import android.content.Context

/** Remembers whether the user wants PodPop to run (so Stop also survives a reboot). */
object PodPrefs {
    private const val FILE = "podpop"
    private const val KEY_AUTOSTART = "autostart"

    fun autoStart(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_AUTOSTART, true)

    /** How long the popup stays on screen (seconds). */
    fun popupSeconds(context: Context): Int =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt("popup_seconds", 6)

    fun setPopupSeconds(context: Context, value: Int) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("popup_seconds", value).apply()
    }

    /** A tiny vibration tick when the popup appears. */
    fun haptic(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("haptic", true)

    fun setHaptic(context: Context, value: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("haptic", value).apply()
    }

    /** Optional: listen for the AirPods "lid open" Bluetooth broadcast (off by default). */
    fun nearby(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("nearby", false)

    fun setNearby(context: Context, value: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("nearby", value).apply()
    }

    fun setAutoStart(context: Context, value: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTOSTART, value).apply()
    }
}
