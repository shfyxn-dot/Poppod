package com.example.podpop

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var receiver: BroadcastReceiver? = null
    private var popup: PodPopupView? = null
    private var popupIsPreview = false
    private var popupIsNearby = false
    private var scanner: ProximityScanner? = null
    private var targetConnected = false
    private var lastNearbyAt = 0L
    private var lastBle: ProximityScanner.Reading? = null
    private var lastBleAt = 0L
    private var currentBattery = -1
    private var lastShownAt = 0L
    private var targetDevice: BluetoothDevice? = null

    private val hideRunnable = Runnable { hidePopup() }
    private val rereadRunnable = Runnable {
        val level = readBattery(targetDevice)
        if (level in 0..100) updateBattery(level)
    }

    override fun onCreate() {
        super.onCreate()
        val channel = "podpop_monitor"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channel, "PodPop connection monitor", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop",
            stopIntent
        ).build()
        val notification = Notification.Builder(this, channel)
            .setContentTitle("PodPop is active")
            .setContentText("Watching for your AirPods")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        startForeground(42, notification)

        val r = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val device = deviceFrom(intent) ?: return
                val address = try { device.address } catch (e: SecurityException) { null }
                if (!TARGET_MAC.equals(address, ignoreCase = true)) return
                val action = intent.action
                if (action == BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED ||
                    action == BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED
                ) {
                    // Real audio-profile connection, not just a Bluetooth link or pairing.
                    val state = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED)
                    if (state == BluetoothProfile.STATE_CONNECTED) onTargetConnected(device)
                } else if (action == BluetoothDevice.ACTION_ACL_DISCONNECTED) {
                    onTargetDisconnected()
                } else if (action == ACTION_BATTERY_LEVEL_CHANGED) {
                    if (popup != null) updateBattery(intent.getIntExtra(EXTRA_BATTERY_LEVEL, -1))
                }
            }
        }
        receiver = r
        val filter = IntentFilter()
        filter.addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
        filter.addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        filter.addAction(ACTION_BATTERY_LEVEL_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(r, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // Stop pressed (app button or notification): remember it, remove the notification, quit.
            PodPrefs.setAutoStart(this, false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        refreshProximity()
        if (intent?.getBooleanExtra(EXTRA_TEST, false) == true) verifyTestConnection()
        if (intent?.getBooleanExtra(EXTRA_PREVIEW, false) == true) showPreview()
        return START_STICKY
    }

    // ---------- connection events ----------

    private fun onTargetConnected(device: BluetoothDevice) {
        targetDevice = device
        targetConnected = true
        val now = SystemClock.elapsedRealtime()
        val level = readBattery(device)
        if (popup != null && !popupIsNearby && now - lastShownAt < DEDUPE_MS) {
            // A2DP and Headset both report "connected"; don't pop up twice.
            if (level in 0..100) updateBattery(level)
        } else {
            showPopup(level)
        }
        // Battery usually arrives a moment after the connection.
        handler.removeCallbacks(rereadRunnable)
        handler.postDelayed(rereadRunnable, 900)
        handler.postDelayed(rereadRunnable, 2000)
    }

    private fun onTargetDisconnected() {
        targetConnected = false
        handler.removeCallbacks(rereadRunnable)
        currentBattery = -1
        hidePopup()
    }

    // ---------- optional: nearby AirPods (Bluetooth LE "lid open" broadcast) ----------

    /** Starts or stops the scanner so it matches the app's switch. */
    private fun refreshProximity() {
        val want = PodPrefs.nearby(this) && ProximityScanner.hasPermission(this)
        if (!want) {
            scanner?.stop()
            scanner = null
            return
        }
        if (scanner?.running == true) return
        // Learn whether the AirPods are already connected, so an open case doesn't pop up "Nearby".
        val adapter: BluetoothAdapter? = try { getSystemService(BluetoothManager::class.java)?.adapter } catch (e: Exception) { null }
        if (adapter != null && (Build.VERSION.SDK_INT < 31 ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)) {
            checkTargetConnected(adapter) { connected -> targetConnected = connected }
        }
        val s = ProximityScanner(this) { onProximity(it) }
        if (s.start()) scanner = s
    }

    private fun onProximity(r: ProximityScanner.Reading) {
        val now = SystemClock.elapsedRealtime()
        if (r.case >= 0 && r.rssi >= NEARBY_MIN_RSSI) {
            lastBle = r
            lastBleAt = now
            // Real case level received while a connected popup is open: fill it in.
            if (popup != null && !popupIsNearby && !popupIsPreview) popup?.setCase(r.case)
        }
        if (popup != null || targetConnected) return
        if (r.rssi < NEARBY_MIN_RSSI) return                 // only very close devices (about 1 m)
        if (now - lastNearbyAt < NEARBY_COOLDOWN_MS) return
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (!pm.isInteractive) return
        lastNearbyAt = now
        lastBle = r
        lastBleAt = now
        val buds = if (r.left >= 0 && r.right >= 0) minOf(r.left, r.right) else maxOf(r.left, r.right)
        showPopup(buds, false, true)
    }

    // ---------- preview button (no earbuds needed; labelled "Preview", never "Connected") ----------

    private fun showPreview() {
        val device: BluetoothDevice? = try {
            getSystemService(BluetoothManager::class.java)?.adapter?.getRemoteDevice(TARGET_MAC)
        } catch (e: Exception) {
            null
        }
        hidePopup()
        showPopup(readBattery(device), true)
    }

    // ---------- test button ----------

    private fun verifyTestConnection() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            toast("Bluetooth permission required")
            return
        }
        val adapter: BluetoothAdapter? = try {
            getSystemService(BluetoothManager::class.java)?.adapter
        } catch (e: Exception) {
            null
        }
        if (adapter == null || !adapter.isEnabled) {
            toast("Bluetooth is off or unavailable")
            return
        }
        val device: BluetoothDevice? = try { adapter.getRemoteDevice(TARGET_MAC) } catch (e: Exception) { null }
        if (device == null) {
            toast("Configured AirPods not found")
            return
        }
        checkTargetConnected(adapter) { connected ->
            if (connected) {
                targetDevice = device
                showPopup(readBattery(device))
            } else {
                currentBattery = -1
                hidePopup()
                toast("AirPods not connected")
            }
        }
    }

    /** Asks Android which devices are really connected on the A2DP, then Headset profile. */
    private fun checkTargetConnected(adapter: BluetoothAdapter, result: (Boolean) -> Unit) {
        queryProfile(adapter, BluetoothProfile.A2DP) { onA2dp ->
            if (onA2dp) {
                result(true)
            } else {
                queryProfile(adapter, BluetoothProfile.HEADSET) { onHeadset -> result(onHeadset) }
            }
        }
    }

    private fun queryProfile(adapter: BluetoothAdapter, profile: Int, done: (Boolean) -> Unit) {
        var finished = false
        val listener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                val found = try {
                    proxy.connectedDevices.any { TARGET_MAC.equals(it.address, ignoreCase = true) }
                } catch (e: Exception) {
                    false
                }
                try { adapter.closeProfileProxy(p, proxy) } catch (e: Exception) { }
                if (!finished) {
                    finished = true
                    done(found)
                }
            }

            override fun onServiceDisconnected(p: Int) {}
        }
        val started = try { adapter.getProfileProxy(this, listener, profile) } catch (e: Exception) { false }
        if (!started) {
            finished = true
            done(false)
            return
        }
        handler.postDelayed({
            if (!finished) {
                finished = true
                done(false)
            }
        }, 2500)
    }

    // ---------- battery ----------

    /** Battery level Android currently knows for this device, or -1 if unknown. */
    private fun readBattery(device: BluetoothDevice?): Int {
        if (device == null) return -1
        return try {
            val value = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(device) as? Int
            if (value != null && value in 0..100) value else -1
        } catch (e: Throwable) {
            -1
        }
    }

    private fun updateBattery(level: Int) {
        currentBattery = if (level in 0..100) level else -1
        popup?.setBattery(currentBattery)
    }

    // ---------- popup ----------

    private fun showPopup(level: Int, preview: Boolean = false, nearby: Boolean = false) {
        currentBattery = if (level in 0..100) level else -1
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow display over other apps for PodPop")
            return
        }
        handler.removeCallbacks(hideRunnable)
        if (popup != null && popupIsNearby && !nearby) hidePopup()   // now really connected: rebuild as "Connected"
        val existing = popup
        if (existing != null) {
            existing.setBattery(currentBattery)
            handler.postDelayed(hideRunnable, PodPrefs.popupSeconds(this) * 1000L)
            return
        }
        val d = resources.displayMetrics.density
        val screenW = resources.displayMetrics.widthPixels
        val width = Math.min(screenW, (520f * d).toInt())
        val navId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        val navH = if (navId > 0) resources.getDimensionPixelSize(navId) else 0

        val view = PodPopupView(this, currentBattery, preview, nearby = nearby) { hidePopup() }
        val params = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        params.y = navH + (6f * d).toInt()
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(view, params)
            popup = view
            popupIsPreview = preview
            popupIsNearby = nearby
            if (!preview && SystemClock.elapsedRealtime() - lastBleAt < BLE_FRESH_MS) lastBle?.let { view.setCase(it.case) }
            tick()
            lastShownAt = SystemClock.elapsedRealtime()
            handler.postDelayed(hideRunnable, PodPrefs.popupSeconds(this) * 1000L)
        } catch (e: Exception) {
            popup = null
        }
    }

    /** Small vibration when the popup appears (can be turned off in the app). */
    @Suppress("DEPRECATION")
    private fun tick() {
        if (!PodPrefs.haptic(this)) return
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            v.vibrate(android.os.VibrationEffect.createOneShot(22L, 110))
        } catch (e: Exception) {
            // No vibrator: ignore.
        }
    }

    private fun hidePopup() {
        handler.removeCallbacks(hideRunnable)
        val view = popup ?: return
        popup = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (e: Exception) {
            // already removed
        }
    }

    /** Rebuild the popup when the system switches between light and dark. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (popup != null) {
            val level = currentBattery
            hidePopup()
            showPopup(level, popupIsPreview, popupIsNearby)
        }
    }

    // ---------- helpers ----------

    @Suppress("DEPRECATION")
    private fun deviceFrom(intent: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
        }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        scanner?.stop()
        scanner = null
        hidePopup()
        handler.removeCallbacksAndMessages(null)
        receiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        receiver = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val TARGET_MAC = "41:42:84:7B:08:D6"
        const val EXTRA_TEST = "podpop_test"
        const val EXTRA_PREVIEW = "podpop_preview"
        const val ACTION_STOP = "com.example.podpop.STOP"
        /** How long the popup stays on screen. */
        const val POPUP_TIMEOUT_MS = 6_000L
        private const val DEDUPE_MS = 4_000L
        /** Nearby popup only for a very close signal (dBm), and at most once a minute. */
        private const val NEARBY_MIN_RSSI = -58
        private const val NEARBY_COOLDOWN_MS = 60_000L
        private const val BLE_FRESH_MS = 30_000L
        // Hidden from the public SDK, so they must be plain strings.
        const val ACTION_BATTERY_LEVEL_CHANGED = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY_LEVEL = "android.bluetooth.device.extra.BATTERY_LEVEL"
    }
}
