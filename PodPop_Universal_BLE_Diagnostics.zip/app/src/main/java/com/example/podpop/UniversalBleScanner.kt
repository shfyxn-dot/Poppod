package com.example.podpop

import android.Manifest
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.SparseArray
import java.util.UUID

/**
 * Diagnostic-only unfiltered BLE scanner. It does not infer lid state or battery values.
 * Apple-format decoding remains in ProximityScanner and is intentionally separate.
 */
class UniversalBleScanner(private val context: Context, private val onReport: (String) -> Unit) {
    private var leScanner: BluetoothLeScanner? = null
    var running = false
        private set
    private val seen = LinkedHashMap<String, String>()

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) = handle(result)
        override fun onBatchScanResults(results: MutableList<ScanResult>) { results.forEach { handle(it) } }
        override fun onScanFailed(errorCode: Int) {
            onReport("SCAN FAILED: $errorCode\n${scanError(errorCode)}")
            running = false
        }
    }

    fun start(): Boolean {
        if (running) return true
        if (!hasPermission(context)) {
            onReport("Permission missing: Nearby devices / Bluetooth scan.")
            return false
        }
        return try {
            val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
            if (adapter == null || !adapter.isEnabled) {
                onReport("Bluetooth is OFF or unavailable.")
                return false
            }
            val scanner = adapter.bluetoothLeScanner ?: run {
                onReport("BLE scanner unavailable on this device.")
                return false
            }
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(0)
                .build()
            // Empty filter list means discover advertisements from all manufacturers/services.
            scanner.startScan(emptyList<ScanFilter>(), settings, callback)
            leScanner = scanner
            running = true
            seen.clear()
            onReport("Scanning all BLE advertisements…\nKeep the case close to the phone.")
            true
        } catch (e: SecurityException) {
            onReport("Permission denied: ${e.message ?: "Bluetooth scan permission"}")
            false
        } catch (e: Exception) {
            onReport("Could not start scan: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    private fun handle(result: ScanResult) {
        val record = result.scanRecord ?: return
        val sb = StringBuilder()
        val name = record.deviceName ?: try { result.device.name } catch (_: Exception) { null }
        sb.append("Name: ").append(name ?: "(not advertised)").append('\n')
        val address = try { result.device.address } catch (_: Exception) { "(unavailable)" }
        sb.append("Address: ").append(address).append('\n')
        sb.append("RSSI: ").append(result.rssi).append(" dBm\n")
        sb.append("Manufacturer data:\n")
        val m: SparseArray<ByteArray> = record.manufacturerSpecificData
        if (m.size() == 0) sb.append("  (none)\n")
        for (i in 0 until m.size()) {
            val id = m.keyAt(i)
            sb.append("  ID 0x").append("%04X".format(id)).append(": ")
                .append(hex(m.valueAt(i))).append('\n')
        }
        sb.append("Service UUIDs: ")
        sb.append(record.serviceUuids?.joinToString { it.uuid.toString() } ?: "(none)").append('\n')
        sb.append("Service data:\n")
        val sd = record.serviceData
        if (sd.isNullOrEmpty()) sb.append("  (none)\n") else sd.forEach { (uuid, bytes) ->
            sb.append("  ").append(uuid.uuid).append(": ").append(hex(bytes)).append('\n')
        }
        sb.append("Raw advertisement: ").append(hex(record.bytes ?: byteArrayOf()))
        val key = "$address|${record.deviceName}|${m.size()}|${record.serviceUuids}"
        synchronized(seen) {
            seen[key] = sb.toString()
            while (seen.size > 12) seen.remove(seen.keys.first())
            onReport("Devices/signatures: ${seen.size}\n\n" + seen.values.toList().asReversed().joinToString("\n\n--------------------\n\n"))
        }
    }

    fun stop() {
        if (!running) return
        running = false
        try { leScanner?.stopScan(callback) } catch (_: Exception) { }
        leScanner = null
    }

    private fun hex(bytes: ByteArray): String = bytes.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
    private fun scanError(code: Int) = when (code) {
        ScanCallback.SCAN_FAILED_ALREADY_STARTED -> "Scan already started"
        ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED -> "App registration failed"
        ScanCallback.SCAN_FAILED_FEATURE_UNSUPPORTED -> "BLE scanning unsupported"
        ScanCallback.SCAN_FAILED_INTERNAL_ERROR -> "Android Bluetooth stack internal error"
        ScanCallback.SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES -> "Bluetooth hardware resources exhausted"
        else -> "Unknown BLE scan error"
    }

    companion object {
        fun hasPermission(context: Context): Boolean =
            if (Build.VERSION.SDK_INT >= 31)
                context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
            else context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }
}
