package com.example.podpop

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.io.IOException
import java.io.InputStream

/** Keeps the user's chosen popup wallpaper (PNG / JPG / GIF / MP4) in the app's private storage. */
object WallpaperStore {
    data class Info(val path: String, val kind: String)   // kind: "image", "gif" or "video"

    private const val FILE = "podpop_wallpaper"
    private const val KEY_PATH = "path"
    private const val KEY_KIND = "kind"
    private const val KEY_FLOAT = "float"
    private const val KEY_X = "pos_x"
    private const val KEY_Y = "pos_y"
    private const val KEY_ZOOM = "zoom"
    private const val KEY_SIZE = "airpods_size"
    private const val KEY_POSTER = "poster"
    private const val KEY_NOTE = "note"
    private const val MAX_BYTES = 80L * 1024L * 1024L

    private fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun current(c: Context): Info? {
        val path = prefs(c).getString(KEY_PATH, null) ?: return null
        val kind = prefs(c).getString(KEY_KIND, "image") ?: "image"
        return if (File(path).exists()) Info(path, kind) else null
    }

    /** Whether the floating AirPods image is drawn on top of the wallpaper. */
    fun floatOverWallpaper(c: Context): Boolean = prefs(c).getBoolean(KEY_FLOAT, true)

    /** Which part of the wallpaper is shown: 0..100 left-to-right / top-to-bottom, zoom 100..300 (%). */
    fun posX(c: Context): Int = prefs(c).getInt(KEY_X, 50)
    fun posY(c: Context): Int = prefs(c).getInt(KEY_Y, 50)
    fun zoom(c: Context): Int = prefs(c).getInt(KEY_ZOOM, 100)

    fun setFit(c: Context, x: Int, y: Int, zoom: Int) {
        prefs(c).edit().putInt(KEY_X, x).putInt(KEY_Y, y).putInt(KEY_ZOOM, zoom).apply()
    }

    /** Size of the floating AirPods picture in percent (60..120). Works with and without wallpaper. */
    const val SIZE_MIN = 60
    const val SIZE_MAX = 120
    fun airpodsSize(c: Context): Int = prefs(c).getInt(KEY_SIZE, 100).coerceIn(SIZE_MIN, SIZE_MAX)
    fun setAirpodsSize(c: Context, percent: Int) {
        prefs(c).edit().putInt(KEY_SIZE, percent.coerceIn(SIZE_MIN, SIZE_MAX)).apply()
    }

    /** A small still picture of the first video frame, shown instantly while the video starts. */
    fun posterPath(c: Context): String? {
        val path = prefs(c).getString(KEY_POSTER, null) ?: return null
        return if (File(path).exists()) path else null
    }

    /** A short tip about the imported file (for example "large video"), or null. */
    fun note(c: Context): String? = prefs(c).getString(KEY_NOTE, null)

    /** Makes the still picture for a video wallpaper if it does not exist yet. Call off the main thread. */
    fun ensurePoster(c: Context) {
        val info = current(c) ?: return
        if (info.kind != "video" || posterPath(c) != null) return
        val file = File(c.filesDir, "poster_" + System.currentTimeMillis() + ".jpg")
        if (makePoster(info.path, file)) prefs(c).edit().putString(KEY_POSTER, file.absolutePath).apply()
    }

    private fun makePoster(videoPath: String, out: File): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(videoPath)
            val frame = r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return false
            val longSide = kotlin.math.max(frame.width, frame.height)
            val small = if (longSide > 1280) {
                val f = 1280f / longSide
                Bitmap.createScaledBitmap(frame, (frame.width * f).toInt(), (frame.height * f).toInt(), true)
            } else frame
            out.outputStream().use { small.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Exception) {
            out.delete()
            false
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    private fun videoNote(path: String, bytes: Long): String? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val big = kotlin.math.max(w, h) > 1920 || bytes > 40L * 1024L * 1024L
            if (big) "This video is large. It plays best at 1080p or smaller (under 30 MB)." else null
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    fun setFloatOverWallpaper(c: Context, value: Boolean) {
        prefs(c).edit().putBoolean(KEY_FLOAT, value).apply()
    }

    fun clear(c: Context) {
        val old = prefs(c).getString(KEY_PATH, null)
        if (old != null) File(old).delete()
        val oldPoster = prefs(c).getString(KEY_POSTER, null)
        if (oldPoster != null) File(oldPoster).delete()
        prefs(c).edit().remove(KEY_PATH).remove(KEY_KIND).remove(KEY_X).remove(KEY_Y).remove(KEY_ZOOM)
            .remove(KEY_POSTER).remove(KEY_NOTE).apply()
    }

    /** Copies the picked file into the app. Returns an error message, or null on success. */
    fun import(c: Context, uri: Uri): String? {
        val mime = c.contentResolver.getType(uri) ?: ""
        val kind: String
        val ext: String
        if (mime.startsWith("video/")) {
            kind = "video"
            ext = "mp4"
        } else if (mime == "image/gif") {
            kind = "gif"
            ext = "gif"
        } else if (mime == "image/webp") {
            kind = "gif"
            ext = "webp"
        } else if (mime.startsWith("image/")) {
            kind = "image"
            ext = "img"
        } else {
            return "Please choose a PNG, JPG, GIF or MP4 file"
        }

        val out = File(c.filesDir, "wallpaper_" + System.currentTimeMillis() + "." + ext)
        val input: InputStream? = try {
            c.contentResolver.openInputStream(uri)
        } catch (e: Exception) {
            null
        }
        if (input == null) return "Could not open that file"

        var failure: String? = null
        try {
            input.use { source ->
                out.outputStream().use { sink ->
                    val buffer = ByteArray(256 * 1024)
                    var total = 0L
                    while (true) {
                        val n = source.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > MAX_BYTES) throw IOException("too big")
                        sink.write(buffer, 0, n)
                    }
                }
            }
        } catch (e: IOException) {
            failure = if (e.message == "too big") "File is larger than 80 MB" else "Could not copy that file"
        } catch (e: Exception) {
            failure = "Could not copy that file"
        }
        if (failure != null) {
            out.delete()
            return failure
        }

        // Still picture + size tip for videos (done here, in the background, so the popup starts fast).
        var poster: File? = null
        var note: String? = null
        if (kind == "video") {
            val p = File(c.filesDir, "poster_" + System.currentTimeMillis() + ".jpg")
            if (makePoster(out.absolutePath, p)) poster = p
            note = videoNote(out.absolutePath, out.length())
        }

        val old = prefs(c).getString(KEY_PATH, null)
        val oldPoster = prefs(c).getString(KEY_POSTER, null)
        prefs(c).edit().putString(KEY_PATH, out.absolutePath).putString(KEY_KIND, kind)
            .putString(KEY_POSTER, poster?.absolutePath).putString(KEY_NOTE, note)
            .putInt(KEY_X, 50).putInt(KEY_Y, 50).putInt(KEY_ZOOM, 100).apply()
        if (old != null && old != out.absolutePath) File(old).delete()
        if (oldPoster != null) File(oldPoster).delete()
        return null
    }
}
