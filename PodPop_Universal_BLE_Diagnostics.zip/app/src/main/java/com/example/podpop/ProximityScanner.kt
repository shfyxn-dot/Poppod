package com.example.podpop

import android.Manifest
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/**
 * Optional "nearby AirPods" detection.
 *
 * When AirPods (or their case) are opened close to a phone they broadcast a small Bluetooth LE
 * message (Apple company id 0x004C, type 0x07) that iPhones use for their popup. Android ignores it,
 * so this listens for it. It only reads that public broadcast: nothing is connected, stored or sent.
 * Battery values are used only when the message really contains them (0..10 = 0..100 %, 15 = unknown).
 */
class ProximityScanner(private val context: Context, private val onReading: (Reading) -> Unit) {

    data class Reading(
        val model: Int,
        val left: Int,      // 0..100, or -1 when unknown
        val right: Int,
        val case: Int,
        val rssi: Int,
        val raw: String
    )

    private var scanner: BluetoothLeScanner? = null
    var running = false
        private set

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            handle(result)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            for (r in results) handle(r)
        }
    }

    fun start(): Boolean {
        if (running) return true
        if (!hasPermission(context)) return false
        return try {
            val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
            if (adapter == null || !adapter.isEnabled) return false
            val le = adapter.bluetoothLeScanner ?: return false
            val filter = ScanFilter.Builder()
                .setManufacturerData(APPLE_ID, byteArrayOf(0x07), byteArrayOf(0xFF.toByte()))
                .build()
            val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_BALANCED).build()
            le.startScan(listOf(filter), settings, callback)
            scanner = le
            running = true
            true
        } catch (e: Exception) {
            running = false
            false
        }
    }

    fun stop() {
        if (!running) return
        running = false
        try { scanner?.stopScan(callback) } catch (e: Exception) { }
        scanner = null
    }

    private fun handle(result: ScanResult) {
        val data = result.scanRecord?.getManufacturerSpecificData(APPLE_ID) ?: return
        if (data.size < 8 || data[0] != 0x07.toByte()) return
        val b6 = data[6].toInt() and 0xFF
        val b7 = data[7].toInt() and 0xFF
        val model = ((data[4].toInt() and 0xFF) shl 8) or (data[3].toInt() and 0xFF)
        val hex = StringBuilder()
        for (i in 0 until minOf(data.size, 12)) hex.append(String.format("%02X ", data[i].toInt() and 0xFF))
        onReading(
            Reading(model, level(b6 shr 4), level(b6 and 0x0F), level(b7 and 0x0F), result.rssi, hex.toString().trim())
        )
    }

    private fun level(nibble: Int): Int = if (nibble in 0..10) nibble * 10 else -1

    companion object {
        private const val APPLE_ID = 0x004C

        /** Android 12+ needs "Nearby devices"; older versions need Location. */
        fun permissionName(): String =
            if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_SCAN
            else Manifest.permission.ACCESS_FINE_LOCATION

        fun hasPermission(context: Context): Boolean =
            context.checkSelfPermission(permissionName()) == PackageManager.PERMISSION_GRANTED
    }
}
