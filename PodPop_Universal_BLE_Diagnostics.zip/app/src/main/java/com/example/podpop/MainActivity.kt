package com.example.podpop

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Toast
import android.widget.TextView

class MainActivity : Activity() {
    private var pendingTest = false
    private val statusView: TextView by lazy { TextView(this) }
    private val wallpaperView: TextView by lazy { TextView(this) }
    private lateinit var floatButton: Button
    private lateinit var previewHolder: FrameLayout
    private var previewView: PodPopupView? = null
    private val noteView: TextView by lazy { TextView(this) }
    private var mutedColor = Color.GRAY
    private val fitSliders = ArrayList<View>()
    private lateinit var seekX: SeekBar
    private lateinit var seekY: SeekBar
    private lateinit var seekZoom: SeekBar
    private lateinit var seekSize: SeekBar
    private lateinit var step1: Button
    private lateinit var step2: Button
    private lateinit var step4: Button
    private lateinit var durationButton: Button
    private lateinit var hapticButton: Button
    private lateinit var nearbyButton: Button
    private lateinit var scanTestButton: Button
    private val scanView: TextView by lazy { TextView(this) }
    private var testScanner: UniversalBleScanner? = null
    private var testSeen = 0
    private val reqWallpaper = 21

    private fun refreshWallpaperUi() {
        val info = WallpaperStore.current(this)
        wallpaperView.text = when (info?.kind) {
            null -> "Wallpaper: default (floating AirPods)"
            "video" -> "Wallpaper: video (loops, muted)"
            "gif" -> "Wallpaper: animated image"
            else -> "Wallpaper: picture"
        }
        val on = WallpaperStore.floatOverWallpaper(this)
        floatButton.text = "Floating AirPods on wallpaper: " + (if (on) "ON" else "OFF")

        val note = WallpaperStore.note(this)
        noteView.text = note ?: ""
        noteView.visibility = if (note != null && info != null) View.VISIBLE else View.GONE
        for (v in fitSliders) v.visibility = if (info != null) View.VISIBLE else View.GONE

        // Make the video's still picture if needed (background), then draw the live preview.
        Thread {
            WallpaperStore.ensurePoster(this)
            runOnUiThread { if (!isDestroyed) rebuildPreview() }
        }.start()
    }

    private fun rebuildPreview() {
        previewView?.let { previewHolder.removeView(it) }
        val v = PodPopupView(this, -1, true, true) { }
        previewView = v
        previewHolder.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
    }

    /** Label + slider. Returns the slider; [onChange] gets the real value (min..max). */
    private fun addSlider(root: LinearLayout, label: String, min: Int, max: Int, value: Int,
                          fitGroup: Boolean, onChange: (Int) -> Unit): SeekBar {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(2))
        val text = TextView(this)
        text.textSize = 13f
        text.setTextColor(mutedColor)
        text.text = label
        box.addView(text)
        val bar = SeekBar(this)
        bar.max = max - min
        bar.progress = value - min
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(min + progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(bar)
        root.addView(box, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        if (fitGroup) fitSliders.add(box)
        return bar
    }

    private fun fitChanged() {
        WallpaperStore.setFit(this, seekX.progress, seekY.progress, 100 + seekZoom.progress)
        previewView?.reloadFit()
    }

    @Suppress("DEPRECATION")
    private fun isServiceRunning(): Boolean {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        return am.getRunningServices(Int.MAX_VALUE).any { it.service.className == MonitorService::class.java.name }
    }

    private fun refreshStatus() {
        if (isServiceRunning()) {
            statusView.text = "● PodPop is running"
            statusView.setTextColor(Color.rgb(48, 209, 88))
        } else {
            statusView.text = "● PodPop is stopped"
            statusView.setTextColor(Color.rgb(255, 159, 10))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshSetup()
    }

    /** Ticks next to each setup step once Android says it is done. */
    private fun refreshSetup() {
        val overlay = Settings.canDrawOverlays(this)
        val bt = Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        val battery = pm.isIgnoringBatteryOptimizations(packageName)
        step1.text = (if (overlay) "✓  " else "") + "1. Allow display over other apps"
        step2.text = (if (bt) "✓  " else "") + "2. Allow Bluetooth access"
        step4.text = (if (battery) "✓  " else "") + "4. Allow background activity (battery)"
        durationButton.text = "Popup stays for: " + PodPrefs.popupSeconds(this) + " seconds"
        hapticButton.text = "Vibrate when popup appears: " + (if (PodPrefs.haptic(this)) "ON" else "OFF")
        nearbyButton.text = "Nearby AirPods detection (optional): " +
            (if (PodPrefs.nearby(this) && ProximityScanner.hasPermission(this)) "ON" else "OFF")
    }

    private fun applyNearby(on: Boolean) {
        PodPrefs.setNearby(this, on)
        PodPrefs.setAutoStart(this, true)
        startForegroundService(Intent(this, MonitorService::class.java))
        refreshSetup()
        statusView.postDelayed({ refreshStatus() }, 600)
    }

    private fun fmt(v: Int) = if (v >= 0) "$v%" else "?"

    private fun toggleScanTest() {
        val running = testScanner
        if (running != null) {
            running.stop()
            testScanner = null
            scanTestButton.text = "Universal BLE scan test"
            scanView.text = "Scan stopped. Compare the saved reports for case closed and case open."
            return
        }
        if (!UniversalBleScanner.hasPermission(this)) {
            val permission = if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_SCAN
                else Manifest.permission.ACCESS_FINE_LOCATION
            requestPermissions(arrayOf(permission), 14)
            return
        }
        val s = UniversalBleScanner(this) { report ->
            runOnUiThread { scanView.text = report }
        }
        if (s.start()) {
            testScanner = s
            scanTestButton.text = "Stop universal BLE scan"
        } else {
            scanView.text = "Could not start scan. Check Bluetooth and Nearby devices permission."
            Toast.makeText(this, "Check Bluetooth and scan permission", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
        testScanner?.stop()
        testScanner = null
        if (::scanTestButton.isInitialized) scanTestButton.text = "Scan test: check my AirPods signal"
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val foreground = if (isDark) Color.WHITE else Color.rgb(30, 30, 34)
        val muted = if (isDark) Color.rgb(170, 170, 178) else Color.rgb(100, 100, 108)
        val background = if (isDark) Color.rgb(12, 12, 14) else Color.rgb(248, 248, 250)
        mutedColor = muted

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(20), dp(28), dp(20), dp(24))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.podpop_logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        logo.contentDescription = "PodPop logo"
        val logoLp = LinearLayout.LayoutParams(dp(110), dp(110))
        logoLp.bottomMargin = dp(10)
        root.addView(logo, logoLp)

        val title = TextView(this)
        title.text = "PodPop"
        title.textSize = 30f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(foreground)
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "A premium AirPods connection popup."
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER
        subtitle.setTextColor(muted)
        subtitle.setPadding(0, dp(6), 0, dp(20))
        root.addView(subtitle)

        statusView.textSize = 14f
        statusView.gravity = Gravity.CENTER
        statusView.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        statusView.setPadding(0, 0, 0, dp(14))
        root.addView(statusView)

        step1 = addAction(root, "1. Allow display over other apps", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        step2 = addAction(root, "2. Allow Bluetooth access", false) {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12)
            } else {
                startMonitor()
            }
        }
        addAction(root, "3. Start PodPop", false) { startMonitor() }
        step4 = addAction(root, "4. Allow background activity (battery)", false) {
            try {
                // One-tap system prompt: "Allow PodPop to always run in the background?"
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e2: Exception) {
                    // Settings screen not available on this phone.
                }
            }
        }
        addAction(root, "Test popup now", true) { startMonitor(true) }

        durationButton = addAction(root, "Popup time", false) {
            val options = intArrayOf(3, 6, 10, 15)
            val next = options[(options.indexOf(PodPrefs.popupSeconds(this)) + 1) % options.size]
            PodPrefs.setPopupSeconds(this, next)
            refreshSetup()
        }
        hapticButton = addAction(root, "Vibrate", false) {
            PodPrefs.setHaptic(this, !PodPrefs.haptic(this))
            refreshSetup()
        }

        // ----- Optional: nearby AirPods (case opened, not connected yet) -----
        nearbyButton = addAction(root, "Nearby AirPods detection", false) {
            if (PodPrefs.nearby(this) && ProximityScanner.hasPermission(this)) {
                applyNearby(false)
            } else if (!ProximityScanner.hasPermission(this)) {
                requestPermissions(arrayOf(ProximityScanner.permissionName()), 13)
            } else {
                applyNearby(true)
            }
        }
        scanTestButton = addAction(root, "Universal BLE scan test", false) { toggleScanTest() }
        scanView.textSize = 12f
        scanView.setTextColor(muted)
        scanView.setPadding(dp(4), 0, dp(4), dp(10))
        scanView.text = "Nearby detection shows the popup when your AirPods case is opened close to the phone, " +
            "even before they connect. Use the scan test first: it shows whether your AirPods send this signal."
        root.addView(scanView)

        // ----- Popup wallpaper -----
        wallpaperView.textSize = 13f
        wallpaperView.gravity = Gravity.CENTER
        wallpaperView.setTextColor(muted)
        wallpaperView.setPadding(0, dp(14), 0, dp(8))
        root.addView(wallpaperView)

        previewHolder = FrameLayout(this)
        previewHolder.clipChildren = false
        root.addView(previewHolder, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        addAction(root, "Choose popup wallpaper (PNG / GIF / MP4)", false) {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
            pick.addCategory(Intent.CATEGORY_OPENABLE)
            pick.type = "*/*"
            pick.putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("image/png", "image/jpeg", "image/gif", "image/webp", "video/mp4")
            )
            startActivityForResult(pick, reqWallpaper)
        }

        noteView.textSize = 12f
        noteView.setTextColor(Color.rgb(255, 159, 10))
        noteView.setPadding(dp(4), 0, dp(4), dp(8))
        root.addView(noteView)

        // Which part of the wallpaper is used (only shown while a wallpaper is set).
        seekX = addSlider(root, "Wallpaper position: left  ↔  right", 0, 100, WallpaperStore.posX(this), true) { fitChanged() }
        seekY = addSlider(root, "Wallpaper position: top  ↔  bottom", 0, 100, WallpaperStore.posY(this), true) { fitChanged() }
        seekZoom = addSlider(root, "Wallpaper zoom (zoom in to move up/down)", 0, 200, WallpaperStore.zoom(this) - 100, true) { fitChanged() }
        val resetFit = addAction(root, "Reset wallpaper position", false) {
            seekX.progress = 50
            seekY.progress = 50
            seekZoom.progress = 0
            fitChanged()
        }
        fitSliders.add(resetFit)

        seekSize = addSlider(root, "AirPods size", WallpaperStore.SIZE_MIN, WallpaperStore.SIZE_MAX,
            WallpaperStore.airpodsSize(this), false) { v ->
            WallpaperStore.setAirpodsSize(this, v)
            previewView?.applySize()
        }

        floatButton = addAction(root, "Floating AirPods on wallpaper", false) {
            WallpaperStore.setFloatOverWallpaper(this, !WallpaperStore.floatOverWallpaper(this))
            refreshWallpaperUi()
        }
        addAction(root, "Use default look (remove wallpaper)", false) {
            WallpaperStore.clear(this)
            refreshWallpaperUi()
            Toast.makeText(this, "Default popup restored", Toast.LENGTH_SHORT).show()
        }
        addAction(root, "Preview popup (no earbuds needed)", true) { startPreview() }
        refreshWallpaperUi()
        refreshSetup()

        val spacer = TextView(this)
        spacer.setPadding(0, dp(6), 0, 0)
        root.addView(spacer)
        addAction(root, "Stop PodPop", false, Color.rgb(176, 48, 48)) {
            PodPrefs.setAutoStart(this, false)
            stopService(Intent(this, MonitorService::class.java))
            statusView.postDelayed({ refreshStatus() }, 400)
        }

        val info = TextView(this)
        info.text = "Selected device: AirPods Pro\nBluetooth ID: 41:42:84:7B:08:D6\n\n" +
            "Battery is shown only when Android receives it from your earbuds. " +
            "The case battery is shown as empty because these earbuds don't report it."
        info.textSize = 13f
        info.setTextColor(Color.rgb(145, 145, 153))
        info.setPadding(dp(2), dp(18), dp(2), 0)
        root.addView(info)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(background)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addAction(root: LinearLayout, label: String, primary: Boolean, tint: Int = 0, action: () -> Unit): Button {
        val button = Button(this)
        button.text = label
        button.isAllCaps = false
        button.textSize = 14f
        button.setTextColor(if (primary) Color.WHITE else Color.rgb(235, 235, 240))
        button.backgroundTintList = ColorStateList.valueOf(
            if (tint != 0) tint else if (primary) Color.rgb(48, 112, 245) else Color.rgb(58, 58, 64)
        )
        button.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
        lp.bottomMargin = dp(9)
        root.addView(button, lp)
        return button
    }

    private fun startPreview() {
        PodPrefs.setAutoStart(this, true)
        val i = Intent(this, MonitorService::class.java).putExtra(MonitorService.EXTRA_PREVIEW, true)
        startForegroundService(i)
        statusView.postDelayed({ refreshStatus() }, 600)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == reqWallpaper && resultCode == RESULT_OK && uri != null) {
            Toast.makeText(this, "Importing wallpaper… please wait", Toast.LENGTH_SHORT).show()
            Thread {
                val error = WallpaperStore.import(this, uri)
                runOnUiThread {
                    seekX.progress = WallpaperStore.posX(this)
                    seekY.progress = WallpaperStore.posY(this)
                    seekZoom.progress = WallpaperStore.zoom(this) - 100
                    refreshWallpaperUi()
                    Toast.makeText(
                        this,
                        error ?: "Wallpaper saved. Use the sliders to choose which part shows.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }.start()
        }
    }

    private fun startMonitor(test: Boolean = false) {
        pendingTest = test
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12)
            return
        }
        PodPrefs.setAutoStart(this, true)
        val i = Intent(this, MonitorService::class.java).putExtra(MonitorService.EXTRA_TEST, test)
        startForegroundService(i)
        statusView.postDelayed({ refreshStatus() }, 600)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (requestCode == 12 && granted) startMonitor(pendingTest)
        if (requestCode == 13 && granted) applyNearby(true)
        if (requestCode == 14 && granted) toggleScanTest()
        refreshSetup()
    }
}
