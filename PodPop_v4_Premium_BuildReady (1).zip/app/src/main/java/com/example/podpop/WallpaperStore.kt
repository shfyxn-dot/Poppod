package com.example.podpop

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.IOException
import java.io.InputStream

/** Keeps the user's chosen popup wallpaper (PNG / JPG / GIF / MP4) in the app's private storage. */
object WallpaperStore {
    data class Info(val path: String, val kind: String)   // kind: "image", "gif" or "video"

    private const val FILE = "podpop_wallpaper"
    private const val KEY_PATH = "path"
    private const val KEY_KIND = "kind"
    private const val KEY_FLOAT = "float"
    private const val MAX_BYTES = 80L * 1024L * 1024L

    private fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun current(c: Context): Info? {
        val path = prefs(c).getString(KEY_PATH, null) ?: return null
        val kind = prefs(c).getString(KEY_KIND, "image") ?: "image"
        return if (File(path).exists()) Info(path, kind) else null
    }

    /** Whether the floating AirPods image is drawn on top of the wallpaper. */
    fun floatOverWallpaper(c: Context): Boolean = prefs(c).getBoolean(KEY_FLOAT, false)

    fun setFloatOverWallpaper(c: Context, value: Boolean) {
        prefs(c).edit().putBoolean(KEY_FLOAT, value).apply()
    }

    fun clear(c: Context) {
        val old = prefs(c).getString(KEY_PATH, null)
        if (old != null) File(old).delete()
        prefs(c).edit().remove(KEY_PATH).remove(KEY_KIND).apply()
    }

    /** Copies the picked file into the app. Returns an error message, or null on success. */
    fun import(c: Context, uri: Uri): String? {
        val mime = c.contentResolver.getType(uri) ?: ""
        val kind: String
        val ext: String
        if (mime.startsWith("video/")) {
            kind = "video"
            ext = "mp4"
        } else if (mime == "image/gif") {
            kind = "gif"
            ext = "gif"
        } else if (mime == "image/webp") {
            kind = "gif"
            ext = "webp"
        } else if (mime.startsWith("image/")) {
            kind = "image"
            ext = "img"
        } else {
            return "Please choose a PNG, JPG, GIF or MP4 file"
        }

        val out = File(c.filesDir, "wallpaper_" + System.currentTimeMillis() + "." + ext)
        val input: InputStream? = try {
            c.contentResolver.openInputStream(uri)
        } catch (e: Exception) {
            null
        }
        if (input == null) return "Could not open that file"

        var failure: String? = null
        try {
            input.use { source ->
                out.outputStream().use { sink ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = source.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > MAX_BYTES) throw IOException("too big")
                        sink.write(buffer, 0, n)
                    }
                }
            }
        } catch (e: IOException) {
            failure = if (e.message == "too big") "File is larger than 80 MB" else "Could not copy that file"
        } catch (e: Exception) {
            failure = "Could not copy that file"
        }
        if (failure != null) {
            out.delete()
            return failure
        }

        val old = prefs(c).getString(KEY_PATH, null)
        prefs(c).edit().putString(KEY_PATH, out.absolutePath).putString(KEY_KIND, kind).apply()
        if (old != null && old != out.absolutePath) File(old).delete()
        return null
    }
}
