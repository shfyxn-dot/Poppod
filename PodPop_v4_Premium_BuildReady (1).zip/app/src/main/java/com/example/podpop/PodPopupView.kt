package com.example.podpop

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.os.Build
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/**
 * Bottom connection popup styled like the iOS AirPods card.
 *
 * Two looks:
 *  - Default: gradient card, name on top, floating AirPods cut-out, batteries at the bottom.
 *  - Wallpaper: the user's PNG / GIF / MP4 fills the whole popup (video loops, muted). The AirPods
 *    cut-out floats on top only if the user turned that option on.
 * Battery values are shown only when Android reports them; the case level is never reported by
 * these earbuds, so it is always shown as empty.
 */
class PodPopupView(
    context: Context,
    initialBattery: Int,
    private val preview: Boolean,
    private val onClose: () -> Unit
) : FrameLayout(context) {

    private val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val wallpaper: WallpaperStore.Info? = WallpaperStore.current(context)
    private val onWallpaper = wallpaper != null

    private val card = FrameLayout(context)
    private val earBattery = BatteryView(context, dark || onWallpaper)
    private val earText = TextView(context)
    private var floatAnimator: ValueAnimator? = null
    private var floatTarget: View? = null

    // Wallpaper playback
    private var player: MediaPlayer? = null
    private var textureView: TextureView? = null
    private var videoW = 0
    private var videoH = 0
    private var animatedDrawable: Drawable? = null

    init {
        setPadding(dp(10f), dp(10f), dp(10f), dp(22f))
        clipToPadding = false
        clipChildren = false

        card.background = GradientDrawable().apply {
            setColor(if (onWallpaper) Color.BLACK else if (dark) Color.rgb(46, 45, 51) else Color.rgb(247, 247, 249))
            cornerRadius = dp(30f).toFloat()
            setStroke(dp(1f), if (dark || onWallpaper) 0x26FFFFFF else 0x14000000)
        }
        card.elevation = dp(12f).toFloat()
        card.clipToOutline = true

        if (onWallpaper) buildWallpaperCard() else buildDefaultCard()

        // --- Close button (top right) ---
        val close = CloseButton(context)
        close.contentDescription = "Close popup"
        close.isClickable = true
        close.setOnClickListener { onClose() }
        card.addView(close, LayoutParams(dp(48f), dp(48f), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(8f)
            rightMargin = dp(8f)
        })

        addView(card, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        setBattery(initialBattery)
    }

    // ---------- shared pieces ----------

    private fun headline(color: Int): TextView = TextView(context).apply {
        text = "AirPods Pro 2"
        textSize = 20f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(48f), dp(26f), dp(48f), 0)
    }

    private fun subline(color: Int): TextView = TextView(context).apply {
        text = if (preview) "Preview" else "Connected"
        textSize = 13f
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(0, dp(2f), 0, dp(6f))
    }

    private fun cutoutImage(): ImageView {
        val image = ImageView(context)
        image.setImageResource(R.drawable.pro2_cutout)
        image.adjustViewBounds = true
        image.scaleType = ImageView.ScaleType.FIT_CENTER
        image.contentDescription = "AirPods and charging case"
        floatTarget = image
        return image
    }

    /** "Earbuds [battery] 96%" and "Case [empty battery] —", side by side. */
    private fun batteryRow(valueColor: Int, labelColor: Int, dark: Boolean, topPad: Int, bottomPad: Int): LinearLayout {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.setPadding(dp(12f), topPad, dp(12f), bottomPad)

        earText.textSize = 17f
        earText.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        earText.setTextColor(valueColor)
        earText.setPadding(dp(8f), 0, 0, 0)
        row.addView(batteryItem("Earbuds", earBattery, earText, labelColor))

        val caseBattery = BatteryView(context, dark)
        val caseText = TextView(context)
        caseText.text = "—"
        caseText.textSize = 17f
        caseText.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        caseText.setTextColor(labelColor)
        caseText.setPadding(dp(8f), 0, 0, 0)
        val lp = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(26f)
        row.addView(batteryItem("Case", caseBattery, caseText, labelColor), lp)
        return row
    }

    private fun batteryItem(label: String, battery: BatteryView, value: TextView, labelColor: Int): LinearLayout {
        val item = LinearLayout(context)
        item.orientation = LinearLayout.HORIZONTAL
        item.gravity = Gravity.CENTER_VERTICAL
        val name = TextView(context)
        name.text = label
        name.textSize = 13f
        name.setTextColor(labelColor)
        name.setPadding(0, 0, dp(8f), 0)
        item.addView(name)
        item.addView(battery, LinearLayout.LayoutParams(dp(36f), dp(17f)))
        item.addView(value)
        return item
    }

    // ---------- default look ----------

    private fun buildDefaultCard() {
        val cardColor = if (dark) Color.rgb(46, 45, 51) else Color.rgb(247, 247, 249)
        val primary = if (dark) Color.WHITE else Color.rgb(28, 28, 32)
        val secondary = if (dark) Color.rgb(165, 165, 173) else Color.rgb(110, 110, 118)

        val column = LinearLayout(context)
        column.orientation = LinearLayout.VERTICAL

        val title = headline(primary)
        val subtitle = subline(if (dark) Color.rgb(190, 190, 198) else secondary)

        // The backdrop lives on the hero panel; only the transparent cut-out floats above it,
        // so no edge of the picture ever slides against the card.
        val imageFrame = FrameLayout(context)
        imageFrame.clipChildren = false
        imageFrame.setPadding(0, dp(18f), 0, dp(22f))
        imageFrame.addView(cutoutImage(), LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        if (dark) {
            val hero = LinearLayout(context)
            hero.orientation = LinearLayout.VERTICAL
            hero.clipChildren = false
            hero.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(70, 69, 75), cardColor)
            )
            hero.addView(title)
            hero.addView(subtitle)
            hero.addView(imageFrame, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
            column.addView(hero, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        } else {
            column.addView(title)
            column.addView(subtitle)
            val panel = FrameLayout(context)
            panel.clipChildren = false
            panel.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(70, 69, 75), Color.rgb(54, 53, 59))
            )
            panel.clipToOutline = true
            panel.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(20f).toFloat())
                }
            }
            panel.addView(imageFrame, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
            val lp = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(12f), dp(4f), dp(12f), 0)
            column.addView(panel, lp)
        }

        column.addView(batteryRow(primary, secondary, dark, dp(12f), dp(30f)))
        card.addView(column, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    // ---------- wallpaper look ----------

    private fun buildWallpaperCard() {
        val info = wallpaper ?: return
        val white = Color.WHITE
        val softWhite = Color.argb(210, 255, 255, 255)

        // Layer 0: the wallpaper itself.
        try {
            if (info.kind == "video") addVideo(info.path) else addPicture(info.path, info.kind == "gif")
        } catch (e: Exception) {
            // Falls back to the plain black card if the file cannot be shown.
        }

        // Layer 1: soft shading so the text stays readable on any wallpaper.
        val scrim = View(context)
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(120, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(170, 0, 0, 0))
        )
        card.addView(scrim, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        // Layer 2: name on top, optional floating AirPods in the middle, batteries at the bottom.
        val content = LinearLayout(context)
        content.orientation = LinearLayout.VERTICAL
        content.addView(headline(white))
        content.addView(subline(softWhite))

        val middle = FrameLayout(context)
        middle.clipChildren = false
        if (WallpaperStore.floatOverWallpaper(context)) {
            middle.addView(cutoutImage(), LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        content.addView(middle, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        content.addView(batteryRow(white, softWhite, true, dp(6f), dp(26f)))
        card.addView(content, LayoutParams(LayoutParams.MATCH_PARENT, dp(330f)))
    }

    private fun addPicture(path: String, animated: Boolean) {
        val view = ImageView(context)
        view.scaleType = ImageView.ScaleType.CENTER_CROP
        var shown = false
        if (animated && Build.VERSION.SDK_INT >= 28) {
            try {
                val drawable = ImageDecoder.decodeDrawable(ImageDecoder.createSource(File(path)))
                view.setImageDrawable(drawable)
                if (drawable is AnimatedImageDrawable) {
                    drawable.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    drawable.start()
                    animatedDrawable = drawable
                }
                shown = true
            } catch (e: Exception) {
                shown = false
            }
        }
        if (!shown) {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1400) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bitmap = BitmapFactory.decodeFile(path, opts)
            if (bitmap != null) view.setImageBitmap(bitmap)
        }
        card.addView(view, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    private fun addVideo(path: String) {
        val tv = TextureView(context)
        textureView = tv
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                startVideo(path, surface)
            }

            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
                applyCenterCrop()
            }

            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                releasePlayer()
                return true
            }

            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }
        card.addView(tv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    private fun startVideo(path: String, surface: SurfaceTexture) {
        try {
            val mp = MediaPlayer()
            mp.setDataSource(path)
            mp.setSurface(Surface(surface))
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            mp.setOnVideoSizeChangedListener { _, w, h ->
                videoW = w
                videoH = h
                applyCenterCrop()
            }
            mp.setOnPreparedListener { it.start() }
            mp.setOnErrorListener { _, _, _ -> true }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            releasePlayer()
        }
    }

    /** Scales the video to fill the popup without stretching (centre-crop). */
    private fun applyCenterCrop() {
        val tv = textureView ?: return
        val vw = tv.width.toFloat()
        val vh = tv.height.toFloat()
        if (videoW <= 0 || videoH <= 0 || vw <= 0f || vh <= 0f) return
        val scale = kotlin.math.max(vw / videoW, vh / videoH)
        val matrix = Matrix()
        matrix.setScale(videoW * scale / vw, videoH * scale / vh, vw / 2f, vh / 2f)
        tv.setTransform(matrix)
    }

    private fun releasePlayer() {
        val mp = player ?: return
        player = null
        try { mp.stop() } catch (e: Exception) { }
        try { mp.release() } catch (e: Exception) { }
    }

    // ---------- battery ----------

    /** level 0..100 = real reading; anything else = unavailable (empty outline, no percentage). */
    fun setBattery(level: Int) {
        val valid = level in 0..100
        earBattery.level = if (valid) level else -1
        earText.text = if (valid) "$level%" else "—"
    }

    // ---------- lifecycle ----------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        card.alpha = 0f
        card.translationY = dp(28f).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(260).start()

        // Gentle floating motion: a sine wave, so it starts at rest and loops without any jump.
        floatAnimator?.cancel()
        if (floatTarget != null) {
            val bob = ValueAnimator.ofFloat(0f, (2.0 * Math.PI).toFloat())
            bob.duration = 3200
            bob.startDelay = 250
            bob.repeatCount = ValueAnimator.INFINITE
            bob.interpolator = LinearInterpolator()
            bob.addUpdateListener { a ->
                val phase = a.animatedValue as Float
                floatTarget?.translationY = dp(4f).toFloat() * kotlin.math.sin(phase)
            }
            floatAnimator = bob
            bob.start()
        }
    }

    override fun onDetachedFromWindow() {
        floatAnimator?.cancel()
        floatAnimator = null
        releasePlayer()
        val d = animatedDrawable
        if (Build.VERSION.SDK_INT >= 28 && d is AnimatedImageDrawable) d.stop()
        animatedDrawable = null
        card.animate().cancel()
        super.onDetachedFromWindow()
    }
}

/** Battery outline with fill. level < 0 draws an empty outline. */
private class BatteryView(context: Context, private val dark: Boolean) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    var level: Int = -1
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val stroke = 1.6f * d
        val nubW = 2.6f * d
        val bodyRight = w - nubW - 0.8f * d
        val outline = if (dark) Color.argb(205, 255, 255, 255) else Color.argb(185, 40, 40, 46)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        paint.color = outline
        rect.set(stroke / 2f, stroke / 2f, bodyRight - stroke / 2f, h - stroke / 2f)
        canvas.drawRoundRect(rect, 4.2f * d, 4.2f * d, paint)

        paint.style = Paint.Style.FILL
        rect.set(bodyRight + 0.8f * d, h * 0.34f, w, h * 0.66f)
        canvas.drawRoundRect(rect, 1.3f * d, 1.3f * d, paint)

        if (level in 0..100) {
            val pad = stroke + 1.3f * d
            val left = pad
            val maxRight = bodyRight - pad
            val right = left + (maxRight - left) * level / 100f
            paint.color = if (level <= 20) Color.rgb(255, 69, 58) else Color.rgb(48, 209, 88)
            rect.set(left, pad, kotlin.math.max(right, left + 1.5f * d), h - pad)
            canvas.drawRoundRect(rect, 2.4f * d, 2.4f * d, paint)
        }
    }
}

/** Round close button with a drawn X, so it never depends on a font glyph. */
private class CloseButton(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(150, 20, 20, 24)
        canvas.drawCircle(cx, cy, 13f * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 1.8f * d
        paint.color = Color.WHITE
        val a = 4.2f * d
        canvas.drawLine(cx - a, cy - a, cx + a, cy + a, paint)
        canvas.drawLine(cx - a, cy + a, cx + a, cy - a, paint)
    }
}
