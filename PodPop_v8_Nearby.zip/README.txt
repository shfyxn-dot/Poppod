PodPop 3.3 - optional Nearby AirPods detection (Bluetooth LE case-open signal) + Scan test. Popup design unchanged.

PodPop 3.2 - setup steps show a tick when done; popup time (3/6/10/15 s) and vibration tick options. Popup design unchanged.

PodPop 3.1 - new: choose which part of the wallpaper shows (left/right, top/bottom, zoom) with a live preview in the app; AirPods size slider; videos show a still frame instantly so there is no lag; large-video tip.

PodPop v3.0

- Popup: name on top ("AirPods Pro 2"), taller, floating AirPods (transparent cut-out), batteries at
  the bottom, X button, auto-dismiss after 6 s.
- Custom popup wallpaper (PNG / JPG / GIF / MP4). Videos loop automatically and are muted.
  "Floating AirPods on wallpaper" switch decides if the AirPods image floats on top of it.
  "Use default look" removes the wallpaper.
- "Preview popup" shows the popup without earbuds (labelled "Preview", never "Connected").
- Stop button (app + notification), status line.
Build on GitHub: commit this zip + .github/workflows/build.yml, then download app-debug.apk from Releases.
