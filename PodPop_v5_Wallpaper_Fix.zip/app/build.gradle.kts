plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.podpop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.podpop"
        minSdk = 26
        targetSdk = 32
        versionCode = 12
        versionName = "3.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
