package com.example.podpop

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the connection monitor after the phone reboots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && PodPrefs.autoStart(context)) {
            try {
                context.startForegroundService(Intent(context, MonitorService::class.java))
            } catch (e: Exception) {
                // Ignore: user can start PodPop manually.
            }
        }
    }
}
