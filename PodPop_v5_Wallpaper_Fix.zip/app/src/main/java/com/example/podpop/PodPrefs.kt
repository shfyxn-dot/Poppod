package com.example.podpop

import android.content.Context

/** Remembers whether the user wants PodPop to run (so Stop also survives a reboot). */
object PodPrefs {
    private const val FILE = "podpop"
    private const val KEY_AUTOSTART = "autostart"

    fun autoStart(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_AUTOSTART, true)

    fun setAutoStart(context: Context, value: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTOSTART, value).apply()
    }
}
