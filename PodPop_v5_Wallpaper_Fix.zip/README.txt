PodPop v3.0

- Popup: name on top ("AirPods Pro 2"), taller, floating AirPods (transparent cut-out), batteries at
  the bottom, X button, auto-dismiss after 6 s.
- Custom popup wallpaper (PNG / JPG / GIF / MP4). Videos loop automatically and are muted.
  "Floating AirPods on wallpaper" switch decides if the AirPods image floats on top of it.
  "Use default look" removes the wallpaper.
- "Preview popup" shows the popup without earbuds (labelled "Preview", never "Connected").
- Stop button (app + notification), status line.
Build on GitHub: commit this zip + .github/workflows/build.yml, then download app-debug.apk from Releases.
