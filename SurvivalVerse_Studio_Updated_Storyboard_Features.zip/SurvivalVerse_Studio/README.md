# SurvivalVerse Studio — RENDER Edition

Script + ElevenLabs audio + SRT in → finished 1080×1920 / 30 fps H.264 + AAC MP4 out (saved to `Movies/SurvivalVerse`).

## What's new vs the BEAST build
- **Real renderer**: deterministic Canvas scene engine (`js/engine.js`) — stickman rigs (walk/run/scared/crouch/sit/point/fall + talking), expressions,
  zombies (approach/horde/chase/distant/silhouette), city/room/bunker/forest backgrounds with parallax, rain/storm/fog/lightning,
  camera push/pull/pan/tilt/shake/handheld, HUD (heart-rate pulse), title cards, scene transitions, word-highlighted burned-in captions.
- **Frame-by-frame export**: JS draws every frame from time `t` → JPEG → native `MediaCodec` H.264 (explicit timestamps) →
  AAC-LC → `MediaMuxer` MP4. No screenshot/slideshow, no paid APIs, fully offline.
- **Audio**: import narration / music / SFX (MP3/WAV/M4A), per-track offset + volume, music ducking under narration,
  SFX/music files auto-matched to `[SFX: name]` / `[MUSIC: name]` tags by file name, peak-safe mix. Preview plays the exact export mix.
- **SRT**: drives scene cuts, captions and word highlighting.
- **QC**: scene preflight (reports which scene failed), contact sheet PNG, scrubbable preview, ETA, cancel, "first 6 s" test render, range render.
- File chooser + file saving now work inside the WebView (the BEAST build could not import files or download).

## Build the APK from your phone
Upload the ZIP contents to a GitHub repo root → Actions → **Build SurvivalVerse Studio APK** → download `SurvivalVerseStudio-debug-apk`.

## Workflow
1. Script tab: paste tagged script (tag reference is in the app).
2. Audio + SRT tab: import narration, music, SFX, SRT.
3. Preview: scrub / play. Storyboard: check every scene.
4. Render tab: run the 6-second test, then the full render. Keep the app open (screen stays on).

Notes: SRT should have one cue per spoken script line for exact scene cuts (otherwise scenes are aligned by text length and a warning is shown).
Audio files are not stored in project JSON; re-import them (offsets/volumes are remembered by file name).


## Storyboard and reusable visual assets (updated)
- The Storyboard tab now samples the rendered timeline every 4 seconds by default and adds scene-boundary samples. Change the interval and column count in-app; long videos are no longer limited to a small fixed set of scene thumbnails.
- Export creates a portrait-frame contact sheet in a 4-column grid by default, with scene names and timestamps.
- Import transparent character PNG/WebP artwork in Storyboard to keep the same character design across episodes/parts. The uploaded character asset is saved in the project JSON.
- Import multiple background images/sheets in Storyboard. Select them in scripts with `[BG: custom]`, `[BG: custom 2]`, etc.
- Built-in scene props now include door, bunker/exit, elevator/lift and stair scenes when those terms appear in the scene name.
- Speaker shorthand such as `[NARRATOR]` and `[MARINA]` is supported. The existing `[CHARACTER: MARINA]` syntax remains supported. Lip movement is tied to the active character line; narrator lines do not animate character mouths.
- Multiple narration audio files, music and SFX remain supported with per-track offset and volume controls. SRT files can be imported directly from the Audio + SRT tab.
