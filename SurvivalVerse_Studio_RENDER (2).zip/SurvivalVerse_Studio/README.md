# SurvivalVerse Studio v3

Script + (optional) narration/SRT -> finished 1080x1920 30fps MP4, fully offline.

## New in v3
- Auto-director: plain script becomes many shots (~1 shot per 3-4 s), locations auto-picked (door, elevator, stairs, hallway, alley, bunker, forest, room, city).
- Library tab: save character PNGs (idle/talk/walk/run/fall/expressions) once; they persist across stories. Add your own backgrounds with keywords.
- Lip-sync: mouth/sprite flaps while narrator or character speaks. Tags: `[narrator] text`, `[Marina] text`.
- A/B choice cards + "COMMENT A OR B" ending; new heartbeat/noise HUD.
- Built-in synth SFX + music (heartbeat, knock, footsteps, door, elevator ding, riser...). Import your own too.
- Voices tab: offline Android TTS, different voice per speaker, exact SRT generated.
- SRT / JSON pickers now accept any file name (.srt works).

## Build
Push to GitHub; Actions builds the debug APK. Kotlin (encoder + TTS bridge) is not compiled in the authoring sandbox - report any build error.
