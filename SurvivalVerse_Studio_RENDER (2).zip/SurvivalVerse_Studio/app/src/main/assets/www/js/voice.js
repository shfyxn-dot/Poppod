/* SurvivalVerse Studio — voices: generates narration + dialogue audio from the script with the phone's
   offline text-to-speech (native bridge), one voice per speaker, and builds exact SRT timing from it. */
(function () {
  const SV = (window.SV = window.SV || {});
  const SR = 44100;
  const T = (SV.tts = {});
  const tick = () => new Promise((r) => setTimeout(r, 0));
  T.available = () => !!(window.SVNative && window.SVNative.ttsSynth);

  T.voices = async function () {
    const r = window.SVNative.ttsVoices();
    if (/^ERR/.test(r)) throw new Error(r.replace(/^ERR:\s*/, ""));
    const all = JSON.parse(r), off = all.filter((v) => !v.net);
    return (off.length ? off : all).sort((a, b) => a.locale.localeCompare(b.locale) || a.name.localeCompare(b.name));
  };

  T.synth = async function (text, cfg) {
    cfg = cfg || {};
    const r = window.SVNative.ttsSynth(text, cfg.voice || "", cfg.rate || 1, cfg.pitch || 1);
    if (/^ERR/.test(r)) throw new Error(r.replace(/^ERR:\s*/, ""));
    const bin = atob(r), u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return await SV.audio.decode(u8.buffer);
  };

  /* speakers in script order: [{name, kind}] */
  T.speakers = function (script, heroName) {
    const out = [], seen = new Set();
    SV.parseScript(script).forEach((sc) => sc.events.forEach((e) => {
      if (e.type !== "line") return;
      let n = SV.ALIASES.has(e.speaker) && heroName ? heroName : e.speaker;
      if (!seen.has(n)) { seen.add(n); out.push({ name: n, kind: e.kind }); }
    }));
    return out;
  };

  /* returns {buffer, cues}; cfgFor(speaker, kind) -> {voice, rate, pitch} */
  T.generate = async function (script, heroName, cfgFor, onProg, gap) {
    gap = gap == null ? 0.3 : gap;
    const items = []; let pend = 0;
    SV.parseScript(script).forEach((sc) => sc.events.forEach((e) => {
      if (e.type === "pause") pend += parseFloat(String(e.arg).replace(/s$/i, "")) || 0.5;
      else if (e.type === "line") {
        const sp = SV.ALIASES.has(e.speaker) && heroName ? heroName : e.speaker;
        items.push({ speaker: sp, kind: e.kind, text: e.text, emph: !!e.emph, pause: pend }); pend = 0;
      }
    }));
    if (!items.length) throw new Error("No spoken lines in the script.");
    const segs = [], cues = []; let t = 0.3;
    for (let i = 0; i < items.length; i++) {
      const it = items[i], cfg = Object.assign({}, cfgFor(it.speaker, it.kind));
      if (it.emph) { cfg.pitch = (cfg.pitch || 1) * 0.92; cfg.rate = (cfg.rate || 1) * 0.94; }
      const say = it.text.replace(/[—–]/g, ", ").replace(/\.{3,}/g, "...").replace(/\bA,\s/, "Option A, ").replace(/\bB,\s/, "Option B, ");
      onProg && onProg(i, items.length, it);
      await tick();
      const buf = await T.synth(say, cfg);
      const d = buf.getChannelData(0); let pk = 0;
      for (let k = 0; k < d.length; k += 4) { const v = Math.abs(d[k]); if (v > pk) pk = v; }
      t += it.pause;
      segs.push({ data: d, gain: pk > 0 ? 0.85 / pk : 1, at: t });
      cues.push({ start: t, end: t + buf.duration, text: it.text });
      t += buf.duration + gap + (it.emph ? 0.12 : 0);
    }
    const len = Math.ceil((t + 0.4) * SR);
    const out = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(2, 1, SR).createBuffer(2, len, SR);
    const L = out.getChannelData(0), R = out.getChannelData(1);
    segs.forEach((s) => { const o = Math.floor(s.at * SR); for (let i = 0; i < s.data.length && o + i < len; i++) { const v = s.data[i] * s.gain; L[o + i] = v; R[o + i] = v; } });
    return { buffer: out, cues };
  };
})();
