/* SurvivalVerse Studio — frame-by-frame export driver.
   JS draws every frame deterministically (SV.drawFrame), hands JPEG frames + mixed PCM to the native
   Android bridge (SVNative), which encodes H.264 (MediaCodec) + AAC and muxes the MP4 (MediaMuxer). */
(function () {
  const SV = (window.SV = window.SV || {});
  const tick = () => new Promise((r) => setTimeout(r, 0));
  const R = (SV.render = { cancelled: false, busy: false });

  R.available = () => !!(window.SVNative && window.SVNative.beginRender);

  R.preflight = function (comp) {
    const c = document.createElement("canvas"); c.width = 270; c.height = 480;
    const g = c.getContext("2d"), errors = [];
    comp.scenes.forEach((sc) => {
      [sc.start + 0.05, (sc.start + sc.end) / 2, sc.end - 0.05].forEach((t) => {
        try { g.setTransform(0.25, 0, 0, 0.25, 0, 0); SV.drawFrame(g, comp, t); }
        catch (e) { errors.push(`Scene ${sc.index + 1} "${sc.name}" @${t.toFixed(2)}s: ${e.message}`); }
      });
    });
    return errors;
  };

  /* o: {w,h,fps,bitrate,name,from,to}; audio: AudioBuffer|null; cb(progress) */
  R.run = async function (comp, audio, o, cb) {
    if (R.busy) throw new Error("A render is already running.");
    if (!R.available()) throw new Error("MP4 encoding is only available inside the Android app.");
    R.busy = true; R.cancelled = false;
    const N = window.SVNative;
    try {
      const errs = R.preflight(comp);
      if (errs.length) throw new Error("Preflight failed:\n" + errs.join("\n"));
      const from = Math.max(0, o.from || 0), to = Math.min(comp.duration, o.to > from ? o.to : comp.duration);
      const frames = Math.max(1, Math.round((to - from) * o.fps));
      const cv = document.createElement("canvas"); cv.width = o.w; cv.height = o.h;
      const g = cv.getContext("2d", { alpha: false });
      const hasAudio = !!audio;
      let r = N.beginRender(JSON.stringify({ w: o.w, h: o.h, fps: o.fps, bitrate: o.bitrate, name: o.name, hasAudio, sampleRate: 44100 }));
      if (!/^ok/.test(r)) throw new Error(r);
      const t0 = performance.now();
      for (let i = 0; i < frames; i++) {
        if (R.cancelled) { N.cancelRender(); throw new Error("Render cancelled."); }
        const t = from + i / o.fps;
        try {
          g.setTransform(o.w / SV.W, 0, 0, o.h / SV.H, 0, 0);
          SV.drawFrame(g, comp, t);
        } catch (e) {
          const sc = SV.sceneAt(comp, t);
          N.cancelRender();
          throw new Error(`Scene ${sc.index + 1} "${sc.name}" failed at ${t.toFixed(2)}s (frame ${i}): ${e.message}`);
        }
        const url = cv.toDataURL("image/jpeg", 0.93);
        r = N.pushFrame(url.substring(url.indexOf(",") + 1));
        if (!/^ok/.test(r)) { N.cancelRender(); throw new Error(r); }
        if (i % 3 === 0 || i === frames - 1) {
          const el = (performance.now() - t0) / 1000, per = el / (i + 1);
          cb({ phase: "frames", i: i + 1, n: frames, eta: per * (frames - i - 1), fps: (i + 1) / el });
          await tick();
        }
      }
      if (hasAudio) {
        cb({ phase: "audio" }); await tick();
        const pcm = SV.audio.toPCM16(audio, from, to), bytes = new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength);
        const CH = 196608;
        for (let p = 0; p < bytes.length; p += CH) {
          r = N.audioChunk(SV.b64(bytes.subarray(p, Math.min(bytes.length, p + CH))));
          if (!/^ok/.test(r)) { N.cancelRender(); throw new Error(r); }
          if ((p / CH) % 8 === 0) await tick();
        }
      }
      cb({ phase: "mux" }); await tick();
      const res = N.finishRender();
      if (!/^ok/.test(res)) throw new Error(res);
      return res.replace(/^ok:?\s*/, "");
    } finally { R.busy = false; }
  };
})();
