/* SurvivalVerse Studio — built-in procedural SFX + loopable horror music (no files needed). */
(function () {
  const SV = (window.SV = window.SV || {});
  const SR = 44100, TAU = Math.PI * 2;
  const syn = (SV.synth = {});
  const OAC = () => window.OfflineAudioContext || window.webkitOfflineAudioContext;

  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const N = (sec) => new Float32Array(Math.floor(sec * SR));
  function toBuf(L, R) {
    const b = new (OAC())(2, 1, SR).createBuffer(2, L.length, SR);
    b.copyToChannel(L, 0); b.copyToChannel(R || L, 1); return b;
  }
  function norm(x, peak) { let m = 0; for (let i = 0; i < x.length; i++) { const v = Math.abs(x[i]); if (v > m) m = v; } if (m > 0) { const k = peak / m; for (let i = 0; i < x.length; i++) x[i] *= k; } return x; }
  function add(dst, src, at, g) { const o = Math.floor(at * SR); for (let i = 0; i < src.length && o + i < dst.length; i++) dst[o + i] += src[i] * (g == null ? 1 : g); }
  function lp(x, a) { let y = 0; for (let i = 0; i < x.length; i++) { y += a * (x[i] - y); x[i] = y; } return x; }

  function thud(freq, dur, noiseAmt, decay, seed) {
    const x = N(dur), r = rng(seed); let ph = 0, nz = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR, f = freq * (1 - 0.35 * Math.min(1, t * 8));
      ph += (TAU * f) / SR; nz += 0.25 * (r() * 2 - 1 - nz);
      x[i] = (Math.sin(ph) * 0.9 + nz * noiseAmt) * Math.exp(-t * decay);
    }
    return x;
  }
  function saw(ph, harm) { let v = 0; for (let k = 1; k <= harm; k++) v += Math.sin(k * ph) / k; return v; }

  const SFX = {
    knock() { const x = N(0.75); add(x, thud(118, 0.3, 0.7, 22, 1), 0, 1); add(x, thud(110, 0.3, 0.7, 22, 2), 0.29, 0.9); return x; },
    heartbeat() { const x = N(0.7); add(x, thud(58, 0.4, 0.04, 15, 3), 0, 1); add(x, thud(48, 0.4, 0.04, 17, 4), 0.21, 0.7); return x; },
    footstep() {
      const x = thud(78, 0.28, 0.9, 26, 5), r = rng(6); let nz = 0;
      for (let i = 0; i < x.length; i++) { const t = i / SR, w = r() * 2 - 1; nz += 0.5 * (w - nz); x[i] += (w - nz) * 0.25 * Math.exp(-t * 45); }
      return x;
    },
    footsteps_run() { const x = N(2.6), s = SFX.footstep(); for (let i = 0; i < 9; i++) add(x, s, i * 0.27 + (i % 2) * 0.02, 0.55 + 0.45 * (i % 2)); return x; },
    door_creak() {
      const x = N(1.8); let ph = 0;
      for (let i = 0; i < x.length; i++) {
        const t = i / SR, f = 130 + 120 * Math.sin((Math.PI * t) / 1.8) + 9 * Math.sin(TAU * 23 * t);
        ph += (TAU * f) / SR;
        const env = Math.min(1, t / 0.2) * Math.min(1, (1.8 - t) / 0.4);
        x[i] = saw(ph, 9) * 0.35 * env * (0.75 + 0.25 * Math.sin(TAU * 17 * t));
      }
      return lp(x, 0.35);
    },
    door_slam() { const x = N(1), r = rng(8); add(x, thud(46, 1, 1.3, 8, 7), 0, 1); for (let i = 0; i < 6000; i++) x[i] += (r() * 2 - 1) * 0.6 * Math.exp(-i / 900); return x; },
    elevator_ding() { const x = N(1.6); for (let i = 0; i < x.length; i++) { const t = i / SR; x[i] = (Math.sin(TAU * 1175 * t) + 0.45 * Math.sin(TAU * 2349 * t) + 0.2 * Math.sin(TAU * 3520 * t)) * Math.exp(-t * 2.8) * 0.5; } return x; },
    thunder() {
      const x = N(3.6), r = rng(9);
      for (let i = 0; i < x.length; i++) x[i] = r() * 2 - 1;
      lp(x, 0.03); lp(x, 0.05);
      for (let i = 0; i < x.length; i++) { const t = i / SR; x[i] *= Math.min(1, t * 7) * Math.exp(-t * 0.85) * (0.7 + 0.3 * Math.sin(t * 17)) * 14; x[i] += Math.sin(TAU * 38 * t) * 0.3 * Math.exp(-t * 1.1); }
      return x;
    },
    phone_alert() { const x = N(1.4); for (let i = 0; i < x.length; i++) { const t = i / SR, on = mod(t, 0.5) < 0.11 ? 1 : 0, f = mod(t, 1) < 0.5 ? 1046 : 1318; x[i] = Math.sin(TAU * f * t) * on * 0.5 + Math.sin(TAU * f * 2 * t) * on * 0.12; } return x; },
    groan() {
      const x = N(2.4); let ph = 0;
      for (let i = 0; i < x.length; i++) {
        const t = i / SR, f = 88 - 28 * (t / 2.4) + 3 * Math.sin(TAU * 5 * t);
        ph += (TAU * f) / SR;
        x[i] = saw(ph, 14) * Math.pow(Math.sin((Math.PI * t) / 2.4), 1.5) * 0.5;
      }
      return lp(x, 0.09);
    },
    whoosh() { const x = N(0.9), r = rng(11); let y = 0; for (let i = 0; i < x.length; i++) { const t = i / SR, a = 0.02 + 0.3 * Math.sin((Math.PI * t) / 0.9); y += a * (r() * 2 - 1 - y); x[i] = y * Math.sin((Math.PI * t) / 0.9) * 3; } return x; },
    hit() { const x = N(1.5), r = rng(12); let ph = 0; for (let i = 0; i < x.length; i++) { const t = i / SR; ph += (TAU * (62 - 25 * Math.min(1, t * 2))) / SR; x[i] = Math.sin(ph) * Math.exp(-t * 3) + (r() * 2 - 1) * 0.5 * Math.exp(-t * 14) + (Math.sin(TAU * 311 * t) + Math.sin(TAU * 466 * t)) * 0.12 * Math.exp(-t * 2.2); } return x; },
    riser() { const x = N(3.2), r = rng(13); let ph = 0, y = 0; for (let i = 0; i < x.length; i++) { const t = i / SR, u = t / 3.2; ph += (TAU * (180 + 1100 * u * u)) / SR; y += 0.4 * ((r() * 2 - 1) - y); x[i] = (Math.sin(ph) * 0.5 + (r() * 2 - 1 - y) * 0.4) * u * u; } return x; },
    static() { const x = N(1.2), r = rng(14); for (let i = 0; i < x.length; i++) x[i] = (r() * 2 - 1) * 0.5 * (0.6 + 0.4 * Math.sin(i / 400)); return x; },
  };
  function mod(a, n) { return ((a % n) + n) % n; }

  const LEN = 16 * SR;
  function pulse(t, per, f, decay) { const tp = mod(t, per); return Math.sin(TAU * f * tp) * Math.exp(-tp * decay); }
  const MUSIC = {
    tense() {
      const L = new Float32Array(LEN), R = new Float32Array(LEN);
      for (let i = 0; i < LEN; i++) {
        const t = i / SR, sw = 0.7 + 0.3 * Math.sin((TAU * t) / 16);
        const a = saw(TAU * 55 * t, 6) * 0.2 * sw, b = saw(TAU * 55.125 * t, 6) * 0.2 * sw, c = saw(TAU * 55.0625 * t, 6) * 0.2 * sw;
        const tri = Math.sin(TAU * 77.75 * t) * 0.1 * (0.5 + 0.5 * Math.sin((TAU * t) / 8));
        const hi = Math.sin(TAU * 698.5 * t) * 0.025 * Math.pow(Math.max(0, Math.sin((TAU * t) / 8)), 6);
        const p = (pulse(t, 1, 46, 7) + 0.6 * pulse(t - 0.22, 1, 42, 9)) * 0.38;
        L[i] = a + b + tri + hi + p; R[i] = b + c + tri * 0.8 + hi + p;
      }
      lp(L, 0.12); lp(R, 0.12); norm(L, 0.7); norm(R, 0.7); return [L, R];
    },
    calm() {
      const L = new Float32Array(LEN), R = new Float32Array(LEN);
      for (let i = 0; i < LEN; i++) {
        const t = i / SR, sw = Math.pow(Math.sin((Math.PI * t) / 16), 2) * 0.8 + 0.2;
        const v = (Math.sin(TAU * 110 * t) * 0.35 + Math.sin(TAU * 130.8125 * t) * 0.25 + Math.sin(TAU * 164.8125 * t) * 0.2 + Math.sin(TAU * 220 * t) * 0.08) * sw;
        L[i] = v; R[i] = v * 0.9 + Math.sin(TAU * 110.0625 * t) * 0.05;
      }
      norm(L, 0.6); norm(R, 0.6); return [L, R];
    },
    chase() {
      const L = new Float32Array(LEN), R = new Float32Array(LEN), r = rng(21);
      const tick = new Float32Array(LEN);
      for (let k = 0; k < 80; k++) { const o = Math.floor(k * 0.2 * SR); for (let j = 0; j < 1800 && o + j < LEN; j++) tick[o + j] += (r() * 2 - 1) * Math.exp(-j / 260) * (k % 2 ? 0.25 : 0.12); }
      for (let i = 0; i < LEN; i++) {
        const t = i / SR, trem = 0.6 + 0.4 * Math.sin(TAU * 5 * t);
        const v = pulse(t, 0.4, 52, 9) * 0.7 + saw(TAU * 55 * t, 5) * 0.18 * trem + saw(TAU * 82.5 * t, 4) * 0.08 * trem + tick[i];
        L[i] = v; R[i] = v;
      }
      lp(L, 0.35); lp(R, 0.35); norm(L, 0.7); norm(R, 0.7); return [L, R];
    },
  };

  const cache = {};
  syn.sfxNames = Object.keys(SFX);
  syn.musicNames = Object.keys(MUSIC);
  syn.sfx = (name) => { if (!SFX[name]) return null; return cache["s:" + name] || (cache["s:" + name] = toBuf(norm(SFX[name](), 0.9))); };
  syn.music = (name) => { if (!MUSIC[name]) return null; return cache["m:" + name] || (cache["m:" + name] = (() => { const [L, R] = MUSIC[name](); return toBuf(L, R); })()); };

  const SFX_MAP = [[/knock/, "knock"], [/heart|pulse/, "heartbeat"], [/run.*step|steps_run|footsteps/, "footsteps_run"], [/foot|step|walk/, "footstep"], [/creak/, "door_creak"], [/slam|bang|thud/, "door_slam"],
    [/ding|elevator|bell/, "elevator_ding"], [/thunder|storm/, "thunder"], [/phone|alert|ring|notif/, "phone_alert"], [/groan|zombie|moan|growl/, "groan"], [/whoosh|swoosh|swipe/, "whoosh"],
    [/hit|stinger|impact|boom|sting/, "hit"], [/riser|rise|build/, "riser"], [/static|glitch|noise/, "static"]];
  const MUSIC_MAP = [[/chase|action|run|panic|escape/, "chase"], [/calm|soft|peace|sad|hope/, "calm"], [/tense|dark|ambient|horror|drone|suspense|low|fear|scary/, "tense"]];
  syn.findSfx = (tag) => { tag = String(tag || "").toLowerCase(); if (SFX[tag]) return tag; const m = SFX_MAP.find(([re]) => re.test(tag)); return m ? m[1] : null; };
  syn.findMusic = (tag) => { tag = String(tag || "").toLowerCase(); if (MUSIC[tag]) return tag; const m = MUSIC_MAP.find(([re]) => re.test(tag)); return m ? m[1] : null; };
})();
