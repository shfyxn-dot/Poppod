/* SurvivalVerse Studio — persistent Library (IndexedDB): characters (PNG sprites), backgrounds, music/SFX.
   Everything survives app restarts, so every new story reuses the same cast and sounds. */
(function () {
  const SV = (window.SV = window.SV || {});
  const L = (SV.lib = { chars: {}, bgs: {}, audio: {}, db: null, ready: null });
  SV.charAssets = SV.charAssets || {}; SV.bgImages = SV.bgImages || {}; SV.bgDefs = SV.bgDefs || [];

  L.SLOTS = [
    ["idle", "Idle (mouth closed)", true], ["talk", "Talking (mouth open)", true],
    ["scared", "Scared"], ["scared_talk", "Scared talking"], ["worried", "Worried"], ["worried_talk", "Worried talking"],
    ["angry", "Angry"], ["sad", "Sad"], ["happy", "Happy"], ["tired", "Tired"],
    ["walkA", "Walk A"], ["walkB", "Walk B"], ["runA", "Run A"], ["runB", "Run B"], ["fall", "Fallen / dead"],
  ];

  function open() {
    return new Promise((res) => {
      try {
        const rq = indexedDB.open("svstudio", 1);
        rq.onupgradeneeded = () => { const d = rq.result; ["chars", "bgs"].forEach((n) => d.createObjectStore(n, { keyPath: "name" })); d.createObjectStore("audio", { keyPath: "key" }); };
        rq.onsuccess = () => res(rq.result); rq.onerror = () => res(null); rq.onblocked = () => res(null);
      } catch (e) { res(null); }
    });
  }
  const store = (n, mode) => L.db.transaction(n, mode).objectStore(n);
  const wrap = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const put = async (n, rec) => { if (L.db) try { await wrap(store(n, "readwrite").put(rec)); } catch (e) { console.log("lib put failed", e); } };
  const del = async (n, key) => { if (L.db) try { await wrap(store(n, "readwrite").delete(key)); } catch (e) { } };
  const all = async (n) => (L.db ? wrap(store(n, "readonly").getAll()) : []);

  async function blobImg(blob) {
    const url = URL.createObjectURL(blob), img = new Image();
    img.src = url; await img.decode(); return img;
  }

  /* ----- characters ----- */
  async function buildChar(rec) {
    const slots = {};
    for (const k of Object.keys(rec.slots || {})) { try { slots[k] = await blobImg(rec.slots[k]); } catch (e) { console.log("bad image", rec.name, k); } }
    SV.charAssets[rec.name] = { name: rec.name, role: rec.role, height: rec.height || 640, yOff: rec.yOff || 0, facesLeft: !!rec.facesLeft, slots };
  }
  L.listChars = () => Object.values(L.chars).sort((a, b) => a.name.localeCompare(b.name));
  L.mainChar = () => { const c = L.listChars().find((x) => x.role === "main"); return c ? c.name : ""; };
  L.addChar = async function (name, role) {
    name = String(name || "").trim().toUpperCase().replace(/[^A-Z0-9_ ]/g, "");
    if (!name) throw new Error("Enter a character name (e.g. ALEX)");
    const rec = L.chars[name] || { name, role: role || "main", height: 640, yOff: 0, facesLeft: false, slots: {} };
    rec.role = role || rec.role; L.chars[name] = rec; await put("chars", rec); await buildChar(rec); return rec;
  };
  L.updateChar = async function (name, patch) { const rec = L.chars[name]; Object.assign(rec, patch); await put("chars", rec); await buildChar(rec); };
  L.setSlot = async function (name, slot, file) { const rec = L.chars[name]; rec.slots[slot] = file; await put("chars", rec); await buildChar(rec); };
  L.clearSlot = async function (name, slot) { const rec = L.chars[name]; delete rec.slots[slot]; await put("chars", rec); await buildChar(rec); };
  L.deleteChar = async function (name) { delete L.chars[name]; delete SV.charAssets[name]; await del("chars", name); };

  /* ----- backgrounds ----- */
  function syncBgDefs() { SV.bgDefs.length = 0; Object.values(L.bgs).forEach((b) => SV.bgDefs.push({ name: b.name, keywords: b.keywords })); }
  L.listBgs = () => Object.values(L.bgs).sort((a, b) => a.name.localeCompare(b.name));
  L.addBg = async function (name, keywords, file) {
    name = String(name || "").trim().toLowerCase().replace(/[^a-z0-9_ ]/g, "");
    if (!name) throw new Error("Enter a background name (e.g. rooftop)");
    const rec = { name, keywords: keywords || "", blob: file };
    L.bgs[name] = rec; SV.bgImages[name] = await blobImg(file); await put("bgs", rec); syncBgDefs(); return rec;
  };
  L.setBgKeywords = async function (name, kw) { const rec = L.bgs[name]; rec.keywords = kw; await put("bgs", rec); syncBgDefs(); };
  L.deleteBg = async function (name) { delete L.bgs[name]; delete SV.bgImages[name]; await del("bgs", name); syncBgDefs(); };

  /* ----- music / sfx files ----- */
  L.saveAudio = async function (track) {
    if (!track.raw) return;
    const key = track.kind + ":" + track.name;
    await put("audio", { key, kind: track.kind, name: track.name, data: track.raw, offset: track.offset, volume: track.volume });
    track.lib = true;
  };
  L.deleteAudio = (track) => del("audio", track.kind + ":" + track.name);

  /* ----- init ----- */
  L.init = function () {
    if (L.ready) return L.ready;
    L.ready = (async () => {
      L.db = await open();
      try {
        for (const r of await all("chars")) { L.chars[r.name] = r; await buildChar(r); }
        for (const r of await all("bgs")) { L.bgs[r.name] = r; try { SV.bgImages[r.name] = await blobImg(r.blob); } catch (e) { } }
        syncBgDefs();
        for (const r of await all("audio")) {
          try {
            const buffer = await SV.audio.decode(r.data.slice(0));
            const t = SV.audio.addDecoded({ name: r.name, kind: r.kind, buffer, offset: r.offset, volume: r.volume, lib: true });
            t.raw = r.data;
          } catch (e) { console.log("audio restore failed", r.name); }
        }
      } catch (e) { console.log("library load failed", e); }
      return true;
    })();
    return L.ready;
  };
})();
