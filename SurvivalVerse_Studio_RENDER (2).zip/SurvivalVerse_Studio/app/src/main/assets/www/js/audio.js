/* SurvivalVerse Studio — audio import, mixing (with narration ducking) and preview playback.
   Mixing uses OfflineAudioContext, so the exported audio is exactly what the preview plays. */
(function () {
  const SV = (window.SV = window.SV || {});
  const SR = 44100;
  const A = (SV.audio = { tracks: [], nextId: 1, cache: null });
  const OAC = () => window.OfflineAudioContext || window.webkitOfflineAudioContext;

  const norm = (s) => String(s || "").toLowerCase().replace(/\.[a-z0-9]+$/, "").replace(/[^a-z0-9]/g, "");

  A.decode = async function (arrayBuffer) {
    const ctx = new (OAC())(2, 1, SR);
    return await new Promise((res, rej) => {
      const p = ctx.decodeAudioData(arrayBuffer, res, rej);
      if (p && p.catch) p.catch(rej);
    });
  };

  A.narrationDuration = function () {
    return A.tracks.filter((t) => t.kind === "narration" && t.buffer).reduce((m, t) => Math.max(m, t.offset + t.duration), 0);
  };

  A.addDecoded = function (o) {
    const t = { id: A.nextId++, name: o.name, stem: norm(o.name), kind: o.kind, buffer: o.buffer, duration: o.buffer.duration,
      offset: o.offset || 0, volume: o.volume == null ? 0.9 : o.volume, lib: !!o.lib };
    A.tracks.push(t); A.cache = null; return t;
  };

  A.addFile = async function (file, kind) {
    const ab = await file.arrayBuffer();
    const raw = kind === "narration" ? null : ab.slice(0); // keep original bytes so music/SFX can live in the Library
    const buffer = await A.decode(ab);
    const t = {
      id: A.nextId++, name: file.name, stem: norm(file.name), kind, buffer, duration: buffer.duration, raw,
      offset: kind === "narration" ? A.narrationDuration() : 0,
      volume: kind === "narration" ? 1 : kind === "music" ? 0.6 : 0.9,
    };
    A.tracks.push(t); A.cache = null;
    return t;
  };
  A.remove = (id) => { A.tracks = A.tracks.filter((t) => t.id !== id); A.cache = null; };
  A.invalidate = () => { A.cache = null; };

  const matches = (tag, stem) => stem && tag && (stem === tag || stem.includes(tag) || tag.includes(stem));

  A.matchReport = function (comp) {
    const sfxTracks = A.tracks.filter((t) => t.kind === "sfx"), musicTracks = A.tracks.filter((t) => t.kind === "music");
    const out = [], seen = new Set();
    comp.sfx.forEach((s) => {
      if (seen.has(s.name)) return; seen.add(s.name);
      const user = sfxTracks.some((t) => matches(norm(s.name), t.stem)), syn = SV.synth && SV.synth.findSfx(s.name);
      out.push({ type: "SFX", name: s.name, ok: user || !!syn, builtin: !user && !!syn });
    });
    const mseen = new Set();
    comp.music.forEach((m) => {
      if (m.stop || mseen.has(m.name)) return; mseen.add(m.name);
      const exact = musicTracks.some((t) => matches(norm(m.name), t.stem));
      out.push({ type: "MUSIC", name: m.name, ok: true, builtin: !exact && !musicTracks.length, fallback: !exact && musicTracks.length > 0 });
    });
    if (comp.beats && comp.beats.length) out.push({ type: "HEARTBEAT", name: comp.beats.length + " beats follow the HUD", ok: true, builtin: true });
    return out;
  };

  function speechWindows(comp) {
    const w = [];
    comp.cues.forEach((c) => {
      if (w.length && c.start - w[w.length - 1][1] < 0.45) w[w.length - 1][1] = Math.max(w[w.length - 1][1], c.end);
      else w.push([c.start, c.end]);
    });
    return w;
  }

  A.mix = async function (comp, opts) {
    opts = opts || {};
    const duck = opts.duck !== false, duckLevel = opts.duckLevel != null ? opts.duckLevel : 0.3;
    const len = Math.ceil(comp.duration * SR);
    const oc = new (OAC())(2, len, SR);
    const master = oc.createGain();
    const comp1 = oc.createDynamicsCompressor();
    comp1.threshold.value = -14; comp1.ratio.value = 3; comp1.attack.value = 0.01; comp1.release.value = 0.2;
    master.connect(comp1); comp1.connect(oc.destination);
    const musicBus = oc.createGain(); musicBus.connect(master);
    musicBus.gain.setValueAtTime(1, 0);
    if (duck) {
      speechWindows(comp).forEach(([a, b]) => {
        musicBus.gain.setTargetAtTime(duckLevel, Math.max(0, a - 0.08), 0.07);
        musicBus.gain.setTargetAtTime(1, b + 0.05, 0.35);
      });
    }
    const play = (track, dest, when, gain, o) => {
      o = o || {};
      const src = oc.createBufferSource(); src.buffer = track.buffer;
      const g = oc.createGain(); g.gain.value = 0; src.connect(g); g.connect(dest);
      let w = when, skip = 0;
      if (w < 0) { skip = -w; w = 0; }
      if (skip >= track.duration && !o.loop) return;
      const end = o.end != null ? o.end : comp.duration;
      if (w >= end) return;
      src.loop = !!o.loop;
      const fi = o.fadeIn || 0.005, fo = o.fadeOut || 0.01;
      g.gain.setValueAtTime(0, w);
      g.gain.linearRampToValueAtTime(gain, w + fi);
      g.gain.setValueAtTime(gain, Math.max(w + fi, end - fo));
      g.gain.linearRampToValueAtTime(0, end);
      src.start(w, o.loop ? skip % track.duration : skip);
      src.stop(Math.min(comp.duration, end + 0.01));
    };

    const T = A.tracks.filter((t) => t.buffer);
    // narration
    T.filter((t) => t.kind === "narration").forEach((t) => play(t, master, t.offset, t.volume));
    // music: your files, else built-in generated music
    const synthTrack = (buf, vol) => ({ buffer: buf, duration: buf.duration, volume: vol == null ? 1 : vol, offset: 0 });
    const musicTracks = T.filter((t) => t.kind === "music");
    const tags = comp.music.slice().sort((a, b) => a.t - b.t);
    const S = comp.settings || {};
    if (!tags.length) {
      if (musicTracks.length) musicTracks.forEach((t) => play(t, musicBus, t.offset, t.volume * 0.5, { loop: true, fadeIn: 1.2, fadeOut: 2 }));
      else if (S.autoMusic !== false && SV.synth) play(synthTrack(SV.synth.music("tense")), musicBus, 0, 0.32, { loop: true, fadeIn: 1.5, fadeOut: 2.5 });
    } else {
      tags.forEach((m, i) => {
        if (m.stop) return;
        let track = musicTracks.find((t) => matches(norm(m.name), t.stem));
        let gain = m.volume * (track ? track.volume : 1);
        if (!track && musicTracks.length) { track = musicTracks[0]; gain = m.volume * track.volume; }
        if (!track && SV.synth) { const k = SV.synth.findMusic(m.name) || "tense"; track = synthTrack(SV.synth.music(k)); gain = m.volume * 1.2; }
        if (!track) return;
        const next = tags[i + 1];
        play(track, musicBus, m.t + (track.offset || 0), gain, { loop: true, end: next ? next.t : comp.duration, fadeIn: 1.2, fadeOut: next ? 1.2 : 2 });
      });
    }
    // sfx: your files first, else built-in generated effects
    const sfxTracks = T.filter((t) => t.kind === "sfx"), used = new Set();
    comp.sfx.forEach((s) => {
      let track = sfxTracks.find((t) => matches(norm(s.name), t.stem)), g = s.volume;
      if (track) { used.add(track.id); g *= track.volume; }
      else if (SV.synth) { const k = SV.synth.findSfx(s.name); if (k) track = synthTrack(SV.synth.sfx(k)); }
      if (!track) return;
      const at = s.t + (track.offset || 0);
      play(track, master, at, g, { end: Math.min(comp.duration, at + track.duration) });
    });
    sfxTracks.filter((t) => !used.has(t.id)).forEach((t) => play(t, master, t.offset, t.volume, { end: Math.min(comp.duration, t.offset + t.duration) }));
    // heartbeat bed follows the HUD heart rate
    if (S.heartbeatSfx !== false && comp.beats && comp.beats.length && SV.synth) {
      const hb = synthTrack(SV.synth.sfx("heartbeat"));
      comp.beats.forEach((b) => play(hb, master, b.t, b.vol * 0.7, { end: Math.min(comp.duration, b.t + hb.duration) }));
    }

    const out = await oc.startRendering();
    // keep peaks below clipping
    let peak = 0;
    for (let c = 0; c < out.numberOfChannels; c++) { const d = out.getChannelData(c); for (let i = 0; i < d.length; i++) { const v = Math.abs(d[i]); if (v > peak) peak = v; } }
    if (peak > 0.97) {
      const k = 0.95 / peak;
      for (let c = 0; c < out.numberOfChannels; c++) { const d = out.getChannelData(c); for (let i = 0; i < d.length; i++) d[i] *= k; }
    }
    out._peak = peak;
    return out;
  };

  A.hasAudio = () => A.tracks.some((t) => t.buffer);

  A.toPCM16 = function (buf, startSec, endSec) {
    const s0 = Math.floor((startSec || 0) * buf.sampleRate), s1 = Math.min(buf.length, Math.ceil((endSec != null ? endSec : buf.duration) * buf.sampleRate));
    const n = Math.max(0, s1 - s0), L = buf.getChannelData(0), R = buf.numberOfChannels > 1 ? buf.getChannelData(1) : L;
    const out = new Int16Array(n * 2);
    for (let i = 0; i < n; i++) {
      out[i * 2] = Math.max(-1, Math.min(1, L[s0 + i])) * 32767;
      out[i * 2 + 1] = Math.max(-1, Math.min(1, R[s0 + i])) * 32767;
    }
    return out;
  };
  SV.b64 = function (u8) {
    let s = "";
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  };

  /* ---------- preview playback ---------- */
  const P = (A.player = { ctx: null, src: null, startT: 0, ctxStart: 0, playing: false });
  A.player.play = function (buffer, fromT) {
    A.player.stop();
    if (!buffer) { A.player.playing = true; A.player.startT = fromT; A.player.ctxStart = performance.now() / 1000; A.player.silent = true; return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    P.ctx = P.ctx || new AC();
    if (P.ctx.state === "suspended") P.ctx.resume();
    P.src = P.ctx.createBufferSource(); P.src.buffer = buffer; P.src.connect(P.ctx.destination);
    P.startT = fromT; P.ctxStart = P.ctx.currentTime; P.silent = false;
    P.src.start(0, Math.max(0, fromT)); P.playing = true;
  };
  A.player.stop = function () { if (P.src) { try { P.src.stop(); } catch (e) { } P.src = null; } P.playing = false; };
  A.player.time = function () {
    if (!P.playing) return P.startT;
    return P.startT + (P.silent ? performance.now() / 1000 : P.ctx.currentTime) - P.ctxStart;
  };
})();
