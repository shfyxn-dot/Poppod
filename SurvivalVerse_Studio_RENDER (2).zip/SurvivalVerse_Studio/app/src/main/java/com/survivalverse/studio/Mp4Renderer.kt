package com.survivalverse.studio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * Frame-by-frame MP4 writer.
 *
 *  JS (WebView) -> beginRender -> pushFrame(JPEG) x N -> audioChunk(PCM16 stereo) x M -> finishRender
 *
 *  Video: JPEG -> Bitmap -> YUV420 (BT.709, limited) -> MediaCodec "video/avc" (ByteBuffer input,
 *         explicit presentation timestamps => exact 30 fps, deterministic sync) -> temp video.mp4
 *  Audio: PCM file -> MediaCodec "audio/mp4a-latm" (AAC-LC) -> temp audio.m4a
 *  Final: MediaExtractor + MediaMuxer interleave both into the finished MP4, then publish to
 *         Movies/SurvivalVerse (MediaStore on Android 10+, app-external Movies folder below that).
 */
class Mp4Renderer(private val ctx: Context) {
    private val workDir = File(ctx.cacheDir, "render").apply { mkdirs() }
    private val videoTmp = File(workDir, "video.mp4")
    private val audioTmp = File(workDir, "audio.m4a")
    private val pcmFile = File(workDir, "audio.pcm")
    private val finalTmp = File(workDir, "final.mp4")

    private var w = 0
    private var h = 0
    private var fps = 30
    private var name = "episode"
    private var hasAudio = false
    private var sampleRate = 44100

    private var enc: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var vTrack = -1
    private var vStarted = false
    private var frameIdx = 0L
    private val info = MediaCodec.BufferInfo()
    private var pixels: IntArray? = null
    private var rowBuf: ByteArray? = null
    private var pcmOut: FileOutputStream? = null

    @Synchronized
    fun begin(w: Int, h: Int, fps: Int, bitrate: Int, hasAudio: Boolean, sampleRate: Int, name: String) {
        cancel()
        require(w % 2 == 0 && h % 2 == 0) { "Width/height must be even" }
        this.w = w; this.h = h; this.fps = fps; this.hasAudio = hasAudio; this.sampleRate = sampleRate
        this.name = name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "episode" }
        frameIdx = 0; vTrack = -1; vStarted = false
        pixels = IntArray(w * h); rowBuf = ByteArray(w)
        listOf(videoTmp, audioTmp, pcmFile, finalTmp).forEach { it.delete() }

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
            setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        }
        val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        e.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        e.start()
        enc = e
        muxer = MediaMuxer(videoTmp.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        if (hasAudio) pcmOut = FileOutputStream(pcmFile)
    }

    @Synchronized
    fun pushFrame(jpeg: ByteArray) {
        val e = enc ?: error("Render not started")
        var bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: error("Frame $frameIdx: bad JPEG")
        if (bmp.width != w || bmp.height != h) {
            val s = Bitmap.createScaledBitmap(bmp, w, h, true); bmp.recycle(); bmp = s
        }
        val px = pixels!!
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()

        var idx: Int
        var spins = 0
        while (true) {
            idx = e.dequeueInputBuffer(10_000)
            if (idx >= 0) break
            drain(false)
            if (++spins > 2000) error("Encoder input stalled at frame $frameIdx")
        }
        val img = e.getInputImage(idx) ?: error("Encoder gave no input image")
        fillImage(img, px)
        e.queueInputBuffer(idx, 0, w * h * 3 / 2, frameIdx * 1_000_000L / fps, 0)
        frameIdx++
        drain(false)
    }

    /** RGB -> YUV420 (BT.709 limited range) written through the codec's Image planes (any layout). */
    private fun fillImage(img: Image, px: IntArray) {
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
        val ys = yP.rowStride; val us = uP.rowStride; val vs = vP.rowStride
        val up = uP.pixelStride; val vp = vP.pixelStride
        val row = rowBuf!!
        for (j in 0 until h) {
            val base = j * w
            for (i in 0 until w) {
                val c = px[base + i]
                val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                row[i] = (((47 * r + 157 * g + 16 * b + 128) shr 8) + 16).toByte()
            }
            yb.position(j * ys)
            yb.put(row, 0, w)
            if (j and 1 == 0) {
                val b2 = base + w
                var i = 0
                while (i < w) {
                    val c0 = px[base + i]; val c1 = px[base + i + 1]; val c2 = px[b2 + i]; val c3 = px[b2 + i + 1]
                    val r = (((c0 shr 16) and 255) + ((c1 shr 16) and 255) + ((c2 shr 16) and 255) + ((c3 shr 16) and 255)) shr 2
                    val g = (((c0 shr 8) and 255) + ((c1 shr 8) and 255) + ((c2 shr 8) and 255) + ((c3 shr 8) and 255)) shr 2
                    val b = ((c0 and 255) + (c1 and 255) + (c2 and 255) + (c3 and 255)) shr 2
                    val u = ((-26 * r - 87 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 102 * g - 10 * b + 128) shr 8) + 128
                    ub.put((j shr 1) * us + (i shr 1) * up, u.coerceIn(16, 240).toByte())
                    vb.put((j shr 1) * vs + (i shr 1) * vp, v.coerceIn(16, 240).toByte())
                    i += 2
                }
            }
        }
    }

    private fun drain(eos: Boolean) {
        val e = enc ?: return
        var spins = 0
        while (true) {
            val i = e.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
            when {
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!eos) return
                    if (++spins > 600) error("Video encoder did not finish")
                }
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    vTrack = muxer!!.addTrack(e.outputFormat)
                    muxer!!.start(); vStarted = true
                }
                i >= 0 -> {
                    val buf = e.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && vStarted) {
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        muxer!!.writeSampleData(vTrack, buf, info)
                    }
                    e.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }

    @Synchronized
    fun audioChunk(data: ByteArray) { (pcmOut ?: error("Audio not expected")).write(data) }

    @Synchronized
    fun finish(): String {
        val e = enc ?: error("Render not started")
        var idx: Int
        var spins = 0
        while (true) {
            idx = e.dequeueInputBuffer(10_000)
            if (idx >= 0) break
            drain(false)
            if (++spins > 2000) error("Encoder stalled at end")
        }
        e.queueInputBuffer(idx, 0, 0, frameIdx * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drain(true)
        e.stop(); e.release(); enc = null
        if (vStarted) muxer!!.stop()
        muxer!!.release(); muxer = null
        pcmOut?.close(); pcmOut = null

        val out: File
        if (hasAudio && pcmFile.length() > 0) {
            encodeAudio()
            remux(finalTmp)
            out = finalTmp
        } else out = videoTmp
        val msg = publish(out)
        listOf(videoTmp, audioTmp, pcmFile, finalTmp).forEach { it.delete() }
        pixels = null
        return msg
    }

    private fun readFill(inp: FileInputStream, buf: ByteArray, len: Int): Int {
        var n = 0
        while (n < len) { val r = inp.read(buf, n, len - n); if (r <= 0) break; n += r }
        return n - (n and 3) // whole stereo 16-bit frames only
    }

    private fun encodeAudio() {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 160_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
        }
        val a = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        a.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        a.start()
        val mux = MediaMuxer(audioTmp.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1; var started = false
        val bi = MediaCodec.BufferInfo()
        val chunk = ByteArray(8192)
        var samples = 0L
        var inDone = false; var outDone = false
        var idle = 0
        FileInputStream(pcmFile).use { inp ->
            while (!outDone) {
                if (!inDone) {
                    val ii = a.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val ib = a.getInputBuffer(ii)!!
                        ib.clear()
                        val n = readFill(inp, chunk, minOf(chunk.size, ib.capacity() and 3.inv()))
                        if (n <= 0) {
                            a.queueInputBuffer(ii, 0, 0, samples * 1_000_000L / sampleRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            ib.put(chunk, 0, n)
                            a.queueInputBuffer(ii, 0, n, samples * 1_000_000L / sampleRate, 0)
                            samples += n / 4
                        }
                    }
                }
                val oi = a.dequeueOutputBuffer(bi, 10_000)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { track = mux.addTrack(a.outputFormat); mux.start(); started = true }
                    oi >= 0 -> {
                        idle = 0
                        val ob = a.getOutputBuffer(oi)!!
                        if (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) bi.size = 0
                        if (bi.size > 0 && started) { ob.position(bi.offset); ob.limit(bi.offset + bi.size); mux.writeSampleData(track, ob, bi) }
                        a.releaseOutputBuffer(oi, false)
                        if (bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                    else -> if (inDone && ++idle > 1500) error("Audio encoder did not finish")
                }
            }
        }
        a.stop(); a.release()
        if (started) mux.stop()
        mux.release()
    }

    private fun remux(out: File) {
        val m = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val vx = MediaExtractor().apply { setDataSource(videoTmp.path) }
        vx.selectTrack(0)
        val vt = m.addTrack(vx.getTrackFormat(0))
        val ax = MediaExtractor().apply { setDataSource(audioTmp.path) }
        ax.selectTrack(0)
        val at = m.addTrack(ax.getTrackFormat(0))
        m.start()
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val bi = MediaCodec.BufferInfo()
        var vDone = false; var aDone = false
        while (!vDone || !aDone) {
            val useV = !vDone && (aDone || vx.sampleTime <= ax.sampleTime || ax.sampleTime < 0)
            val ex = if (useV) vx else ax
            buf.clear()
            val size = ex.readSampleData(buf, 0)
            if (size < 0) { if (useV) vDone = true else aDone = true; continue }
            bi.set(0, size, ex.sampleTime, ex.sampleFlags)
            m.writeSampleData(if (useV) vt else at, buf, bi)
            ex.advance()
        }
        m.stop(); m.release(); vx.release(); ax.release()
    }

    private fun publish(file: File): String {
        val fname = "$name.mp4"
        return if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fname)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SurvivalVerse")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: error("Could not create file in Movies")
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
            ctx.contentResolver.update(uri, v, null, null)
            "Saved to Movies/SurvivalVerse/$fname (${file.length() / 1024} KB, ${frameIdx} frames)"
        } else {
            val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "SurvivalVerse").apply { mkdirs() }
            val dest = File(dir, fname)
            file.copyTo(dest, overwrite = true)
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), arrayOf("video/mp4"), null)
            "Saved to ${dest.absolutePath} (${file.length() / 1024} KB, ${frameIdx} frames)"
        }
    }

    @Synchronized
    fun cancel() {
        try { enc?.stop() } catch (_: Exception) {}
        try { enc?.release() } catch (_: Exception) {}
        enc = null
        try { if (vStarted) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        muxer = null; vStarted = false
        try { pcmOut?.close() } catch (_: Exception) {}
        pcmOut = null
        listOf(videoTmp, audioTmp, pcmFile, finalTmp).forEach { it.delete() }
    }
}
