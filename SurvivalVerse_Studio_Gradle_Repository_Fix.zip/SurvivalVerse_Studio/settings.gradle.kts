pluginManagement {
    repositories {
        google()
        // Fallback mirror for Maven Central artifacts used by the Android Gradle Plugin.
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        // Fallback mirror for Maven Central artifacts used by AndroidX and tooling.
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        mavenCentral()
    }
}

rootProject.name = "SurvivalVerseStudio"
include(":app")
