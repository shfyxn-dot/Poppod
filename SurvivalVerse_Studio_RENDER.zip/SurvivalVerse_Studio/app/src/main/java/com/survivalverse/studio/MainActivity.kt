package com.survivalverse.studio

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var renderer: Mp4Renderer
    private var chooserCb: ValueCallback<Array<Uri>>? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooserCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        chooserCb = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // never sleep mid-render
        renderer = Mp4Renderer(applicationContext)
        web = WebView(this)
        setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "SVNative")
        web.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                chooserCb?.onReceiveValue(null)
                chooserCb = cb
                return try { chooser.launch(params.createIntent()); true } catch (e: Exception) { chooserCb = null; false }
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onDestroy() { renderer.cancel(); super.onDestroy() }

    private fun safe(name: String) = name.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(80).ifBlank { "file" }

    inner class Bridge {
        // ---- projects ----
        @android.webkit.JavascriptInterface fun saveProject(name: String, data: String): String {
            val s = safe(name).take(48)
            val dir = File(filesDir, "projects/$s").apply { mkdirs() }
            File(dir, "project.json").writeText(data)
            return "Saved ${dir.absolutePath}"
        }
        @android.webkit.JavascriptInterface fun loadProject(name: String): String {
            val f = File(filesDir, "projects/${safe(name).take(48)}/project.json")
            return if (f.exists()) f.readText() else ""
        }

        // ---- export any small file (SRT, PNG, JSON) to Downloads/SurvivalVerse ----
        @android.webkit.JavascriptInterface fun exportFile(name: String, mime: String, b64: String): String = try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val fname = safe(name)
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fname)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SurvivalVerse")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                "Saved to Downloads/SurvivalVerse/$fname"
            } else {
                val dir = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SurvivalVerse").apply { mkdirs() }
                File(dir, fname).writeBytes(bytes)
                "Saved to ${File(dir, fname).absolutePath}"
            }
        } catch (e: Exception) { "ERR: ${e.message}" }

        // ---- MP4 render ----
        @android.webkit.JavascriptInterface fun beginRender(json: String): String = try {
            val o = JSONObject(json)
            renderer.begin(
                o.getInt("w"), o.getInt("h"), o.getInt("fps"), o.getInt("bitrate"),
                o.getBoolean("hasAudio"), o.optInt("sampleRate", 44100), o.optString("name", "episode")
            )
            "ok"
        } catch (e: Throwable) { renderer.cancel(); "ERR: begin failed: ${e.message}" }

        @android.webkit.JavascriptInterface fun pushFrame(b64: String): String = try {
            renderer.pushFrame(Base64.decode(b64, Base64.DEFAULT)); "ok"
        } catch (e: Throwable) { "ERR: frame failed: ${e.message}" }

        @android.webkit.JavascriptInterface fun audioChunk(b64: String): String = try {
            renderer.audioChunk(Base64.decode(b64, Base64.DEFAULT)); "ok"
        } catch (e: Throwable) { "ERR: audio failed: ${e.message}" }

        @android.webkit.JavascriptInterface fun finishRender(): String = try {
            "ok: " + renderer.finish()
        } catch (e: Throwable) { renderer.cancel(); "ERR: finish failed: ${e.message}" }

        @android.webkit.JavascriptInterface fun cancelRender() { renderer.cancel() }
    }
}
