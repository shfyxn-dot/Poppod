(function () {
  const SV = window.SV, A = SV.audio;
  const $ = (id) => document.getElementById(id);
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = (s) => { s = Math.max(0, s); return Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0"); };

  const DEMO = `[SCENE: CITY_NIGHT_OPENING]
[BG: city night]
[WEATHER: rain]
[CAPTION: DAY 1 - 6:42 AM]
[MUSIC: low_ambient | volume=0.25]
[NARRATOR: am_michael | speed=0.9]
The city was quiet that morning.
[SCENE: FIRST_WARNING]
[CHARACTER: MARINA | expression=worried]
[POSE: walk]
Then every phone in the building started ringing.
[SFX: phone_alert | volume=0.7]
[HUD: HEART=112]
[NARRATOR: am_michael]
You have thirty seconds to decide where to go.
[CAMERA: slow_push_in]
[SCENE: THE_HORDE]
[BG: city dusk]
[WEATHER: storm]
[CHARACTER: MARINA | expression=scared]
[POSE: run]
[ZOMBIES: 6 | mode=approach | side=right]
[SFX: thunder_crack]
Run! They are right behind us!
[HUD: HEART=168]
[NARRATOR]
Marina looked back and saw the whole street moving.
[CAMERA: shake | dur=1.5]
[SCENE: BUNKER_DOOR]
[BG: bunker]
[CHARACTER: MARINA | expression=tired]
[POSE: idle]
Not yet. But we are alive.
[SCENE: FOREST_ROAD]
[BG: forest fog]
[WEATHER: fog]
[ZOMBIES: 3 | mode=silhouette]
[NARRATOR]
Somewhere in the fog, something was walking.`;

  const P = {
    name: "SILENT_CITY_EPISODE_01", script: DEMO, srt: "", trackMeta: [],
    settings: { duck: true, duckLevel: 30, res: "1080x1920", fps: "30", br: "10" },
  };
  let comp = null, mixCache = null, mixKey = "";
  window.__P = P; window.__comp = () => comp;

  /* ---------- native-aware file save ---------- */
  async function saveFile(name, mime, data) {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
    if (window.SVNative && SVNative.exportFile) {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      return SVNative.exportFile(name, mime, SV.b64(bytes));
    }
    const a = document.createElement("a"), u = URL.createObjectURL(blob);
    a.href = u; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(u), 1500);
    return "Downloaded " + name;
  }

  /* ---------- tabs ---------- */
  document.querySelectorAll("#nav button").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));
  function showTab(id) {
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.id === id));
    document.querySelectorAll("#nav button").forEach((b) => b.classList.toggle("on", b.dataset.tab === id));
    if (id !== "preview") stopPreview();
    if (id === "story") buildSheet();
    if (id === "preview") drawPreview(pv.t);
    if (id === "audio") renderAudioUI();
  }

  /* ---------- build ---------- */
  function rebuild() {
    P.script = $("src").value;
    const cues = P.srt ? SV.parseSRT(P.srt) : null;
    comp = SV.compile(SV.parseScript(P.script), { cues, narrationDuration: A.narrationDuration() });
    mixCache = null; sheetDirty = true;
    $("sc").textContent = comp.stats.scenes; $("ln").textContent = comp.stats.lines; $("dur").textContent = comp.duration.toFixed(1) + "s";
    $("status").textContent = `Built ${comp.stats.scenes} scenes · ${comp.stats.lines} lines · timing from ${comp.timingSource}.`;
    $("warns").innerHTML = comp.warnings.map((w) => `<span class="warn">⚠ ${esc(w)}</span>`).join("<br>");
    const rows = [];
    comp.scenes.forEach((s) => {
      rows.push(`── SCENE ${s.index + 1} ${s.name}  ${s.start.toFixed(2)}–${s.end.toFixed(2)}s  [${s.bg.type}/${s.bg.mood}]  cast: ${s.cast.map((c) => c.name).join(", ")}`);
      s.lines.forEach((l) => rows.push(`   ${l.start.toFixed(2)}s  ${l.speaker}: ${l.text}`));
      s.events.forEach((e) => rows.push(`   ${e.t.toFixed(2)}s  [${e.type}] ${e.name || e.value || e.text || (e.kv ? JSON.stringify(e.kv) : "")}`));
    });
    $("events").textContent = rows.join("\n");
    $("srt").textContent = SV.formatSRT(comp.cues);
    $("tsrc").textContent = "Timing source: " + comp.timingSource;
    $("pscene").innerHTML = comp.scenes.map((s) => `<option value="${s.start}">${s.index + 1}. ${esc(s.name)}</option>`).join("");
    $("scrub").max = Math.round(comp.duration * 100);
    pv.t = Math.min(pv.t, comp.duration - 0.01); drawPreview(pv.t); updateTime();
    renderAudioUI(); autosave();
  }
  $("build").onclick = rebuild;
  $("demo").onclick = () => { $("src").value = DEMO; rebuild(); };

  /* ---------- audio UI ---------- */
  async function addFiles(input, kind) {
    const files = Array.from(input.files || []); input.value = "";
    for (const f of files) {
      $("audioMsg").textContent = "Decoding " + f.name + "…";
      try {
        const t = await A.addFile(f, kind);
        const m = P.trackMeta.find((x) => x.name === t.name && x.kind === t.kind);
        if (m) { t.offset = m.offset; t.volume = m.volume; }
        $("audioMsg").textContent = `Added ${f.name} (${t.duration.toFixed(1)}s).`;
      } catch (e) { $("audioMsg").innerHTML = `<span class="bad">Could not decode ${esc(f.name)}: ${esc(e && e.message || e)}</span>`; }
    }
    rebuild();
  }
  $("inNarr").onchange = (e) => addFiles(e.target, "narration");
  $("inMusic").onchange = (e) => addFiles(e.target, "music");
  $("inSfx").onchange = (e) => addFiles(e.target, "sfx");
  $("inSrt").onchange = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = () => { const cues = SV.parseSRT(r.result); if (!cues.length) { $("srtMsg").innerHTML = '<span class="bad">No cues found in that file.</span>'; return; } P.srt = r.result; rebuild(); };
    r.readAsText(f); e.target.value = "";
  };
  $("clearSrt").onclick = () => { P.srt = ""; rebuild(); };
  $("duck").onchange = () => { P.settings.duck = $("duck").checked; mixCache = null; autosave(); };
  $("duckL").oninput = () => { P.settings.duckLevel = +$("duckL").value; $("duckV").textContent = $("duckL").value; mixCache = null; autosave(); };

  function syncMeta() {
    P.trackMeta = A.tracks.map((t) => ({ name: t.name, kind: t.kind, offset: t.offset, volume: t.volume }));
  }
  function renderAudioUI() {
    $("srtMsg").innerHTML = P.srt ? `<span class="ok">SRT loaded: ${comp ? comp.cues.length : "?"} cues.</span>` : "No SRT imported — timing is estimated from text.";
    $("tracks").innerHTML = A.tracks.map((t) => `<div class="track" data-id="${t.id}"><b>${t.kind.toUpperCase()}</b> ${esc(t.name)} <span class="muted">${t.duration.toFixed(1)}s</span>
      <div class="row"><div><label>Start offset (s)</label><input type="number" step="0.1" data-k="offset" value="${t.offset.toFixed(2)}"></div>
      <div><label>Volume</label><input type="number" step="0.05" min="0" max="2" data-k="volume" value="${t.volume}"></div>
      <button class="danger" data-del="1">Remove</button></div></div>`).join("") || '<p class="muted">No audio imported yet. You can still render a silent video.</p>';
    $("tracks").querySelectorAll(".track").forEach((el) => {
      const id = +el.dataset.id;
      el.querySelectorAll("input").forEach((inp) => (inp.onchange = () => {
        const t = A.tracks.find((x) => x.id === id); t[inp.dataset.k] = parseFloat(inp.value) || 0; A.invalidate(); mixCache = null;
        if (t.kind === "narration") rebuild(); else { syncMeta(); autosave(); }
      }));
      el.querySelector("[data-del]").onclick = () => { A.remove(id); rebuild(); };
    });
    syncMeta();
    if (comp) {
      const rep = A.matchReport(comp);
      $("match").innerHTML = rep.length ? rep.map((r) => `${r.ok ? '<span class="ok">✓</span>' : '<span class="bad">✗</span>'} ${r.type} <b>${esc(r.name)}</b>${r.fallback ? " (using your first music file)" : ""}${r.ok ? "" : " — no file named like this"}`).join("<br>") : "No SFX/MUSIC tags in the script.";
    }
  }

  async function getMix() {
    if (!A.hasAudio()) return null;
    const key = JSON.stringify([comp.duration, P.settings.duck, P.settings.duckLevel, A.tracks.map((t) => [t.id, t.offset, t.volume]), comp.sfx, comp.music]);
    if (mixCache && mixKey === key) return mixCache;
    mixCache = await A.mix(comp, { duck: P.settings.duck, duckLevel: P.settings.duckLevel / 100 }); mixKey = key;
    return mixCache;
  }

  /* ---------- preview ---------- */
  const pvc = $("pv"), pvg = pvc.getContext("2d");
  const pv = { t: 0, playing: false, raf: 0 };
  function drawPreview(t) {
    if (!comp) return;
    try { pvg.setTransform(pvc.width / SV.W, 0, 0, pvc.height / SV.H, 0, 0); SV.drawFrame(pvg, comp, t); $("pmsg").textContent = ""; }
    catch (e) { $("pmsg").innerHTML = `<span class="bad">Frame error: ${esc(e.message)}</span>`; }
  }
  function updateTime() { $("ptime").textContent = `${fmt(pv.t)} / ${fmt(comp ? comp.duration : 0)}`; $("scrub").value = Math.round(pv.t * 100); }
  function loop() {
    if (!pv.playing) return;
    pv.t = A.player.time();
    if (pv.t >= comp.duration) { stopPreview(); pv.t = 0; drawPreview(0); updateTime(); return; }
    drawPreview(pv.t); updateTime(); pv.raf = requestAnimationFrame(loop);
  }
  async function startPreview() {
    if (pv.playing) return;
    $("pmsg").textContent = A.hasAudio() ? "Mixing audio…" : "";
    let mix = null;
    try { mix = await getMix(); } catch (e) { $("pmsg").innerHTML = `<span class="bad">Audio mix failed: ${esc(e.message)}</span>`; }
    $("pmsg").textContent = "";
    A.player.play(mix, pv.t); pv.playing = true; $("pplay").textContent = "⏸ Pause"; loop();
  }
  function stopPreview() { if (pv.playing) { pv.t = A.player.time(); } A.player.stop(); pv.playing = false; cancelAnimationFrame(pv.raf); $("pplay").textContent = "▶ Play"; }
  $("pplay").onclick = () => (pv.playing ? stopPreview() : startPreview());
  $("pstop").onclick = () => { stopPreview(); pv.t = 0; drawPreview(0); updateTime(); };
  $("scrub").oninput = () => { const was = pv.playing; if (was) stopPreview(); pv.t = $("scrub").value / 100; drawPreview(pv.t); updateTime(); if (was) startPreview(); };
  $("pscene").onchange = () => { const was = pv.playing; if (was) stopPreview(); pv.t = +$("pscene").value + 0.05; drawPreview(pv.t); updateTime(); if (was) startPreview(); };

  /* ---------- storyboard ---------- */
  let sheetDirty = true;
  function buildSheet() {
    if (!comp || !sheetDirty) return;
    sheetDirty = false;
    const box = $("sheet"); box.innerHTML = "";
    comp.scenes.forEach((s, i) => {
      const c = document.createElement("canvas"); c.width = 270; c.height = 480;
      try { SV.drawThumb(comp, i, c); } catch (e) { /* shown in preflight */ }
      const d = document.createElement("div"); d.className = "shot"; d.appendChild(c);
      const l = document.createElement("div"); l.textContent = `${i + 1}. ${s.name} · ${s.start.toFixed(1)}–${s.end.toFixed(1)}s`; d.appendChild(l); box.appendChild(d);
    });
  }
  $("sheetOut").onclick = async () => {
    const n = comp.scenes.length, cols = 4, rows = Math.ceil(n / cols), cw = 270, ch = 480, lh = 40;
    const c = document.createElement("canvas"); c.width = cols * cw; c.height = rows * (ch + lh);
    const g = c.getContext("2d"); g.fillStyle = "#080d15"; g.fillRect(0, 0, c.width, c.height);
    comp.scenes.forEach((s, i) => {
      const t = document.createElement("canvas"); t.width = cw; t.height = ch; SV.drawThumb(comp, i, t);
      const x = (i % cols) * cw, y = Math.floor(i / cols) * (ch + lh);
      g.drawImage(t, x, y); g.fillStyle = "#fff"; g.font = "bold 16px sans-serif"; g.fillText(`${i + 1}. ${s.name}`.slice(0, 26), x + 8, y + ch + 26);
    });
    const blob = await new Promise((r) => c.toBlob(r, "image/png"));
    $("status").textContent = await saveFile("survivalverse-contact-sheet.png", "image/png", blob);
  };

  /* ---------- timeline exports ---------- */
  $("srtOut").onclick = async () => { $("tsrc").textContent = await saveFile((P.name || "episode") + ".srt", "text/plain", SV.formatSRT(comp.cues)); };
  $("srtCopy").onclick = () => navigator.clipboard && navigator.clipboard.writeText(SV.formatSRT(comp.cues));

  /* ---------- render ---------- */
  const log = (m) => { const e = $("rlog"); e.textContent += "\n" + m; e.scrollTop = e.scrollHeight; };
  async function doRender(test) {
    if (!SV.render.available()) { $("rstat").innerHTML = '<span class="bad">MP4 export only works inside the Android app (this is a plain browser).</span>'; return; }
    rebuild();
    const [w, h] = (test ? "540x960" : $("res").value).split("x").map(Number);
    const fps = +$("fps").value, br = +$("br").value * 1e6;
    const from = test ? 0 : +$("rfrom").value || 0, to = test ? 6 : +$("rto").value || 0;
    $("rgo").disabled = $("rtest").disabled = true; $("rcancel").disabled = false; $("rlog").textContent = "Render log"; $("rbar").style.width = "0";
    try {
      let mix = null;
      if (A.hasAudio()) { $("rstat").textContent = "Mixing audio…"; log("Mixing narration/music/SFX with ducking…"); mix = await getMix(); log(`Mix ready (peak ${mix._peak.toFixed(2)}).`); }
      else log("No audio imported → silent video.");
      log(`Rendering ${w}×${h} @ ${fps}fps, ${comp.scenes.length} scenes, ${comp.duration.toFixed(1)}s total.`);
      const name = (P.name || "episode").replace(/[^A-Za-z0-9_-]/g, "_") + (test ? "_TEST" : "") + "_" + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, "");
      const res = await SV.render.run(comp, mix, { w, h, fps, bitrate: br, name, from, to }, (p) => {
        if (p.phase === "frames") { $("rbar").style.width = (p.i / p.n * 92).toFixed(1) + "%"; $("rstat").textContent = `Frame ${p.i}/${p.n} · ${p.fps.toFixed(1)} fps · ${fmt(p.eta)} left`; }
        else if (p.phase === "audio") { $("rstat").textContent = "Sending audio…"; $("rbar").style.width = "94%"; }
        else { $("rstat").textContent = "Encoding audio + muxing MP4…"; $("rbar").style.width = "97%"; }
      });
      $("rbar").style.width = "100%"; $("rstat").innerHTML = `<span class="ok">Done.</span> ${esc(res)}`; log("DONE: " + res);
    } catch (e) {
      $("rstat").innerHTML = `<span class="bad">Render failed.</span>`; log("ERROR: " + (e && e.message || e));
    } finally { $("rgo").disabled = $("rtest").disabled = false; $("rcancel").disabled = true; }
  }
  $("rgo").onclick = () => doRender(false);
  $("rtest").onclick = () => doRender(true);
  $("rcancel").onclick = () => { SV.render.cancelled = true; };

  /* ---------- project ---------- */
  function snapshot() { P.name = $("name").value; P.script = $("src").value; syncMeta(); P.settings.res = $("res").value; P.settings.fps = $("fps").value; P.settings.br = $("br").value; return JSON.stringify(P); }
  function autosave() { try { localStorage.setItem("sv_project2", snapshot()); } catch (e) { } }
  function load(obj) {
    Object.assign(P, obj); P.settings = Object.assign({ duck: true, duckLevel: 30, res: "1080x1920", fps: "30", br: "10" }, obj.settings || {});
    $("src").value = P.script || DEMO; $("name").value = P.name || "episode";
    $("duck").checked = P.settings.duck; $("duckL").value = P.settings.duckLevel; $("duckV").textContent = P.settings.duckLevel;
    $("res").value = P.settings.res; $("fps").value = P.settings.fps; $("br").value = P.settings.br;
    A.tracks.forEach((t) => { const m = (P.trackMeta || []).find((x) => x.name === t.name && x.kind === t.kind); if (m) { t.offset = m.offset; t.volume = m.volume; } });
    rebuild();
  }
  $("save").onclick = () => { const s = snapshot(); autosave(); try { $("saveStatus").textContent = SVNative.saveProject(P.name, s); } catch (e) { $("saveStatus").textContent = "Saved to browser autosave."; } };
  $("jsonOut").onclick = async () => { $("saveStatus").textContent = await saveFile((P.name || "project") + ".json", "application/json", snapshot()); };
  $("jsonIn").onchange = (e) => {
    const f = e.target.files[0]; if (!f) return; const r = new FileReader();
    r.onload = () => { try { load(JSON.parse(r.result)); $("saveStatus").textContent = "Imported " + f.name; } catch (x) { $("saveStatus").textContent = "Invalid project JSON"; } };
    r.readAsText(f); e.target.value = "";
  };
  $("restore").onclick = () => {
    let x = null; try { x = localStorage.getItem("sv_project2"); } catch (e) { }
    if (x) { load(JSON.parse(x)); $("saveStatus").textContent = "Restored autosave."; } else $("saveStatus").textContent = "No autosave found.";
  };
  $("src").addEventListener("input", () => { try { localStorage.setItem("sv_draft", $("src").value); } catch (e) { } });

  /* ---------- boot ---------- */
  let boot = null; try { boot = localStorage.getItem("sv_project2"); } catch (e) { }
  if (boot) { try { load(JSON.parse(boot)); } catch (e) { $("src").value = DEMO; rebuild(); } } else { $("src").value = DEMO; rebuild(); }
  showTab("script");
})();
