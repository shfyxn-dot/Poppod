(function () {
  const SV = window.SV, A = SV.audio, LIB = SV.lib;
  const $ = (id) => document.getElementById(id);
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = (s) => { s = Math.max(0, s); return Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0"); };

  const DEMO = `YOU KEPT THE ZOMBIES OUTSIDE.
BUT YOU FORGOT TO LOCK ONE DOOR.
AND NOW... SOMETHING IS INSIDE YOUR HOME.
[narrator] Your best friend knocked twice more.
[ALEX] Please... open the door.
[narrator] You waited for him to speak.
But nothing.
Just silence.
[narrator] Then you heard it.
One footstep.
Right behind you.
[narrator] You rushed towards the backdoor.
The door was slightly open.
Then you spotted an open elevator.
You have two choices.
A — Close the backdoor and push a heavy cabinet against it.
B — Run into the elevator and head downstairs towards the alley.
THEY CAN HEAR YOUR HEARTBEAT.
COMMENT A OR B.`;

  const DEFAULTS = { look: "studio", style: "silent", mainName: "", autoMode: "auto", density: "normal", autoHud: "auto", narratorOnScreen: false, narratorLips: true, autoSfx: true, autoMusic: true, hbeat: true, duck: true, duckLevel: 30, res: "1080x1920", fps: "30", br: "10" };
  const P = { name: "MY_EPISODE", script: DEMO, srt: "", trackMeta: [], voices: {}, settings: Object.assign({}, DEFAULTS) };
  let comp = null, mixCache = null, mixKey = "";
  window.__P = P; window.__comp = () => comp;

  /* ---------- native-aware file save ---------- */
  async function saveFile(name, mime, data) {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
    if (window.SVNative && SVNative.exportFile) { const bytes = new Uint8Array(await blob.arrayBuffer()); return SVNative.exportFile(name, mime, SV.b64(bytes)); }
    const a = document.createElement("a"), u = URL.createObjectURL(blob);
    a.href = u; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(u), 1500);
    return "Downloaded " + name;
  }

  /* ---------- tabs ---------- */
  document.querySelectorAll("#nav button").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));
  function showTab(id) {
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.id === id));
    document.querySelectorAll("#nav button").forEach((b) => b.classList.toggle("on", b.dataset.tab === id));
    if (id !== "preview") stopPreview();
    if (id === "story") buildSheet();
    if (id === "preview") drawPreview(pv.t);
    if (id === "audio") renderAudioUI();
    if (id === "library") renderLibrary();
    if (id === "voices") loadVoices();
  }

  /* ---------- settings ---------- */
  const S = P.settings;
  const BOOLS = ["narratorOnScreen", "narratorLips", "autoSfx", "autoMusic", "hbeat"];
  const SELS = ["look", "style", "autoMode", "density", "autoHud"];
  function settingsToUI() {
    $("mainName").value = S.mainName || "";
    BOOLS.forEach((k) => ($(k).checked = !!S[k])); SELS.forEach((k) => ($(k).value = S[k]));
    $("duck").checked = S.duck; $("duckL").value = S.duckLevel; $("duckV").textContent = S.duckLevel;
    $("res").value = S.res; $("fps").value = S.fps; $("br").value = S.br;
  }
  $("mainName").onchange = () => { S.mainName = $("mainName").value.trim().toUpperCase(); rebuild(); };
  BOOLS.forEach((k) => ($(k).onchange = () => { S[k] = $(k).checked; rebuild(); }));
  SELS.forEach((k) => ($(k).onchange = () => { S[k] = $(k).value; rebuild(); }));

  function ctxOpts() {
    return {
      cues: P.srt ? SV.parseSRT(P.srt) : null, narrationDuration: A.narrationDuration(),
      mainName: S.mainName || LIB.mainChar(), narratorOnScreen: S.narratorOnScreen || !!(SV.charAssets.NARRATOR && S.narratorOnScreen),
      narratorLips: S.narratorLips, autoMode: S.autoMode, density: S.density, autoSfx: S.autoSfx, autoHud: S.autoHud, autoMusic: S.autoMusic, heartbeatSfx: S.hbeat, look: S.look, style: S.style,
    };
  }

  /* ---------- build ---------- */
  function rebuild() {
    P.script = $("src").value;
    comp = SV.compile(SV.parseScript(P.script), ctxOpts());
    mixCache = null; sheetDirty = true;
    $("sc").textContent = comp.stats.scenes; $("ln").textContent = comp.stats.lines; $("dur").textContent = comp.duration.toFixed(1) + "s";
    $("status").textContent = `Built ${comp.stats.scenes} shots · ${comp.stats.lines} lines · ${comp.auto ? "auto-directed · " : ""}timing from ${comp.timingSource} · main: ${comp.heroName}`;
    $("warns").innerHTML = comp.warnings.map((w) => `<span class="warn">⚠ ${esc(w)}</span>`).join("<br>");
    const rows = [];
    comp.scenes.forEach((s) => {
      rows.push(`── SHOT ${s.index + 1} ${s.name}  ${s.start.toFixed(2)}–${s.end.toFixed(2)}s  [${s.bg.type}${s.bg.name ? ":" + s.bg.name : ""}/${s.bg.mood}${s.bg.variant ? "/" + s.bg.variant : ""}]  cast: ${s.cast.map((c) => c.name).join(", ")}`);
      s.lines.forEach((l) => rows.push(`   ${l.start.toFixed(2)}s  ${l.speaker}: ${l.text}`));
      s.events.forEach((e) => rows.push(`   ${e.t.toFixed(2)}s  [${e.type}] ${e.name || e.value || e.text || (e.kv ? JSON.stringify(e.kv) : "")}`));
    });
    $("events").textContent = rows.join("\n");
    $("srt").textContent = SV.formatSRT(comp.cues);
    $("tsrc").textContent = "Timing source: " + comp.timingSource;
    $("pscene").innerHTML = comp.scenes.map((s) => `<option value="${s.start}">${s.index + 1}. ${esc(s.name)}</option>`).join("");
    $("scrub").max = Math.round(comp.duration * 100);
    pv.t = Math.min(pv.t, comp.duration - 0.01); drawPreview(pv.t); updateTime();
    renderAudioUI(); autosave();
  }
  $("build").onclick = rebuild;
  $("demo").onclick = () => { $("src").value = DEMO; rebuild(); };

  /* ---------- audio UI ---------- */
  async function addFiles(input, kind) {
    const files = Array.from(input.files || []); input.value = "";
    for (const f of files) {
      $("audioMsg").textContent = "Decoding " + f.name + "…";
      try {
        const t = await A.addFile(f, kind);
        const m = P.trackMeta.find((x) => x.name === t.name && x.kind === t.kind);
        if (m && kind === "narration") { t.offset = m.offset; t.volume = m.volume; }
        if (kind !== "narration") await LIB.saveAudio(t);
        $("audioMsg").textContent = `Added ${f.name} (${t.duration.toFixed(1)}s)${t.lib ? " — saved in your Library for every episode" : ""}.`;
      } catch (e) { $("audioMsg").innerHTML = `<span class="bad">Could not decode ${esc(f.name)}: ${esc(e && e.message || e)}</span>`; }
    }
    rebuild();
  }
  $("inNarr").onchange = (e) => addFiles(e.target, "narration");
  $("inMusic").onchange = (e) => addFiles(e.target, "music");
  $("inSfx").onchange = (e) => addFiles(e.target, "sfx");
  $("inSrt").onchange = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = () => { const cues = SV.parseSRT(r.result); if (!cues.length) { $("srtMsg").innerHTML = '<span class="bad">No cues found in that file.</span>'; return; } P.srt = r.result; rebuild(); };
    r.readAsText(f); e.target.value = "";
  };
  $("clearSrt").onclick = () => { P.srt = ""; rebuild(); };
  $("duck").onchange = () => { S.duck = $("duck").checked; mixCache = null; autosave(); };
  $("duckL").oninput = () => { S.duckLevel = +$("duckL").value; $("duckV").textContent = $("duckL").value; mixCache = null; autosave(); };

  function syncMeta() { P.trackMeta = A.tracks.filter((t) => t.kind === "narration").map((t) => ({ name: t.name, kind: t.kind, offset: t.offset, volume: t.volume })); }
  function renderAudioUI() {
    $("srtMsg").innerHTML = P.srt ? `<span class="ok">SRT loaded: ${comp ? comp.cues.length : "?"} cues.</span>` : "No SRT imported — timing is estimated from text (or generated by Voices).";
    $("tracks").innerHTML = A.tracks.map((t) => `<div class="track" data-id="${t.id}"><b>${t.kind.toUpperCase()}</b> ${esc(t.name)} <span class="muted">${t.duration.toFixed(1)}s${t.lib ? " · in Library" : ""}</span>
      <div class="row"><div><label>Start offset (s)</label><input type="number" step="0.1" data-k="offset" value="${t.offset.toFixed(2)}"></div>
      <div><label>Volume</label><input type="number" step="0.05" min="0" max="2" data-k="volume" value="${t.volume}"></div>
      <button class="danger" data-del="1">Remove</button></div></div>`).join("") || '<p class="muted">No audio files. Built-in music, SFX and heartbeat are generated automatically (see Script → Direction).</p>';
    $("tracks").querySelectorAll(".track").forEach((el) => {
      const id = +el.dataset.id;
      el.querySelectorAll("input").forEach((inp) => (inp.onchange = async () => {
        const t = A.tracks.find((x) => x.id === id); t[inp.dataset.k] = parseFloat(inp.value) || 0; A.invalidate(); mixCache = null;
        if (t.lib) await LIB.saveAudio(t);
        if (t.kind === "narration") rebuild(); else { syncMeta(); autosave(); }
      }));
      el.querySelector("[data-del]").onclick = async () => { const t = A.tracks.find((x) => x.id === id); if (t && t.lib) await LIB.deleteAudio(t); A.remove(id); rebuild(); };
    });
    syncMeta();
    if (comp) {
      const rep = A.matchReport(comp);
      $("match").innerHTML = rep.length ? rep.map((r) => `${r.ok ? '<span class="ok">✓</span>' : '<span class="bad">✗</span>'} ${r.type} <b>${esc(r.name)}</b>${r.builtin ? " (built-in sound)" : ""}${r.fallback ? " (using your first music file)" : ""}`).join("<br>") : "No SFX/MUSIC cues in the script.";
    }
  }

  const needsAudio = () => A.hasAudio() || (comp && (comp.sfx.length || comp.music.length || comp.beats.length || comp.settings.autoMusic));
  async function getMix() {
    if (!needsAudio()) return null;
    const key = JSON.stringify([comp.duration, S.duck, S.duckLevel, S.hbeat, S.autoMusic, A.tracks.map((t) => [t.id, t.offset, t.volume]), comp.sfx, comp.music, comp.beats.length]);
    if (mixCache && mixKey === key) return mixCache;
    mixCache = await A.mix(comp, { duck: S.duck, duckLevel: S.duckLevel / 100 }); mixKey = key;
    return mixCache;
  }

  /* ---------- preview ---------- */
  const pvc = $("pv"), pvg = pvc.getContext("2d");
  const pv = { t: 0, playing: false, raf: 0 };
  function drawPreview(t) {
    if (!comp) return;
    try { pvg.setTransform(pvc.width / SV.W, 0, 0, pvc.height / SV.H, 0, 0); SV.drawFrame(pvg, comp, t); $("pmsg").textContent = ""; }
    catch (e) { $("pmsg").innerHTML = `<span class="bad">Frame error: ${esc(e.message)}</span>`; }
  }
  function updateTime() { $("ptime").textContent = `${fmt(pv.t)} / ${fmt(comp ? comp.duration : 0)}`; $("scrub").value = Math.round(pv.t * 100); }
  function loop() {
    if (!pv.playing) return;
    pv.t = A.player.time();
    if (pv.t >= comp.duration) { stopPreview(); pv.t = 0; drawPreview(0); updateTime(); return; }
    drawPreview(pv.t); updateTime(); pv.raf = requestAnimationFrame(loop);
  }
  async function startPreview() {
    if (pv.playing) return;
    $("pmsg").textContent = "Mixing audio…";
    let mix = null;
    try { mix = await getMix(); } catch (e) { $("pmsg").innerHTML = `<span class="bad">Audio mix failed: ${esc(e.message)}</span>`; }
    $("pmsg").textContent = "";
    A.player.play(mix, pv.t); pv.playing = true; $("pplay").textContent = "⏸ Pause"; loop();
  }
  function stopPreview() { if (pv.playing) { pv.t = A.player.time(); } A.player.stop(); pv.playing = false; cancelAnimationFrame(pv.raf); $("pplay").textContent = "▶ Play"; }
  $("pplay").onclick = () => (pv.playing ? stopPreview() : startPreview());
  $("pstop").onclick = () => { stopPreview(); pv.t = 0; drawPreview(0); updateTime(); };
  $("scrub").oninput = () => { const was = pv.playing; if (was) stopPreview(); pv.t = $("scrub").value / 100; drawPreview(pv.t); updateTime(); if (was) startPreview(); };
  $("pscene").onchange = () => { const was = pv.playing; if (was) stopPreview(); pv.t = +$("pscene").value + 0.05; drawPreview(pv.t); updateTime(); if (was) startPreview(); };

  /* ---------- storyboard ---------- */
  let sheetDirty = true;
  function buildSheet() {
    if (!comp || !sheetDirty) return;
    sheetDirty = false;
    const box = $("sheet"); box.innerHTML = "";
    comp.scenes.forEach((s, i) => {
      const c = document.createElement("canvas"); c.width = 270; c.height = 480;
      try { SV.drawThumb(comp, i, c); } catch (e) { /* surfaced by preflight */ }
      const d = document.createElement("div"); d.className = "shot"; d.appendChild(c);
      const l = document.createElement("div"); l.textContent = `${i + 1}. ${s.name} · ${s.start.toFixed(1)}–${s.end.toFixed(1)}s`; d.appendChild(l); box.appendChild(d);
    });
  }
  $("sheetOut").onclick = async () => {
    const n = comp.scenes.length, cols = 4, rows = Math.ceil(n / cols), cw = 270, ch = 480, lh = 40;
    const c = document.createElement("canvas"); c.width = cols * cw; c.height = rows * (ch + lh);
    const g = c.getContext("2d"); g.fillStyle = "#080d15"; g.fillRect(0, 0, c.width, c.height);
    comp.scenes.forEach((s, i) => {
      const t = document.createElement("canvas"); t.width = cw; t.height = ch; SV.drawThumb(comp, i, t);
      const x = (i % cols) * cw, y = Math.floor(i / cols) * (ch + lh);
      g.drawImage(t, x, y); g.fillStyle = "#fff"; g.font = "bold 16px sans-serif"; g.fillText(`${i + 1}. ${s.name}`.slice(0, 26), x + 8, y + ch + 26);
    });
    const blob = await new Promise((r) => c.toBlob(r, "image/png"));
    $("status").textContent = await saveFile("survivalverse-contact-sheet.png", "image/png", blob);
  };

  /* ---------- timeline exports ---------- */
  $("srtOut").onclick = async () => { $("tsrc").textContent = await saveFile((P.name || "episode") + ".srt", "text/plain", SV.formatSRT(comp.cues)); };
  $("srtCopy").onclick = () => navigator.clipboard && navigator.clipboard.writeText(SV.formatSRT(comp.cues));

  /* ---------- library: characters ---------- */
  let thumbUrls = [];
  const thumb = (blob) => { const u = URL.createObjectURL(blob); thumbUrls.push(u); return u; };
  function renderLibrary() { renderChars(); renderBgs(); }
  function renderChars() {
    thumbUrls.forEach((u) => URL.revokeObjectURL(u)); thumbUrls = [];
    const list = LIB.listChars();
    $("chars").innerHTML = list.map((c) => `<div class="track" data-n="${esc(c.name)}"><b>${esc(c.name)}</b> <span class="chip">${c.role}</span>${c.slots.idle && c.slots.talk ? '<span class="chip">lip-sync ✓</span>' : '<span class="chip warn">add Idle + Talking</span>'}
      <button class="danger" data-delchar="1" style="float:right;margin-top:0">Delete</button>
      <div class="row"><div><label>Height on screen (px of 1920)</label><input type="number" data-ck="height" value="${c.height}" step="20"></div>
      <div><label>Move up(−)/down(+) px</label><input type="number" data-ck="yOff" value="${c.yOff}" step="10"></div>
      <label class="chk" style="flex:1"><input type="checkbox" data-ck="facesLeft" ${c.facesLeft ? "checked" : ""}> My image faces LEFT</label></div>
      <div class="slots">${LIB.SLOTS.map(([k, label, req]) => `<div class="slot" data-slot="${k}">${c.slots[k] ? `<img class="thumb" src="${thumb(c.slots[k])}">` : '<div class="thumb"></div>'}<span>${label}${req ? " *" : ""}</span>
        <label class="file">${c.slots[k] ? "Change" : "Choose"}<input type="file" accept="image/png,image/*"></label>${c.slots[k] ? '<button class="danger" data-clr="1">✕</button>' : ""}</div>`).join("")}</div></div>`).join("") || '<p class="muted">No characters yet. Without PNGs the app draws a built-in stickman.</p>';
    $("chars").querySelectorAll(".track").forEach((el) => {
      const name = el.dataset.n;
      el.querySelector("[data-delchar]").onclick = async () => { if (confirm("Delete " + name + "?")) { await LIB.deleteChar(name); renderChars(); rebuild(); } };
      el.querySelectorAll("[data-ck]").forEach((inp) => (inp.onchange = async () => {
        const k = inp.dataset.ck; await LIB.updateChar(name, { [k]: inp.type === "checkbox" ? inp.checked : parseFloat(inp.value) || 0 }); drawPreview(pv.t); sheetDirty = true;
      }));
      el.querySelectorAll(".slot").forEach((sl) => {
        const slot = sl.dataset.slot, fi = sl.querySelector("input[type=file]");
        fi.onchange = async () => { const f = fi.files[0]; if (!f) return; try { await LIB.setSlot(name, slot, f); } catch (e) { $("chMsg").innerHTML = `<span class="bad">${esc(e.message)}</span>`; } renderChars(); rebuild(); };
        const clr = sl.querySelector("[data-clr]"); if (clr) clr.onclick = async () => { await LIB.clearSlot(name, slot); renderChars(); rebuild(); };
      });
    });
  }
  $("chAdd").onclick = async () => {
    try {
      const role = $("chRole").value; let name = $("chName").value;
      if (role === "narrator") name = "NARRATOR";
      const rec = await LIB.addChar(name, role); $("chName").value = "";
      $("chMsg").textContent = `Added ${rec.name}. Now choose its PNGs below.`;
      if (role === "main" && !S.mainName) { S.mainName = rec.name; $("mainName").value = rec.name; }
      if (role === "narrator") { S.narratorOnScreen = true; $("narratorOnScreen").checked = true; }
      renderChars(); rebuild();
    } catch (e) { $("chMsg").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
  };

  /* ---------- library: backgrounds ---------- */
  function renderBgs() {
    const list = LIB.listBgs();
    $("bgs").innerHTML = list.map((b) => `<div class="track" data-n="${esc(b.name)}"><img class="thumb" style="float:left;margin-right:10px;width:54px;height:96px" src="${thumb(b.blob)}"><b>${esc(b.name)}</b> <span class="muted">use [BG: ${esc(b.name)}]</span>
      <div class="row"><input data-kw="1" value="${esc(b.keywords)}" placeholder="keywords, comma separated"><button class="danger" data-delbg="1">Delete</button></div><div style="clear:both"></div></div>`).join("") || '<p class="muted">No custom backgrounds yet.</p>';
    $("bgs").querySelectorAll(".track").forEach((el) => {
      const name = el.dataset.n;
      el.querySelector("[data-kw]").onchange = async (e) => { await LIB.setBgKeywords(name, e.target.value); rebuild(); };
      el.querySelector("[data-delbg]").onclick = async () => { await LIB.deleteBg(name); renderBgs(); rebuild(); };
    });
  }
  $("bgFile").onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    try { await LIB.addBg($("bgName").value, $("bgKw").value, f); $("bgName").value = ""; $("bgKw").value = ""; $("bgMsg").textContent = "Saved."; renderBgs(); rebuild(); }
    catch (x) { $("bgMsg").innerHTML = `<span class="bad">${esc(x.message)}</span>`; }
  };

  /* ---------- voices ---------- */
  let voiceList = null;
  function voiceCfg(name, kind) {
    const v = P.voices[name]; if (v) return v;
    if (name === "NARRATOR" || kind === "NARRATOR") return { voice: defaultVoice(0), rate: 0.93, pitch: 0.82 };
    if (name === (comp && comp.heroName)) return { voice: defaultVoice(1), rate: 1.0, pitch: 1.12 };
    return { voice: defaultVoice(2), rate: 1.0, pitch: 1.0 };
  }
  function defaultVoice(i) {
    if (!voiceList || !voiceList.length) return "";
    const en = voiceList.filter((v) => /^en/i.test(v.locale)), pool = en.length ? en : voiceList;
    return pool[i % pool.length].name;
  }
  async function loadVoices() {
    if (!SV.tts.available()) { $("vInfo").textContent = "Voices need the Android app (offline text-to-speech). In a browser you can only import audio."; $("vGen").disabled = true; return; }
    if (!voiceList) {
      try { voiceList = await SV.tts.voices(); $("vInfo").textContent = `${voiceList.length} offline voices found. Pick one per speaker (add more in Android Settings → Text-to-speech).`; }
      catch (e) { $("vInfo").innerHTML = `<span class="bad">${esc(e.message)}</span>`; voiceList = []; }
    }
    renderVoiceRows();
  }
  function renderVoiceRows() {
    const sp = comp ? SV.tts.speakers($("src").value, comp.heroName) : [];
    $("vRows").innerHTML = sp.map((s) => { const c = voiceCfg(s.name, s.kind); return `<div class="track" data-sp="${esc(s.name)}" data-kind="${s.kind}"><b>${esc(s.name)}</b>
      <div class="row"><div style="flex:2"><label>Voice</label><select data-v="voice"><option value="">(system default)</option>${(voiceList || []).map((v) => `<option value="${esc(v.name)}" ${v.name === c.voice ? "selected" : ""}>${esc(v.locale)} · ${esc(v.name)}</option>`).join("")}</select></div>
      <div><label>Speed ${c.rate}</label><input type="range" min="0.6" max="1.6" step="0.05" value="${c.rate}" data-v="rate"></div>
      <div><label>Pitch ${c.pitch}</label><input type="range" min="0.5" max="1.6" step="0.05" value="${c.pitch}" data-v="pitch"></div>
      <button class="alt" data-test="1">▶ Test</button></div></div>`; }).join("");
    $("vRows").querySelectorAll(".track").forEach((el) => {
      const name = el.dataset.sp, kind = el.dataset.kind;
      const read = () => { const c = { voice: el.querySelector('[data-v="voice"]').value, rate: +el.querySelector('[data-v="rate"]').value, pitch: +el.querySelector('[data-v="pitch"]').value }; P.voices[name] = c; return c; };
      el.querySelectorAll("[data-v]").forEach((i) => (i.onchange = () => { read(); renderVoiceRows(); autosave(); }));
      el.querySelector("[data-test]").onclick = async () => {
        $("vMsg").textContent = "Testing " + name + "…"; await new Promise((r) => setTimeout(r, 30));
        try { const b = await SV.tts.synth("They can hear your heartbeat.", read()); A.player.play(b, 0); $("vMsg").textContent = ""; } catch (e) { $("vMsg").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
      };
    });
  }
  $("vGen").onclick = async () => {
    $("vGen").disabled = true; $("vbar").style.width = "0";
    try {
      rebuild();
      const res = await SV.tts.generate($("src").value, comp.heroName, voiceCfg, (i, n, it) => { $("vbar").style.width = (i / n * 100).toFixed(0) + "%"; $("vMsg").textContent = `Voicing line ${i + 1}/${n} (${it.speaker})…`; });
      A.tracks.filter((t) => t.generated).forEach((t) => A.remove(t.id));
      const t = A.addDecoded({ name: "TTS narration", kind: "narration", buffer: res.buffer, offset: 0, volume: 1 }); t.generated = true;
      P.srt = SV.formatSRT(res.cues); rebuild();
      $("vbar").style.width = "100%"; $("vMsg").innerHTML = `<span class="ok">Done — ${res.cues.length} lines, ${res.buffer.duration.toFixed(1)}s. Subtitles + scene cuts now follow the voice exactly. Open Preview to watch.</span>`;
    } catch (e) { $("vMsg").innerHTML = `<span class="bad">Voice generation failed: ${esc(e.message)}</span>`; }
    $("vGen").disabled = false;
  };
  $("vClear").onclick = () => { A.tracks.filter((t) => t.generated).forEach((t) => A.remove(t.id)); P.srt = ""; rebuild(); $("vMsg").textContent = "Generated voice removed."; };

  /* ---------- render ---------- */
  const log = (m) => { const e = $("rlog"); e.textContent += "\n" + m; e.scrollTop = e.scrollHeight; };
  async function doRender(test) {
    if (!SV.render.available()) { $("rstat").innerHTML = '<span class="bad">MP4 export only works inside the Android app (this is a plain browser).</span>'; return; }
    rebuild();
    const [w, h] = (test ? "540x960" : $("res").value).split("x").map(Number);
    const fps = +$("fps").value, br = +$("br").value * 1e6;
    const from = test ? 0 : +$("rfrom").value || 0, to = test ? 6 : +$("rto").value || 0;
    $("rgo").disabled = $("rtest").disabled = true; $("rcancel").disabled = false; $("rlog").textContent = "Render log"; $("rbar").style.width = "0";
    try {
      let mix = null;
      if (needsAudio()) { $("rstat").textContent = "Mixing audio…"; log("Mixing narration / music / SFX / heartbeat with ducking…"); mix = await getMix(); log(`Mix ready (peak ${mix._peak.toFixed(2)}).`); }
      else log("No audio → silent video.");
      log(`Rendering ${w}×${h} @ ${fps}fps, ${comp.scenes.length} shots, ${comp.duration.toFixed(1)}s total.`);
      const name = (P.name || "episode").replace(/[^A-Za-z0-9_-]/g, "_") + (test ? "_TEST" : "") + "_" + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, "");
      const res = await SV.render.run(comp, mix, { w, h, fps, bitrate: br, name, from, to }, (p) => {
        if (p.phase === "frames") { $("rbar").style.width = (p.i / p.n * 92).toFixed(1) + "%"; $("rstat").textContent = `Frame ${p.i}/${p.n} · ${p.fps.toFixed(1)} fps · ${fmt(p.eta)} left`; }
        else if (p.phase === "audio") { $("rstat").textContent = "Sending audio…"; $("rbar").style.width = "94%"; }
        else { $("rstat").textContent = "Encoding audio + muxing MP4…"; $("rbar").style.width = "97%"; }
      });
      $("rbar").style.width = "100%"; $("rstat").innerHTML = `<span class="ok">Done.</span> ${esc(res)}`; log("DONE: " + res);
    } catch (e) { $("rstat").innerHTML = `<span class="bad">Render failed.</span>`; log("ERROR: " + (e && e.message || e)); }
    finally { $("rgo").disabled = $("rtest").disabled = false; $("rcancel").disabled = true; }
  }
  $("rgo").onclick = () => doRender(false);
  $("rtest").onclick = () => doRender(true);
  $("rcancel").onclick = () => { SV.render.cancelled = true; };

  /* ---------- project ---------- */
  function snapshot() { P.name = $("name").value; P.script = $("src").value; syncMeta(); S.res = $("res").value; S.fps = $("fps").value; S.br = $("br").value; return JSON.stringify(P); }
  function autosave() { try { localStorage.setItem("sv_project3", snapshot()); } catch (e) { } }
  function load(obj) {
    Object.assign(P, obj); P.settings = Object.assign({}, DEFAULTS, obj.settings || {}); Object.keys(S).forEach((k) => delete S[k]); Object.assign(S, P.settings); P.settings = S;
    P.voices = obj.voices || {};
    $("src").value = P.script || DEMO; $("name").value = P.name || "episode";
    settingsToUI(); rebuild();
  }
  $("save").onclick = () => { const s = snapshot(); autosave(); try { $("saveStatus").textContent = SVNative.saveProject(P.name, s); } catch (e) { $("saveStatus").textContent = "Saved to browser autosave."; } };
  $("jsonOut").onclick = async () => { $("saveStatus").textContent = await saveFile((P.name || "project") + ".json", "application/json", snapshot()); };
  $("jsonIn").onchange = (e) => {
    const f = e.target.files[0]; if (!f) return; const r = new FileReader();
    r.onload = () => { try { load(JSON.parse(r.result)); $("saveStatus").textContent = "Imported " + f.name; } catch (x) { $("saveStatus").textContent = "Invalid project JSON"; } };
    r.readAsText(f); e.target.value = "";
  };
  $("restore").onclick = () => {
    let x = null; try { x = localStorage.getItem("sv_project3"); } catch (e) { }
    if (x) { load(JSON.parse(x)); $("saveStatus").textContent = "Restored autosave."; } else $("saveStatus").textContent = "No autosave found.";
  };

  /* ---------- boot ---------- */
  (async function boot() {
    await LIB.init();
    await Promise.race([SV.whenStudio(), new Promise((r) => setTimeout(r, 4000))]);
    let b = null; try { b = localStorage.getItem("sv_project3"); } catch (e) { }
    settingsToUI();
    if (b) { try { load(JSON.parse(b)); } catch (e) { $("src").value = DEMO; rebuild(); } } else { $("src").value = DEMO; rebuild(); }
    showTab("script");
  })();
})();
