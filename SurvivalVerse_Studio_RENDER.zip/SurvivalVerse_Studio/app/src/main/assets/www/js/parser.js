/* SurvivalVerse Studio — script parser, SRT, auto-director and timeline compiler.
   Pure functions, no DOM. Output ("comp") is everything the renderer + mixer need. */
(function () {
  const SV = (window.SV = window.SV || {});
  SV.bgImages = SV.bgImages || {};
  SV.bgDefs = SV.bgDefs || []; // user backgrounds: {name, keywords}

  const SPEAKER_TAGS = ["NARRATOR", "CHARACTER", "RADIO", "MOM", "KID", "SPEAKER"];
  const OTHER_TAGS = ["MARK", "PAUSE", "SFX", "MUSIC", "EMOTION", "CAMERA", "HUD", "CAPTION",
    "BG", "WEATHER", "POSE", "ZOMBIES", "TRANSITION", "FLASH"];
  // ElevenLabs-style inline audio tags: [whispers] etc. They are NOT speakers.
  const AUDIO_TAGS = new Set(("whispers whispering whisper sighs sigh gasps gasp laughs laughing laugh crying cries sobs shouts shouting " +
    "screams screaming yells breathes breathing exhales inhales pauses pause hesitates nervous nervously scared excited angry sad calm " +
    "tired panicked panicking trembling softly quietly slowly quickly urgently desperately fearful terrified coughs clears throat " +
    "gulps swallows muttering mumbles groans groaning sarcastic serious dramatic").split(/\s+/));
  const ALIASES = (SV.ALIASES = new Set(["YOU", "ME", "MAIN", "HERO", "PROTAGONIST", "PLAYER", "SURVIVOR"]));

  function splitTag(body) {
    const parts = body.split("|").map((s) => s.trim());
    const arg = parts.shift() || "";
    const opts = {};
    parts.forEach((p) => {
      const m = p.match(/^([\w-]+)\s*=\s*(.*)$/);
      if (m) opts[m[1].toLowerCase()] = m[2];
      else if (p) opts[p.toLowerCase()] = true;
    });
    return { arg, opts };
  }
  const num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
  const cleanText = (s) => s.replace(/\[[^\]]*\]/g, " ").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
  const isCaps = (s) => { const l = s.replace(/[^A-Za-z]/g, ""); return l.length >= 6 && l === l.toUpperCase(); };
  SV.isCaps = isCaps;

  /* ---------- script -> scenes ---------- */
  SV.parseScript = function (text) {
    const scenes = [];
    let cur = null;
    const ensure = (name) => cur || (cur = (scenes.push({ name: name || "OPENING", events: [] }), scenes[scenes.length - 1]));
    let speaker = { kind: "NARRATOR", name: "NARRATOR" };
    const setSpeaker = (sc, kind, name, arg, opts) => {
      speaker = { kind, name };
      sc.events.push({ type: "speaker", kind, name, arg: arg || "", opts: opts || {} });
    };
    const pushLine = (sc, raw, textRaw) => {
      const t = cleanText(textRaw);
      if (!t) return;
      const ev = { type: "line", kind: speaker.kind, speaker: speaker.name, text: t, raw };
      const ch = t.match(/^([AB])\s*[—–:\-]+\s*(.+)$/);
      if (ch) { ev.choice = ch[1]; ev.choiceText = ch[2]; }
      if (isCaps(t)) { ev.emph = true; if (/\b(comment|vote)\b/i.test(t)) ev.cta = true; }
      sc.events.push(ev);
    };
    for (let raw of String(text || "").split(/\r?\n/)) {
      const x = raw.trim();
      if (!x || x.startsWith("//") || x.startsWith("#")) continue;
      // directive / speaker tag alone on a line: [NAME: args]
      const m = x.match(/^\[([A-Za-z_]+)\s*:?\s*([^\[\]]*)\]$/);
      if (m) {
        const name = m[1].toUpperCase();
        const { arg, opts } = splitTag(m[2]);
        if (name === "SCENE") { cur = { name: arg || "SCENE", events: [] }; scenes.push(cur); continue; }
        const sc = ensure();
        if (SPEAKER_TAGS.includes(name)) {
          const nm = name === "CHARACTER" || name === "SPEAKER" ? (arg || "SURVIVOR").toUpperCase() : name;
          setSpeaker(sc, name, nm, arg, opts);
        } else if (OTHER_TAGS.includes(name)) sc.events.push({ type: name.toLowerCase(), arg, opts });
        else if (!AUDIO_TAGS.has(m[1].toLowerCase()) && !arg) {
          // bare [NAME] alone = switch speaker (sticky)
          setSpeaker(sc, name === "NARRATOR" ? "NARRATOR" : "CHARACTER", name, "", {});
        } else sc.events.push({ type: "unknown", arg: x, opts: {} });
        continue;
      }
      // inline speaker: [NAME] dialogue   (also [NAME: voice | expression=x] dialogue)
      const im = x.match(/^\[([A-Za-z][A-Za-z0-9_ ]{0,24}?)\s*(?::\s*([^\[\]]*))?\]\s+(\S.*)$/);
      if (im && !AUDIO_TAGS.has(im[1].trim().toLowerCase()) && !OTHER_TAGS.includes(im[1].trim().toUpperCase()) && im[1].trim().toUpperCase() !== "SCENE") {
        const sc = ensure();
        const nm = im[1].trim().toUpperCase();
        const { arg, opts } = splitTag(im[2] || "");
        const kind = nm === "NARRATOR" ? "NARRATOR" : ["RADIO", "MOM", "KID"].includes(nm) ? nm : "CHARACTER";
        setSpeaker(sc, kind, nm, arg, opts);
        pushLine(sc, x, im[3]);
        continue;
      }
      const sc = ensure();
      pushLine(sc, x, x);
    }
    return scenes;
  };

  /* ---------- SRT ---------- */
  const tcRe = /(\d+):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d+):(\d{2}):(\d{2})[,.](\d{1,3})/;
  const tcSec = (h, m, s, ms) => +h * 3600 + +m * 60 + +s + +(ms.padEnd(3, "0")) / 1000;
  SV.parseSRT = function (text) {
    const cues = [];
    const blocks = String(text || "").replace(/^﻿/, "").replace(/\r/g, "").split(/\n\s*\n/);
    for (const b of blocks) {
      const lines = b.split("\n").map((l) => l.trim()).filter((l) => l.length);
      const ti = lines.findIndex((l) => tcRe.test(l));
      if (ti < 0) continue;
      const m = lines[ti].match(tcRe);
      const start = tcSec(m[1], m[2], m[3], m[4]);
      const end = tcSec(m[5], m[6], m[7], m[8]);
      const t = cleanText(lines.slice(ti + 1).join(" "));
      if (t && end > start) cues.push({ start, end, text: t });
    }
    cues.sort((a, b) => a.start - b.start);
    return cues;
  };
  const pad = (n, l) => String(n).padStart(l, "0");
  SV.fmtTime = function (t) {
    t = Math.max(0, t);
    const ms = Math.round(t * 1000);
    return pad(Math.floor(ms / 3600000), 2) + ":" + pad(Math.floor(ms / 60000) % 60, 2) + ":" +
      pad(Math.floor(ms / 1000) % 60, 2) + "," + pad(ms % 1000, 3);
  };
  SV.formatSRT = (cues) => cues.map((c, i) => `${i + 1}\n${SV.fmtTime(c.start)} --> ${SV.fmtTime(c.end)}\n${c.text}`).join("\n\n");

  /* ---------- caption chunks with word timing ---------- */
  function chunkWords(words, maxW, maxC) {
    const out = [];
    let cur = [], c = 0;
    for (const w of words) {
      cur.push(w); c += w.length + 1;
      const brk = /[.!?;:,—]$/.test(w);
      if (cur.length >= maxW || c >= maxC || (brk && cur.length >= 2)) { out.push(cur); cur = []; c = 0; }
    }
    if (cur.length) {
      if (cur.length === 1 && out.length && out[out.length - 1].length < maxW + 1) out[out.length - 1].push(cur[0]);
      else out.push(cur);
    }
    return out;
  }
  SV.chunkCues = function (cues) {
    const chunks = [];
    for (const cue of cues) {
      const words = cue.text.split(/\s+/).filter(Boolean);
      if (!words.length) continue;
      const weights = words.map((w) => w.length + 1);
      const total = weights.reduce((a, b) => a + b, 0);
      const dur = cue.end - cue.start;
      let acc = 0;
      const timed = words.map((w, i) => {
        const s = cue.start + (acc / total) * dur; acc += weights[i];
        return { w, start: s, end: cue.start + (acc / total) * dur };
      });
      let idx = 0;
      const emph = cue.emph != null ? cue.emph : isCaps(cue.text);
      for (const grp of chunkWords(words, 4, 26)) {
        const ws = timed.slice(idx, idx + grp.length); idx += grp.length;
        chunks.push({ start: ws[0].start, end: ws[ws.length - 1].end, words: ws, emph });
      }
    }
    for (let i = 0; i < chunks.length - 1; i++) {
      if (chunks[i + 1].start - chunks[i].end < 0.25) chunks[i].end = chunks[i + 1].start;
    }
    return chunks;
  };

  /* ---------- design / inference helpers ---------- */
  SV.hash = function (n) {
    n = Math.imul((n | 0) ^ 0x9e3779b9, 0x85ebca6b); n ^= n >>> 13;
    n = Math.imul(n, 0xc2b2ae35); n ^= n >>> 16;
    return (n >>> 0) / 4294967296;
  };
  SV.strHash = function (s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

  const ACCENTS = ["#e5484d", "#3e9bff", "#f5a524", "#46c37b", "#b074f0", "#ff7ab6", "#22d3c5"];
  SV.designFor = function (name, kind) {
    const h = SV.strHash(name);
    return {
      name, kind: kind || "CHARACTER",
      accent: ACCENTS[h % ACCENTS.length],
      hair: kind === "MOM" || (h >> 3) % 3 === 0 ? "bun" : (h >> 5) % 3 === 0 ? "spiky" : "none",
      hat: (h >> 7) % 4 === 0,
      scale: kind === "KID" ? 0.72 : 1,
    };
  };

  const BG_TYPES = [
    ["elevator", /elevator|lift\b/],
    ["stairs", /stair|staircase/],
    ["door", /backdoor|back door|front door|\bdoor\b|doorway/],
    ["hallway", /hallway|corridor|landing|lobby/],
    ["alley", /alley|dumpster/],
    ["bunker", /bunker|shelter|basement|vault|cellar/],
    ["forest", /forest|wood|camp|trail|jungle/],
    ["room", /room|apartment|house|home|kitchen|office|interior|inside|living|bedroom|flat/],
    ["city", /city|street|road|highway|rooftop|roof|town|market|bridge|outside|downtown|parking/],
  ];
  function inferBg(name) {
    const n = String(name || "").toLowerCase();
    let type = null;
    // user backgrounds first (by name or keyword)
    for (const b of SV.bgDefs) {
      const kws = [b.name].concat(String(b.keywords || "").split(",")).map((s) => s.trim().toLowerCase()).filter(Boolean);
      if (kws.some((k) => n.includes(k))) return { type: "custom", name: b.name, mood: null, variant: null };
    }
    for (const [t, re] of BG_TYPES) if (re.test(n)) { type = t; break; }
    let mood = null;
    if (/night|midnight|dark|silent/.test(n)) mood = "night";
    else if (/dusk|sunset|evening/.test(n)) mood = "dusk";
    else if (/day|morning|noon|calm/.test(n)) mood = "day";
    else if (/blood|red|panic|chaos|attack|horde/.test(n)) mood = "red";
    else if (/fog|mist/.test(n)) mood = "fog";
    const variant = /\bopen\b|ajar|slightly/.test(n) ? "open" : /closed|shut|locked/.test(n) ? "closed" : null;
    return type || mood || variant ? { type, mood, variant } : null;
  }
  SV.inferBg = inferBg;
  SV.parseBg = function (arg) {
    const n = String(arg || "").toLowerCase();
    const r = inferBg(n) || {};
    return { type: r.type || null, mood: r.mood || null, variant: r.variant || null, name: r.name || null };
  };

  const SFX_FX = [
    [/thunder|lightning/, { flash: 0.7 }],
    [/explo|blast|boom/, { flash: 0.6, shake: 26 }],
    [/crash|slam|bang|smash|impact|break/, { shake: 18 }],
    [/gun|shot|shoot/, { flash: 0.35, shake: 10 }],
    [/scream|roar|growl|bite/, { shake: 8 }],
    [/knock/, { shake: 5 }],
  ];

  /* ---------- auto director: split a plain script into many shots and direct each one ---------- */
  const RX = {
    scared: /heard|footstep|behind you|stopped breathing|climbing|horde|inside your|someone was|something is inside|right behind/,
    worried: /nothing|silence|checked|locked|never|forgot|waited|couldn't|expose|trapped|choices|remember|turned|handle|but /,
    determined: /rushed|run |ran |elevator|push|close the/,
    run: /rushed|\bran\b|\brun\b|running/,
    walk: /stepped away|slowly stepped|walked|walking|headed|head downstairs/,
    freeze: /stopped breathing|froze|couldn't run|couldn't scream|silence|nothing\./,
    red: /horde|climbing|rush|panic|scream|zombies were/,
    zombieOutside: /zombies were climbing|horde|zombies/,
    someone: /someone was (already )?inside|something is inside|one footstep/,
  };
  function inferLoc(txt, prev) {
    for (const b of SV.bgDefs) {
      const kws = [b.name].concat(String(b.keywords || "").split(",")).map((s) => s.trim().toLowerCase()).filter(Boolean);
      if (kws.some((k) => txt.includes(k))) return { type: "custom", arg: b.name };
    }
    let type = null;
    if (/elevator|\blift\b/.test(txt)) type = "elevator";
    else if (/stair|staircase|your floor|climbing up/.test(txt)) type = "stairs";
    else if (/doors?\b.*waiting|doors were/.test(txt) && prev.type === "elevator" && !/front|back/.test(txt)) type = "elevator";
    else if (/alley|downstairs|waiting below/.test(txt)) type = "alley";
    else if (/backdoor|back door|front door|\bdoor\b|handle|knock|slightly open|kept the zombies outside/.test(txt)) type = "door";
    else if (/hallway|corridor/.test(txt)) type = "hallway";
    else if (/apartment|home|inside|window|living|room|cabinet|behind you|footstep|silence/.test(txt)) type = "room";
    if (!type) type = prev.type || "room";
    const open = /open|ajar|turned|waiting/.test(txt) && !/\bclose\b|closed/.test(txt) ? "open" : "closed";
    return { type, arg: type + (type === "door" || type === "elevator" ? " " + open : "") };
  }

  SV.autoDirect = function (scenesIn, o) {
    o = o || {};
    const lineCount = scenesIn.reduce((n, s) => n + s.events.filter((e) => e.type === "line").length, 0);
    const mode = o.autoMode || "auto";
    const need = mode === "on" || (mode === "auto" && lineCount > 0 && scenesIn.length < Math.max(2, lineCount / 3));
    if (!need) return { scenes: scenesIn, auto: false };
    const density = o.density || "normal";
    const budget = density === "fast" ? 1 : density === "slow" ? 18 : 9;
    const maxLines = density === "fast" ? 1 : density === "slow" ? 4 : 3;

    // 1) split into shots
    const shots = [];
    scenesIn.forEach((sc) => {
      let cur = { base: sc.name, events: [], words: 0, lines: 0, special: false }, pend = [];
      const flush = () => { if (cur.events.length) shots.push(cur); cur = { base: sc.name, events: [], words: 0, lines: 0, special: false }; };
      sc.events.forEach((e) => {
        if (e.type !== "line") { pend.push(e); return; }
        const w = e.text.split(/\s+/).length, special = !!(e.emph || e.choice || e.cta);
        if (cur.lines > 0 && (cur.words >= budget || cur.lines >= maxLines || special || cur.special)) flush();
        cur.events.push(...pend); pend = [];
        cur.events.push(e); cur.words += w; cur.lines++; cur.special = cur.special || special;
      });
      cur.events.push(...pend); flush();
    });

    // 2) direct each shot
    const allText = scenesIn.map((s) => s.events.filter((e) => e.type === "line").map((e) => e.text).join(" ")).join(" ").toLowerCase();
    const heartMode = o.autoHud === "on" || (o.autoHud !== "off" && /heart/.test(allText));
    const lineShots = shots.filter((s) => s.lines > 0);
    const prev = { type: null }; let camI = 0, lastBpm = -1, li = 0, elevatorDing = false;
    const CAMS = ["slow_push_in", "pan_left", "slow_pull_out", "pan_right", "slow_push_in", "tilt_up"];
    const out = shots.map((sh, i) => {
      const lines = sh.events.filter((e) => e.type === "line");
      const txt = lines.map((l) => l.text).join(" ").toLowerCase();
      const has = (t) => sh.events.some((x) => x.type === t);
      const pre = [];
      const emph = lines.some((l) => l.emph), choice = lines.find((l) => l.choice);
      // location
      let loc;
      if (!has("bg")) {
        loc = inferLoc(txt, prev);
        const mood = RX.red.test(txt) && !emph ? "red" : "night";
        pre.push({ type: "bg", arg: loc.arg + (loc.type === "custom" ? "" : " " + mood), opts: {} });
        prev.type = loc.type;
      } else { const b = SV.parseBg(sh.events.find((e) => e.type === "bg").arg); prev.type = b.type || prev.type; loc = { type: prev.type }; }
      if (lines.length) {
        // expression + pose
        if (!has("emotion")) pre.push({ type: "emotion", arg: RX.scared.test(txt) ? "scared" : RX.determined.test(txt) ? "determined" : RX.worried.test(txt) ? "worried" : "neutral", opts: {} });
        if (!has("pose")) pre.push({ type: "pose", arg: RX.run.test(txt) ? "run" : RX.walk.test(txt) ? "walk" : RX.freeze.test(txt) || RX.scared.test(txt) ? "scared" : "idle", opts: {} });
        // camera
        if (!has("camera")) {
          if (emph) pre.push({ type: "camera", arg: "snap_zoom", opts: { dur: "0.7" } });
          else if (RX.run.test(txt)) pre.push({ type: "camera", arg: "handheld", opts: { amp: "9" } });
          else if (RX.scared.test(txt)) pre.push({ type: "camera", arg: "slow_push_in", opts: {} });
          else pre.push({ type: "camera", arg: CAMS[camI++ % CAMS.length], opts: {} });
          if (emph && !has("flash") && i < 4) pre.push({ type: "flash", arg: "red", opts: { amp: "0.5", dur: "0.25" } });
        }
        // zombies
        if (!has("zombies")) {
          if (RX.someone.test(txt) && ["room", "door", "hallway"].includes(loc.type)) pre.push({ type: "zombies", arg: "1", opts: { mode: "silhouette", side: "left" } });
          else if (RX.zombieOutside.test(txt) && ["stairs", "alley", "elevator", "city"].includes(loc.type)) pre.push({ type: "zombies", arg: /horde/.test(txt) ? "horde" : "3", opts: { mode: /climbing/.test(txt) ? "silhouette" : "approach", side: "right" } });
        }
        // sfx
        if (o.autoSfx !== false && !has("sfx")) {
          const add = (n, v) => pre.push({ type: "sfx", arg: n, opts: { volume: String(v || 0.8) } });
          if (/knocked|knock/.test(txt)) add("knock", 0.95);
          if (/one footstep|heard it/.test(txt)) add("footstep", 0.9);
          if (/slightly open|handle was turned|door was slightly/.test(txt)) add("door_creak", 0.8);
          if (/elevator/.test(txt) && !elevatorDing) { add("elevator_ding", 0.7); elevatorDing = true; }
          if (/climbing|staircase|stairs/.test(txt)) { add("footsteps_run", 0.7); add("groan", 0.5); }
          if (/heavy cabinet|slam/.test(txt)) add("door_slam", 0.9);
          if (/sudden increase|expose/.test(txt)) add("hit", 0.7);
          if (emph && i === 0) add("hit", 0.8);
          if (/thunder|storm/.test(txt)) add("thunder", 0.8);
        }
        // heartbeat HUD: rises through the episode, spikes on danger words
        if (heartMode && !has("hud")) {
          const prog = lineShots.length > 1 ? li / (lineShots.length - 1) : 0;
          let ten = 0.12 + 0.55 * prog + (RX.scared.test(txt) ? 0.2 : 0) + (/heartbeat|expose|trapped|choices/.test(txt) ? 0.2 : 0);
          const target = 72 + 98 * Math.min(1, ten);
          const bpm = lastBpm < 0 ? Math.round(target) : Math.round(lastBpm + Math.max(-4, Math.min(24, target - lastBpm)));
          if (bpm !== lastBpm) { pre.push({ type: "hud", arg: "HEART=" + bpm, opts: {} }); lastBpm = bpm; }
        }
        li++;
      }
      return { name: (loc.type || "SHOT").toUpperCase() + "_" + String(i + 1).padStart(2, "0"), events: pre.concat(sh.events) };
    });
    return { scenes: out, auto: true, shots: out.length };
  };

  /* ---------- compile ---------- */
  SV.compile = function (scenesRaw, ctx) {
    ctx = ctx || {};
    const warnings = [];
    const ad = SV.autoDirect(scenesRaw, ctx);
    const scenesIn = ad.scenes;
    const importedCues = ctx.cues && ctx.cues.length ? ctx.cues : null;
    const narrDur = ctx.narrationDuration || 0;
    const tail = ctx.tail != null ? ctx.tail : 1.2;

    // hero (main character)
    let heroName = String(ctx.mainName || "").trim().toUpperCase();
    if (!heroName) {
      outer: for (const s of scenesIn) for (const e of s.events) if (e.type === "speaker" && e.kind === "CHARACTER" && !ALIASES.has(e.name)) { heroName = e.name; break outer; }
    }
    if (!heroName) heroName = "SURVIVOR";
    const alias = (n) => (ALIASES.has(n) && n !== heroName ? heroName : n);

    // 1) flatten lines with estimated timing (also the fallback)
    let cursor = 0, speed = 1;
    const flat = [];
    const sceneInfo = scenesIn.map((s, si) => {
      const evs = s.events.map((e) => Object.assign({}, e));
      const lines = [];
      evs.forEach((e) => {
        if (e.type === "speaker") { e.name = alias(e.name); if (e.opts && e.opts.speed) speed = num(e.opts.speed, 1) || 1; }
        if (e.type === "pause") cursor += num(String(e.arg).replace(/s$/i, ""), 0.5);
        if (e.type === "line") {
          e.speaker = alias(e.speaker);
          const words = e.text.split(/\s+/).length;
          const d = Math.max(1.2, words / (2.6 * speed));
          e.est0 = cursor; e.est1 = cursor + d; cursor += d;
          lines.push(e); flat.push(e);
        }
      });
      return { s, si, evs, lines };
    });
    const estTotal = cursor || 1;

    // 2) final line timing
    let source = "estimated";
    if (importedCues && flat.length) {
      source = "srt";
      const n = flat.length, m = importedCues.length;
      if (n === m) flat.forEach((l, i) => { l.start = importedCues[i].start; l.end = importedCues[i].end; });
      else {
        warnings.push(`SRT/voice has ${m} cues but script has ${n} spoken lines — aligned by text length. Use one cue per script line for exact cuts.`);
        const cum = [0];
        importedCues.forEach((c) => cum.push(cum[cum.length - 1] + Math.max(1, c.text.length)));
        const tot = cum[cum.length - 1];
        const at = (f) => {
          const target = f * tot;
          let k = 0;
          while (k < m - 1 && cum[k + 1] <= target) k++;
          const c = importedCues[k];
          return c.start + Math.min(1, (target - cum[k]) / Math.max(1, cum[k + 1] - cum[k])) * (c.end - c.start);
        };
        const lc = [0];
        flat.forEach((l) => lc.push(lc[lc.length - 1] + Math.max(1, l.text.length)));
        const lt = lc[lc.length - 1];
        flat.forEach((l, i) => { l.start = at(lc[i] / lt); l.end = at(lc[i + 1] / lt); });
      }
    } else if (narrDur > 0 && flat.length) {
      source = "narration-length";
      const k = narrDur / estTotal;
      flat.forEach((l) => { l.start = l.est0 * k; l.end = l.est1 * k; });
    } else flat.forEach((l) => { l.start = l.est0; l.end = l.est1; });

    const lastEnd = flat.length ? Math.max(...flat.map((l) => l.end)) : 3;
    const duration = Math.max(lastEnd + tail, narrDur ? narrDur + 0.3 : 0, importedCues ? importedCues[importedCues.length - 1].end + 0.3 : 0, 2);

    // 3) scene bounds (scenes without spoken lines are merged forward)
    const valid = [];
    let pending = [];
    sceneInfo.forEach((si) => {
      if (!si.lines.length) { pending = pending.concat(si.evs); return; }
      si.evs = pending.concat(si.evs); pending = [];
      valid.push(si);
    });
    if (pending.length && valid.length) valid[valid.length - 1].evs = valid[valid.length - 1].evs.concat(pending);
    if (!valid.length) warnings.push("No spoken lines found in script.");

    const scenes = [];
    let prevBg = { type: "room", mood: "night", variant: null, name: null };
    const run = { hud: {}, weather: "none", expr: {} };
    const sfx = [], music = [], choices = [];
    let cta = null;

    valid.forEach((si, k) => {
      const start = k === 0 ? 0 : si.lines[0].start;
      const end = k === valid.length - 1 ? duration : valid[k + 1].lines[0].start;
      const sc = {
        index: k, name: si.s.name, start, end,
        seed: SV.strHash(si.s.name) ^ (k * 7919),
        lines: si.lines.map((l) => ({ start: l.start, end: l.end, speaker: l.speaker, kind: l.kind, text: l.text })),
        events: [], cast: [], hasRadio: false,
      };
      si.lines.forEach((l) => {
        if (l.choice) choices.push({ key: l.choice, text: l.choiceText, start: l.start, end: l.end });
        if (l.cta && !cta) cta = { start: l.start, end: l.end };
        if (l.kind === "RADIO") sc.hasRadio = true;
      });
      // background
      const bgEv = si.evs.find((e) => e.type === "bg");
      const inf = bgEv ? SV.parseBg(bgEv.arg) : inferBg(si.s.name);
      sc.bg = {
        type: (inf && inf.type) || prevBg.type, mood: (inf && inf.mood) || (inf && inf.type ? "night" : prevBg.mood),
        variant: (inf && inf.variant) || null, name: inf && inf.name ? inf.name : (inf && inf.type ? null : prevBg.name),
      };
      if (sc.bg.type !== "custom") sc.bg.name = null;
      prevBg = sc.bg;
      const trEv = si.evs.find((e) => e.type === "transition");
      sc.transition = trEv ? String(trEv.arg || "fade").toLowerCase() : "fade";
      sc.entry = { hud: Object.assign({}, run.hud), weather: run.weather, expr: Object.assign({}, run.expr) };

      let buf = [], seenLine = false, lineIdx = 0, lastCharacter = null;
      const finalize = (list) => {
        list.forEach((ev) => {
          switch (ev.type) {
            case "speaker":
              if (ev.kind === "CHARACTER" || ev.kind === "SPEAKER") lastCharacter = ev.name;
              if (ev.opts && ev.opts.expression) sc.events.push({ t: ev.t, type: "expr", name: ev.name, value: String(ev.opts.expression) });
              break;
            case "emotion":
              sc.events.push({ t: ev.t, type: "expr", name: ev.opts.who ? alias(String(ev.opts.who).toUpperCase()) : (lastCharacter || heroName), value: ev.arg });
              break;
            case "pose":
              sc.events.push({ t: ev.t, type: "pose", value: String(ev.arg).toLowerCase(), who: ev.opts.who ? alias(String(ev.opts.who).toUpperCase()) : null });
              break;
            case "zombies": {
              const a = String(ev.arg).toLowerCase();
              const count = /^\d+$/.test(a) ? parseInt(a, 10) : /horde|many|swarm/.test(a) ? 14 : /few|some/.test(a) ? 3 : /none|clear|off|0/.test(a) ? 0 : 4;
              const mode = String(ev.opts.mode || (/horde|swarm/.test(a) ? "horde" : "approach")).toLowerCase();
              sc.events.push({ t: ev.t, type: "zombies", count, mode, side: String(ev.opts.side || "right").toLowerCase() });
              break;
            }
            case "camera":
              sc.events.push({ t: ev.t, type: "camera", name: String(ev.arg).toLowerCase().replace(/\s+/g, "_"), dur: ev.opts.dur ? num(ev.opts.dur, 2) : sc.end - ev.t, amp: num(ev.opts.amp, 0) });
              break;
            case "weather":
              sc.events.push({ t: ev.t, type: "weather", value: String(ev.arg).toLowerCase() });
              run.weather = String(ev.arg).toLowerCase();
              break;
            case "hud": {
              const kv = {};
              [ev.arg].concat(Object.keys(ev.opts).map((k2) => k2 + "=" + ev.opts[k2])).join(",").split(/[,;]/).forEach((p) => {
                const m = p.match(/^\s*([A-Za-z_ ]+?)\s*=\s*(.+?)\s*$/);
                if (m) kv[m[1].toUpperCase()] = m[2];
              });
              sc.events.push({ t: ev.t, type: "hud", kv });
              Object.assign(run.hud, kv);
              break;
            }
            case "caption":
              sc.events.push({ t: ev.t, type: "title", text: ev.arg, dur: num(ev.opts.dur, 2.6) });
              break;
            case "flash":
              sc.events.push({ t: ev.t, type: "flash", color: ev.opts.color || (/red|blood/i.test(ev.arg) ? "#ff2a2a" : "#ffffff"), dur: num(ev.opts.dur, 0.3), amp: num(ev.opts.amp, 0.9) });
              break;
            case "sfx": {
              const name = String(ev.arg).toLowerCase();
              sfx.push({ t: ev.t, name, volume: num(ev.opts.volume, 0.8) });
              SFX_FX.forEach(([re, fx]) => {
                if (!re.test(name)) return;
                if (fx.flash) sc.events.push({ t: ev.t, type: "flash", color: /thunder|lightning/.test(name) ? "#cfe6ff" : "#fff2c4", dur: 0.28, amp: fx.flash });
                if (fx.shake) sc.events.push({ t: ev.t, type: "camera", name: "shake", dur: 0.55, amp: fx.shake });
              });
              break;
            }
            case "music":
              music.push({ t: ev.t, name: String(ev.arg).toLowerCase(), volume: num(ev.opts.volume, 0.3), stop: /^(stop|off|none|silence)$/i.test(ev.arg) });
              break;
            default: break;
          }
        });
        buf = [];
      };
      si.evs.forEach((e) => {
        if (e.type === "line") {
          const l = si.lines[lineIdx++];
          const t = !seenLine ? sc.start : l.start;
          buf.forEach((b) => (b.t = Math.max(sc.start, Math.min(t, sc.end - 0.01))));
          finalize(buf);
          seenLine = true;
        } else if (e.type === "pause" || e.type === "mark" || e.type === "unknown") {
          /* ignored */
        } else buf.push(Object.assign({}, e, { t: sc.start }));
      });
      const lastStart = si.lines[si.lines.length - 1].start;
      buf.forEach((b) => (b.t = Math.max(sc.start, Math.min(lastStart, sc.end - 0.01))));
      finalize(buf);

      // cast: hero always; other speakers in this shot; narrator if shown on screen
      const heroD = SV.designFor(heroName, "CHARACTER"); heroD.isHero = true; heroD.accent = "#d8323a"; heroD.hair = "none"; heroD.hat = false;
      sc.cast.push(heroD);
      si.lines.forEach((l) => {
        if (l.kind === "NARRATOR" || l.kind === "RADIO" || l.speaker === heroName) return;
        if (sc.cast.length < 3 && !sc.cast.find((c) => c.name === l.speaker)) sc.cast.push(SV.designFor(l.speaker, l.kind));
      });
      if (ctx.narratorOnScreen) { const nd = SV.designFor("NARRATOR", "NARRATOR"); nd.isNarrator = true; nd.accent = "#68d9e8"; sc.cast.push(nd); }
      sc.events.sort((a, b) => a.t - b.t);
      sc.events.forEach((e) => { if (e.type === "expr") run.expr[e.name] = e.value; });
      scenes.push(sc);
    });

    const cues = importedCues ? importedCues.map((c) => ({ start: c.start, end: c.end, text: c.text, emph: isCaps(c.text) }))
      : flat.map((l) => ({ start: l.start, end: l.end, text: l.text, emph: !!l.emph }));

    // heartbeat beats follow the HUD HEART value over time
    const hearts = [];
    scenes.forEach((s) => s.events.forEach((e) => { if (e.type === "hud" && e.kv.HEART != null) hearts.push({ t: e.t, bpm: parseFloat(e.kv.HEART) || 72 }); }));
    hearts.sort((a, b) => a.t - b.t);
    const beats = [];
    if (hearts.length) {
      let t = hearts[0].t;
      while (t < duration - 0.2 && beats.length < 1200) {
        let bpm = hearts[0].bpm; hearts.forEach((h) => { if (h.t <= t) bpm = h.bpm; });
        beats.push({ t, vol: 0.3 + 0.55 * Math.min(1, Math.max(0, (bpm - 70) / 100)) });
        t += 60 / Math.max(40, bpm);
      }
    }

    return {
      duration, scenes, cues, captionChunks: SV.chunkCues(cues),
      sfx, music, beats, choices, cta,
      settings: { look: ctx.look || "studio", style: ctx.style || "silent", narratorOnScreen: !!ctx.narratorOnScreen, narratorLips: ctx.narratorLips !== false, autoMusic: ctx.autoMusic !== false, heartbeatSfx: ctx.heartbeatSfx !== false },
      timingSource: source, warnings, heroName, auto: ad.auto,
      stats: { scenes: scenes.length, lines: flat.length, duration },
    };
  };
})();
