/* SurvivalVerse Studio — script parser, SRT, and timeline compiler.
   Pure functions, no DOM. Output ("comp") is everything the renderer + mixer need. */
(function () {
  const SV = (window.SV = window.SV || {});

  const SPEAKER_TAGS = ["NARRATOR", "CHARACTER", "RADIO", "MOM", "KID", "SPEAKER"];
  const OTHER_TAGS = ["MARK", "PAUSE", "SFX", "MUSIC", "EMOTION", "CAMERA", "HUD", "CAPTION",
    "BG", "WEATHER", "POSE", "ZOMBIES", "TRANSITION", "FLASH"];

  function splitTag(body) {
    const parts = body.split("|").map((s) => s.trim());
    const arg = parts.shift() || "";
    const opts = {};
    parts.forEach((p) => {
      const m = p.match(/^([\w-]+)\s*=\s*(.*)$/);
      if (m) opts[m[1].toLowerCase()] = m[2];
      else if (p) opts[p.toLowerCase()] = true;
    });
    return { arg, opts };
  }
  const num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
  const cleanText = (s) => s.replace(/\[[^\]]*\]/g, " ").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();

  /* ---------- script -> scenes ---------- */
  SV.parseScript = function (text) {
    const scenes = [];
    let cur = null;
    const ensure = (name) => cur || (cur = (scenes.push({ name: name || "OPENING", events: [] }), scenes[scenes.length - 1]));
    let speaker = { kind: "NARRATOR", name: "NARRATOR" };
    for (let raw of String(text || "").split(/\r?\n/)) {
      const x = raw.trim();
      if (!x || x.startsWith("//") || x.startsWith("#")) continue;
      const m = x.match(/^\[([A-Za-z_]+)\s*:?\s*([^\[\]]*)\]$/);
      if (m) {
        const name = m[1].toUpperCase();
        const { arg, opts } = splitTag(m[2]);
        if (name === "SCENE") {
          cur = { name: arg || "SCENE", events: [] };
          scenes.push(cur);
          continue;
        }
        const sc = ensure();
        if (SPEAKER_TAGS.includes(name)) {
          const nm = name === "CHARACTER" || name === "SPEAKER" ? (arg || "SURVIVOR").toUpperCase() : name;
          speaker = { kind: name, name: nm };
          sc.events.push({ type: "speaker", kind: name, name: nm, arg, opts });
        } else if (OTHER_TAGS.includes(name)) {
          sc.events.push({ type: name.toLowerCase(), arg, opts });
        } else {
          sc.events.push({ type: "unknown", arg: x, opts: {} });
        }
        continue;
      }
      const sc = ensure();
      const t = cleanText(x);
      if (!t) continue;
      sc.events.push({ type: "line", kind: speaker.kind, speaker: speaker.name, text: t, raw: x });
    }
    return scenes;
  };

  /* ---------- SRT ---------- */
  const tcRe = /(\d+):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d+):(\d{2}):(\d{2})[,.](\d{1,3})/;
  const tcSec = (h, m, s, ms) => +h * 3600 + +m * 60 + +s + +(ms.padEnd(3, "0")) / 1000;
  SV.parseSRT = function (text) {
    const cues = [];
    const blocks = String(text || "").replace(/^﻿/, "").replace(/\r/g, "").split(/\n\s*\n/);
    for (const b of blocks) {
      const lines = b.split("\n").map((l) => l.trim()).filter((l) => l.length);
      const ti = lines.findIndex((l) => tcRe.test(l));
      if (ti < 0) continue;
      const m = lines[ti].match(tcRe);
      const start = tcSec(m[1], m[2], m[3], m[4]);
      const end = tcSec(m[5], m[6], m[7], m[8]);
      const t = cleanText(lines.slice(ti + 1).join(" "));
      if (t && end > start) cues.push({ start, end, text: t });
    }
    cues.sort((a, b) => a.start - b.start);
    return cues;
  };
  const pad = (n, l) => String(n).padStart(l, "0");
  SV.fmtTime = function (t) {
    t = Math.max(0, t);
    const ms = Math.round(t * 1000);
    return pad(Math.floor(ms / 3600000), 2) + ":" + pad(Math.floor(ms / 60000) % 60, 2) + ":" +
      pad(Math.floor(ms / 1000) % 60, 2) + "," + pad(ms % 1000, 3);
  };
  SV.formatSRT = (cues) => cues.map((c, i) => `${i + 1}\n${SV.fmtTime(c.start)} --> ${SV.fmtTime(c.end)}\n${c.text}`).join("\n\n");

  /* ---------- caption chunks with word timing ---------- */
  function chunkWords(words, maxW, maxC) {
    const out = [];
    let cur = [], c = 0;
    for (const w of words) {
      cur.push(w); c += w.length + 1;
      const brk = /[.!?;:,—]$/.test(w);
      if (cur.length >= maxW || c >= maxC || (brk && cur.length >= 2)) { out.push(cur); cur = []; c = 0; }
    }
    if (cur.length) {
      if (cur.length === 1 && out.length && out[out.length - 1].length < maxW + 1) out[out.length - 1].push(cur[0]);
      else out.push(cur);
    }
    return out;
  }
  SV.chunkCues = function (cues) {
    const chunks = [];
    for (const cue of cues) {
      const words = cue.text.split(/\s+/).filter(Boolean);
      if (!words.length) continue;
      const weights = words.map((w) => w.length + 1);
      const total = weights.reduce((a, b) => a + b, 0);
      const dur = cue.end - cue.start;
      let acc = 0;
      const timed = words.map((w, i) => {
        const s = cue.start + (acc / total) * dur; acc += weights[i];
        return { w, start: s, end: cue.start + (acc / total) * dur };
      });
      let idx = 0;
      for (const grp of chunkWords(words, 4, 26)) {
        const ws = timed.slice(idx, idx + grp.length); idx += grp.length;
        chunks.push({ start: ws[0].start, end: ws[ws.length - 1].end, words: ws });
      }
    }
    // close gaps inside a cue so captions never blink between chunks
    for (let i = 0; i < chunks.length - 1; i++) {
      if (chunks[i + 1].start - chunks[i].end < 0.25) chunks[i].end = chunks[i + 1].start;
    }
    return chunks;
  };

  /* ---------- design / inference helpers ---------- */
  SV.hash = function (n) { // deterministic [0,1)
    n = Math.imul((n | 0) ^ 0x9e3779b9, 0x85ebca6b); n ^= n >>> 13;
    n = Math.imul(n, 0xc2b2ae35); n ^= n >>> 16;
    return (n >>> 0) / 4294967296;
  };
  SV.strHash = function (s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

  const ACCENTS = ["#e5484d", "#3e9bff", "#f5a524", "#46c37b", "#b074f0", "#ff7ab6", "#22d3c5"];
  SV.designFor = function (name, kind) {
    const h = SV.strHash(name);
    return {
      name, kind: kind || "CHARACTER",
      accent: ACCENTS[h % ACCENTS.length],
      hair: kind === "MOM" || (h >> 3) % 3 === 0 ? "bun" : (h >> 5) % 3 === 0 ? "spiky" : "none",
      hat: (h >> 7) % 4 === 0,
      scale: kind === "KID" ? 0.72 : 1,
    };
  };

  function inferBg(name) {
    const n = String(name || "").toLowerCase();
    let type = null;
    if (/(room|apartment|house|home|kitchen|office|building|interior|inside|hall|corridor|lobby|store|shop)/.test(n)) type = "room";
    if (/(bunker|shelter|basement|vault|cellar)/.test(n)) type = "bunker";
    if (/(forest|wood|camp|trail|jungle)/.test(n)) type = "forest";
    if (/(city|street|road|highway|rooftop|roof|town|market|alley|bridge|outside|downtown|parking)/.test(n)) type = "city";
    let mood = null;
    if (/night|midnight|dark|silent/.test(n)) mood = "night";
    else if (/dusk|sunset|evening/.test(n)) mood = "dusk";
    else if (/day|morning|noon|calm/.test(n)) mood = "day";
    else if (/blood|red|panic|chaos|attack|horde/.test(n)) mood = "red";
    else if (/fog|mist/.test(n)) mood = "fog";
    return type || mood ? { type, mood } : null;
  }
  SV.parseBg = function (arg) {
    const n = String(arg || "").toLowerCase();
    const r = inferBg(n) || {};
    return { type: r.type || null, mood: r.mood || null };
  };

  const SFX_FX = [
    [/thunder|lightning/, { flash: 0.7 }],
    [/explo|blast|boom/, { flash: 0.6, shake: 26 }],
    [/crash|slam|bang|smash|impact|break|door/, { shake: 18 }],
    [/gun|shot|shoot/, { flash: 0.35, shake: 10 }],
    [/scream|roar|growl|bite/, { shake: 8 }],
  ];

  /* ---------- compile ---------- */
  SV.compile = function (scenesIn, ctx) {
    ctx = ctx || {};
    const warnings = [];
    const importedCues = ctx.cues && ctx.cues.length ? ctx.cues : null;
    const narrDur = ctx.narrationDuration || 0;
    const tail = ctx.tail != null ? ctx.tail : 1.2;

    // 1) flatten lines with estimated timing (also the fallback)
    let cursor = 0, speed = 1;
    const flat = [];
    const sceneInfo = scenesIn.map((s, si) => {
      const evs = s.events.map((e) => Object.assign({}, e));
      const lines = [];
      evs.forEach((e) => {
        if (e.type === "speaker" && e.opts && e.opts.speed) speed = num(e.opts.speed, 1) || 1;
        if (e.type === "pause") cursor += num(String(e.arg).replace(/s$/i, ""), 0.5);
        if (e.type === "line") {
          const words = e.text.split(/\s+/).length;
          const d = Math.max(1.2, words / (2.6 * speed));
          e.est0 = cursor; e.est1 = cursor + d; cursor += d;
          lines.push(e); flat.push(e);
        }
      });
      return { s, si, evs, lines };
    });
    const estTotal = cursor || 1;

    // 2) final line timing
    let source = "estimated";
    if (importedCues && flat.length) {
      source = "srt";
      const n = flat.length, m = importedCues.length;
      if (n === m) {
        flat.forEach((l, i) => { l.start = importedCues[i].start; l.end = importedCues[i].end; });
      } else {
        warnings.push(`SRT has ${m} cues but script has ${n} spoken lines — scenes were aligned by text length. Re-export SRT with one cue per script line for exact scene cuts.`);
        const cum = [0];
        importedCues.forEach((c) => cum.push(cum[cum.length - 1] + Math.max(1, c.text.length)));
        const tot = cum[cum.length - 1];
        const at = (f) => {
          const target = f * tot;
          let k = 0;
          while (k < m - 1 && cum[k + 1] <= target) k++;
          const c = importedCues[k];
          return c.start + Math.min(1, (target - cum[k]) / Math.max(1, cum[k + 1] - cum[k])) * (c.end - c.start);
        };
        const lc = [0];
        flat.forEach((l) => lc.push(lc[lc.length - 1] + Math.max(1, l.text.length)));
        const lt = lc[lc.length - 1];
        flat.forEach((l, i) => { l.start = at(lc[i] / lt); l.end = at(lc[i + 1] / lt); });
      }
    } else if (narrDur > 0 && flat.length) {
      source = "narration-length";
      const k = narrDur / estTotal;
      flat.forEach((l) => { l.start = l.est0 * k; l.end = l.est1 * k; });
    } else {
      flat.forEach((l) => { l.start = l.est0; l.end = l.est1; });
    }

    const lastEnd = flat.length ? Math.max(...flat.map((l) => l.end)) : 3;
    const duration = Math.max(lastEnd + tail, narrDur ? narrDur + 0.3 : 0, importedCues ? importedCues[importedCues.length - 1].end + 0.3 : 0, 2);

    // 3) scene bounds (scenes without spoken lines are merged forward)
    const valid = [];
    let pending = [];
    sceneInfo.forEach((si) => {
      if (!si.lines.length) { pending = pending.concat(si.evs); return; }
      si.evs = pending.concat(si.evs); pending = [];
      valid.push(si);
    });
    if (pending.length && valid.length) valid[valid.length - 1].evs = valid[valid.length - 1].evs.concat(pending);
    if (!valid.length) warnings.push("No spoken lines found in script.");

    const heroName = (function () {
      for (const si of sceneInfo) for (const e of si.evs) if (e.type === "speaker" && (e.kind === "CHARACTER" || e.kind === "SPEAKER")) return e.name;
      return "SURVIVOR";
    })();

    const scenes = [];
    let prevBg = { type: "city", mood: "dusk" };
    const run = { hud: {}, weather: "none", expr: {} };
    const sfx = [], music = [];

    valid.forEach((si, k) => {
      const start = k === 0 ? 0 : si.lines[0].start;
      const end = k === valid.length - 1 ? duration : valid[k + 1].lines[0].start;
      const sc = {
        index: k, name: si.s.name, start, end,
        seed: SV.strHash(si.s.name) ^ (k * 7919),
        lines: si.lines.map((l) => ({ start: l.start, end: l.end, speaker: l.speaker, kind: l.kind, text: l.text })),
        events: [], cast: [], hasRadio: false,
      };
      // background
      const bgEv = si.evs.find((e) => e.type === "bg");
      const inf = bgEv ? SV.parseBg(bgEv.arg) : inferBg(si.s.name);
      sc.bg = { type: (inf && inf.type) || prevBg.type, mood: (inf && inf.mood) || prevBg.mood };
      prevBg = sc.bg;
      const trEv = si.evs.find((e) => e.type === "transition");
      sc.transition = trEv ? String(trEv.arg || "fade").toLowerCase() : "fade";
      sc.entry = { hud: Object.assign({}, run.hud), weather: run.weather, expr: Object.assign({}, run.expr) };

      // bind tags to times
      let buf = [], seenLine = false, lineIdx = 0, lastCharacter = null;
      const place = (e, t) => {
        const ev = Object.assign({}, e, { t: Math.max(sc.start, Math.min(t, sc.end - 0.01)) });
        buf.push(ev);
      };
      const finalize = (list) => {
        list.forEach((ev) => {
          switch (ev.type) {
            case "speaker":
              if (ev.kind === "CHARACTER" || ev.kind === "SPEAKER") lastCharacter = ev.name;
              if (ev.kind === "RADIO") sc.hasRadio = true;
              if (ev.opts && ev.opts.expression) sc.events.push({ t: ev.t, type: "expr", name: ev.name, value: String(ev.opts.expression) });
              if (ev.kind !== "NARRATOR" && ev.kind !== "RADIO" && !sc.cast.find((c) => c.name === ev.name)) sc.cast.push(SV.designFor(ev.name, ev.kind));
              break;
            case "emotion":
              sc.events.push({ t: ev.t, type: "expr", name: ev.opts.who ? String(ev.opts.who).toUpperCase() : (lastCharacter || heroName), value: ev.arg });
              break;
            case "pose":
              sc.events.push({ t: ev.t, type: "pose", value: String(ev.arg).toLowerCase(), who: ev.opts.who ? String(ev.opts.who).toUpperCase() : null });
              break;
            case "zombies": {
              const a = String(ev.arg).toLowerCase();
              let count = /^\d+$/.test(a) ? parseInt(a, 10) : /horde|many|swarm/.test(a) ? 14 : /few|some/.test(a) ? 3 : /none|clear|off|0/.test(a) ? 0 : 4;
              let mode = String(ev.opts.mode || (/horde|swarm/.test(a) ? "horde" : "approach")).toLowerCase();
              sc.events.push({ t: ev.t, type: "zombies", count, mode, side: String(ev.opts.side || "right").toLowerCase() });
              break;
            }
            case "camera":
              sc.events.push({ t: ev.t, type: "camera", name: String(ev.arg).toLowerCase().replace(/\s+/g, "_"), dur: ev.opts.dur ? num(ev.opts.dur, 2) : sc.end - ev.t, amp: num(ev.opts.amp, 0) });
              break;
            case "weather":
              sc.events.push({ t: ev.t, type: "weather", value: String(ev.arg).toLowerCase() });
              run.weather = String(ev.arg).toLowerCase();
              break;
            case "hud": {
              const kv = {};
              [ev.arg].concat(Object.keys(ev.opts).map((k) => k + "=" + ev.opts[k])).join(",").split(/[,;]/).forEach((p) => {
                const m = p.match(/^\s*([A-Za-z_ ]+?)\s*=\s*(.+?)\s*$/);
                if (m) kv[m[1].toUpperCase()] = m[2];
              });
              sc.events.push({ t: ev.t, type: "hud", kv });
              Object.assign(run.hud, kv);
              break;
            }
            case "caption":
              sc.events.push({ t: ev.t, type: "title", text: ev.arg, dur: num(ev.opts.dur, 2.6) });
              break;
            case "flash":
              sc.events.push({ t: ev.t, type: "flash", color: ev.opts.color || (/red|blood/i.test(ev.arg) ? "#ff2a2a" : "#ffffff"), dur: num(ev.opts.dur, 0.3), amp: 0.9 });
              break;
            case "sfx": {
              const name = String(ev.arg).toLowerCase();
              sfx.push({ t: ev.t, name, volume: num(ev.opts.volume, 0.8) });
              SFX_FX.forEach(([re, fx]) => {
                if (!re.test(name)) return;
                if (fx.flash) sc.events.push({ t: ev.t, type: "flash", color: /thunder|lightning/.test(name) ? "#cfe6ff" : "#fff2c4", dur: 0.28, amp: fx.flash });
                if (fx.shake) sc.events.push({ t: ev.t, type: "camera", name: "shake", dur: 0.55, amp: fx.shake });
              });
              break;
            }
            case "music":
              music.push({ t: ev.t, name: String(ev.arg).toLowerCase(), volume: num(ev.opts.volume, 0.3), stop: /^(stop|off|none|silence)$/i.test(ev.arg) });
              break;
            default: break;
          }
        });
        buf = [];
      };
      si.evs.forEach((e) => {
        if (e.type === "line") {
          const l = si.lines[lineIdx++];
          const t = !seenLine ? sc.start : l.start;
          buf.forEach((b) => (b.t = Math.max(sc.start, Math.min(t, sc.end - 0.01))));
          finalize(buf);
          seenLine = true;
        } else if (e.type === "pause" || e.type === "mark" || e.type === "unknown") {
          /* timing only / ignored */
        } else buf.push(Object.assign({}, e, { t: sc.start }));
      });
      // trailing tags: bind to the last spoken line's start
      const lastStart = si.lines[si.lines.length - 1].start;
      buf.forEach((b) => (b.t = Math.max(sc.start, Math.min(lastStart, sc.end - 0.01))));
      finalize(buf);

      if (!sc.cast.length) sc.cast.push(SV.designFor(heroName, "CHARACTER"));
      sc.cast = sc.cast.slice(0, 3);
      sc.events.sort((a, b) => a.t - b.t);
      sc.events.forEach((e) => { if (e.type === "expr") run.expr[e.name] = e.value; });
      scenes.push(sc);
    });

    // cues for captions
    const cues = importedCues ? importedCues.map((c) => ({ start: c.start, end: c.end, text: c.text }))
      : flat.map((l) => ({ start: l.start, end: l.end, text: l.text }));

    return {
      duration, scenes, cues, captionChunks: SV.chunkCues(cues),
      sfx, music, timingSource: source, warnings, heroName,
      stats: { scenes: scenes.length, lines: flat.length, duration },
    };
  };
})();
