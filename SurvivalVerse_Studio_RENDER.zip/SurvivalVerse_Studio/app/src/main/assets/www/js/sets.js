/* Studio sets: GrowKaz-style layered, lit locations. Each set draws background planes with parallax
   (L(depth, fn)) and returns nothing. Feet line for characters is passed in as o.FY (≈ floor/wall boundary). */
import * as C from '../gk/core.js';
import * as FX from '../gk/fx2d.js';
const { E, clamp, lerp, ease, prog, alpha, shade, mix, seg, circle, ring, rr, poly, linGrad, radGrad, glow, rng, noise } = C;
const W = 1080, H = 1920;
const rect = (g, x, y, w, h, c) => { g.fillStyle = c; g.fillRect(x, y, w, h); };
const flick = (t, seed, amt = 0.35) => 1 - amt * Math.max(0, noise(t * 9 + seed * 3.1, seed)) * (noise(t * 2.3, seed + 4) > 0.55 ? 1 : 0.25);

/* ---------- shared pieces ---------- */
function wallFloor(g, M, fy, o = {}) {
  const wall = o.wall || M.wall, floor = o.floor || M.floor;
  g.fillStyle = linGrad(g, 0, -300, 0, fy, [shade(wall, -0.25), wall, shade(wall, 0.06)]); g.fillRect(-W, -H, W * 3, fy + H);
  if (o.stripes !== false) { g.fillStyle = alpha(shade(wall, 0.12), 0.18); for (let x = -W; x < W * 2; x += 90) g.fillRect(x, -H, 36, fy + H); }
  g.fillStyle = linGrad(g, 0, fy, 0, fy + 800, [shade(floor, 0.1), floor, shade(floor, -0.4)]); g.fillRect(-W, fy, W * 3, H);
  rect(g, -W, fy - 30, W * 3, 30, shade(wall, -0.45));
  rect(g, -W, fy - 32, W * 3, 3, alpha(M_rim(M), 0.25));
  g.strokeStyle = 'rgba(0,0,0,.3)'; g.lineWidth = 2;
  for (let i = -16; i <= 16; i++) { g.beginPath(); g.moveTo(540 + i * 70, fy); g.lineTo(540 + i * 300, fy + 900); g.stroke(); }
  for (let k = 1; k < 7; k++) { const y = fy + k * k * 16; g.beginPath(); g.moveTo(-W, y); g.lineTo(2 * W, y); g.stroke(); }
}
const M_rim = (M) => M.rim || '#8fb8e8';
function lampHang(g, x, y, M, t, seed, len = 260) {
  const f = flick(t, seed, 0.3), sway = Math.sin(t * 1.3 + seed) * 6;
  seg(g, [[x, y], [x + sway * 0.3, y + len]], 4, '#05080f');
  const bx = x + sway * 0.3, by = y + len;
  g.fillStyle = '#05080f'; g.beginPath(); g.moveTo(bx - 40, by + 20); g.lineTo(bx + 40, by + 20); g.lineTo(bx + 20, by - 6); g.lineTo(bx - 20, by - 6); g.closePath(); g.fill();
  glow(g, bx, by + 24, 360 * f, M.practical, 0.5 * f); circle(g, bx, by + 20, 11, alpha('#fff4d0', f));
  g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = linGrad(g, 0, by + 20, 0, by + 620, [alpha(M.practical, 0.2 * f), alpha(M.practical, 0)]);
  g.beginPath(); g.moveTo(bx - 20, by + 20); g.lineTo(bx + 20, by + 20); g.lineTo(bx + 260, by + 620); g.lineTo(bx - 260, by + 620); g.closePath(); g.fill(); g.restore();
}
function floorPool(g, x, y, rx, ry, col, a) { FX.pool(g, x, y, rx, ry, col, a); }
function plant(g, x, y, s, col) { for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (i - 3) * 0.32; seg(g, [[x, y], [x + Math.cos(a) * 120 * s, y + Math.sin(a) * 170 * s], [x + Math.cos(a) * 200 * s, y + Math.sin(a) * 250 * s + 50 * s]], 18 * s, col); } rr(g, x - 46 * s, y - 6, 92 * s, 80 * s, 10 * s); g.fillStyle = shade(col, 0.1); g.fill(); }
function sofa(g, x, y, w, col) { rr(g, x, y - 210, w, 210, 30); g.fillStyle = col; g.fill(); rr(g, x - 30, y - 120, 70, 120, 24); g.fill(); rr(g, x + w - 40, y - 120, 70, 120, 24); g.fill(); g.fillStyle = shade(col, 0.1); rr(g, x + 40, y - 120, w - 80, 70, 18); g.fill(); }
function shelf(g, x, y, w, h, col, seed, M) { const r = rng(seed); rect(g, x, y, w, h, col); const rows = 4; for (let i = 0; i < rows; i++) { const sy = y + (h / rows) * (i + 1); rect(g, x, sy - 8, w, 8, shade(col, 0.15)); let bx = x + 10; while (bx < x + w - 24) { const bw = 12 + r() * 22, bh = 36 + r() * 60; g.fillStyle = mix(M.wall, ['#8a3a3a', '#3a6a8a', '#8a7a3a', '#4a7a5a'][(r() * 4) | 0], 0.5); g.fillRect(bx, sy - 8 - bh, bw, bh); bx += bw + 2; } } }
function pictureFrame(g, x, y, w, h, M, seed) { rect(g, x - 8, y - 8, w + 16, h + 16, shade(M.wall, -0.5)); g.fillStyle = linGrad(g, 0, y, 0, y + h, [M.sky[0], M.sky[M.sky.length - 1]]); g.fillRect(x, y, w, h); FX.hills(g, { seed, y: y + h * 0.7, amp: 20, color: shade(M.sky[0], -0.5), freq: 0.02 }); }
function skyView(M, seed, o = {}) {
  return (g, x, y, w, h) => {
    g.fillStyle = linGrad(g, 0, y, 0, y + h, M.sky); g.fillRect(x, y, w, h);
    if (o.stars !== false) FX.stars(g, 0, { seed, count: 40, area: [x, y, w, h * 0.5] });
    if (o.moon !== false) FX.moon(g, x + w * 0.72, y + h * 0.22, 26, '#e8f0ff');
    FX.skyline(g, { seed: seed + 3, x, y: y + h + 4, w, minH: 50, maxH: 260, color: shade(M.dark, 0.1), windowColor: M.practical, lit: 0.3 });
  };
}
function windowLight(g, x, y, w, fy, M, a = 0.16) { g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = linGrad(g, 0, y, 0, fy + 300, [alpha(M.key, a), alpha(M.key, 0)]); g.beginPath(); g.moveTo(x, y); g.lineTo(x + w, y); g.lineTo(x + w - 180, fy + 380); g.lineTo(x - 380, fy + 380); g.closePath(); g.fill(); g.restore(); }

/* ---------- ROOM / apartment ---------- */
export function room(g, L, o) {
  const { M, t, seed, FY } = o, R = rng(seed), left = R() < 0.5;
  L(0.55, (g) => {
    wallFloor(g, M, FY);
    const wx = left ? 70 : 640;
    FX.windowFrame(g, { x: wx, y: 300, w: 370, h: 560, cols: 2, rows: 3, frame: shade(M.wall, -0.55), bar: 10, blinds: o.blinds ? 40 : 0 }, skyView(M, seed));
    rect(g, wx - 24, 860, 418, 18, shade(M.wall, -0.4));
    windowLight(g, wx, 360, 370, FY, M, 0.14);
    pictureFrame(g, left ? 610 : 130, 380, 220, 160, M, seed);
    const cx = left ? 840 : 220; FX.clock(g, cx, 250, 46, 0, { face: '#d8dfeb', ink: '#10151f', red: '#e04a3a', speed: 0.0 });
  });
  L(0.82, (g) => {
    sofa(g, left ? 560 : -60, FY + 6, 520, shade(M.wall, -0.1));
    shelf(g, left ? 40 : 800, FY - 520, 230, 520, shade(M.dark, 0.12), seed, M);
    plant(g, left ? 480 : 600, FY + 4, 1.2, shade(M.dark, 0.2));
    lampHang(g, 540, -40, M, t, seed, 330);
    floorPool(g, left ? 250 : 790, FY + 150, 260, 70, M.key, 0.12);
  });
  L(1.28, (g) => { plant(g, left ? 1010 : 70, 1960, 2.2, alpha('#02040a', 0.96)); });
}

/* ---------- DOOR (focus) ---------- */
export function doorSet(g, L, o) {
  const { M, t, seed, FY, knock = 0, openAmt = 0 } = o, R = rng(seed);
  L(0.6, (g) => {
    wallFloor(g, M, FY, { stripes: true });
    // wall sconces
    for (const x of [90, 990]) { rect(g, x - 18, 520, 36, 70, shade(M.wall, -0.5)); glow(g, x, 540, 240, M.practical, 0.28 * flick(t, seed + x)); }
    // door mat
    g.fillStyle = shade(M.floor, 0.12); g.beginPath(); g.moveTo(330, FY + 24); g.lineTo(750, FY + 24); g.lineTo(800, FY + 90); g.lineTo(280, FY + 90); g.closePath(); g.fill();
  });
  L(0.9, (g) => {
    const dx = 280 + knock * 3, dw = 520, dy = 290, dh = FY - dy + 6, col = mix(M.wall, '#7a573a', 0.55);
    // frame
    rect(g, dx - 40, dy - 40, dw + 80, dh + 40, shade(col, -0.55));
    // gap light beyond when open
    if (openAmt > 0) { g.fillStyle = linGrad(g, dx, 0, dx + 90 * openAmt, 0, [alpha(M.practical, 0.95), alpha(M.dark, 1)]); g.fillRect(dx, dy, dw, dh); glow(g, dx + 50, dy + dh / 2, 600, M.practical, 0.35 * openAmt); }
    g.save(); g.translate(dx + dw * 0.0, 0);
    // door leaf swings: perspective by squeezing
    const sx = 1 - 0.14 * openAmt; g.translate(0, 0); g.transform(sx, 0, 0, 1, dx * (1 - sx), 0);
    g.fillStyle = linGrad(g, dx, 0, dx + dw, 0, [shade(col, 0.05), col, shade(col, -0.2)]); g.fillRect(dx, dy, dw, dh);
    for (const [px, py, pw, ph] of [[dx + 50, dy + 60, 180, 300], [dx + 290, dy + 60, 180, 300], [dx + 50, dy + 420, 180, 360], [dx + 290, dy + 420, 180, 360]]) { rect(g, px, py, pw, ph, shade(col, -0.12)); g.strokeStyle = shade(col, 0.18); g.lineWidth = 3; g.strokeRect(px, py, pw, ph); }
    // handle + lock + peephole + chain
    const hx = dx + dw - 64, hy = dy + dh * 0.52; circle(g, hx, hy, 24, '#c8a85a'); rr(g, hx - 74, hy - 9, 90, 18, 9); g.fillStyle = '#d8bb6a'; g.fill(); circle(g, hx, hy + 76, 12, '#a88a3a');
    circle(g, dx + dw / 2, dy + 120, 13, '#0a0e14'); ring(g, dx + dw / 2, dy + 120, 13, 4, '#b89a4a');
    seg(g, [[dx + dw - 24, hy - 140], [dx + dw - 120, hy - 140]], 4, '#9aa3b0'); for (let i = 0; i < 6; i++) circle(g, dx + dw - 40 - i * 15, hy - 134 + Math.sin(i) * 2, 5, '#9aa3b0');
    g.restore();
    // light under door
    const lf = flick(t, seed + 5, 0.5);
    g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = linGrad(g, 0, FY - 10, 0, FY + 160, [alpha(M.practical, 0.6 * lf), alpha(M.practical, 0)]);
    g.beginPath(); g.moveTo(dx + 10, FY - 6); g.lineTo(dx + dw - 10, FY - 6); g.lineTo(dx + dw + 220, FY + 200); g.lineTo(dx - 220, FY + 200); g.closePath(); g.fill(); g.restore();
    // shadow of feet moving behind the door
    if (o.shadowsBehind) { const px = dx + dw * (0.3 + 0.4 * (0.5 + 0.5 * Math.sin(t * 0.9))); g.fillStyle = 'rgba(0,0,0,.85)'; g.fillRect(px - 26, FY - 16, 22, 16); g.fillRect(px + 20, FY - 16, 22, 16); }
  });
}

/* ---------- perspective corridor (hallway / alley) ---------- */
function corridor(g, L, o, mat) {
  const { M, t, seed, scroll = 0 } = o, vp = [540, 780], fw = 150, fh = 210;
  const pt = (d, side, y) => [vp[0] + side * (fw + (700 - fw) * d), vp[1] + y * (d * 1 + 0)]; // unused helper
  const sc = (d) => 0.14 + 0.86 * d * d; // d: 0 far .. 1 near
  const wx = (d, side) => vp[0] + side * (130 + 760 * sc(d)), top = (d) => vp[1] - (170 + 760 * sc(d)), bot = (d) => vp[1] + (110 + 900 * sc(d));
  L(0.65, (g) => {
    mat.bg?.(g, M);
    // far end glow
    glow(g, vp[0], vp[1] + 20, 380, mat.endColor || M.practical, 0.3);
    // ceiling, floor, walls (as quads near->far)
    const q = (a, b) => [[wx(a, -1), top(a)], [wx(b, -1), top(b)], [wx(b, 1), top(b)], [wx(a, 1), top(a)]];
    g.fillStyle = linGrad(g, 0, 0, 0, vp[1], [mat.ceil || shade(M.wall, -0.5), shade(mat.ceil || M.wall, -0.1)]); poly(g, q(1.35, 0).map((p, i) => p), g.fillStyle);
    g.fillStyle = linGrad(g, 0, vp[1], 0, H, [shade(M.floor, 0.05), shade(M.floor, -0.25)]); poly(g, [[wx(1.35, -1), bot(1.35)], [wx(0, -1), bot(0)], [wx(0, 1), bot(0)], [wx(1.35, 1), bot(1.35)]], g.fillStyle);
    g.fillStyle = linGrad(g, 0, 0, W, 0, [shade(mat.wallL || M.wall, -0.3), mat.wallL || M.wall]); poly(g, [[wx(1.35, -1), top(1.35)], [wx(0, -1), top(0)], [wx(0, -1), bot(0)], [wx(1.35, -1), bot(1.35)]], g.fillStyle);
    g.fillStyle = linGrad(g, W, 0, 0, 0, [shade(mat.wallR || M.wall, -0.3), mat.wallR || M.wall]); poly(g, [[wx(1.35, 1), top(1.35)], [wx(0, 1), top(0)], [wx(0, 1), bot(0)], [wx(1.35, 1), bot(1.35)]], g.fillStyle);
    // receding bands (doors / bricks / lights) – scroll moves them toward the viewer
    const N = 7, ph = ((scroll / 900) % 1 + 1) % 1;
    for (let i = N; i >= 0; i--) {
      const d = clamp((i + ph) / N), d2 = clamp((i + ph + 0.55) / N);
      if (d <= 0.02) continue;
      mat.band?.(g, { d, d2, wx, top, bot, vp, i, M, t, seed, sc });
    }
    // floor / ceiling edge lines
    g.strokeStyle = alpha('#000', 0.35); g.lineWidth = 3;
    for (const side of [-1, 1]) { seg(g, [[wx(1.35, side), bot(1.35)], [wx(0, side), bot(0)]], 3, alpha('#000', 0.4)); seg(g, [[wx(1.35, side), top(1.35)], [wx(0, side), top(0)]], 3, alpha('#000', 0.4)); }
    // end fog
    g.fillStyle = radGrad(g, vp[0], vp[1], 20, 520, [alpha(mat.fog || M.fog, 0.65), alpha(mat.fog || M.fog, 0)]); g.fillRect(-W, -H, W * 3, H * 3);
  });
}
export function hallway(g, L, o) {
  const { M, t, seed } = o;
  corridor(g, L, o, {
    wallL: mix(M.wall, '#4a5a7a', 0.25), wallR: mix(M.wall, '#4a5a7a', 0.2), ceil: shade(M.wall, -0.35), endColor: '#9fd0ff', fog: M.fog,
    band(g, b) {
      const { d, d2, wx, top, bot, i } = b;
      // ceiling light
      const lx = 540, ly = top(d) + 6, lw = 170 * b.sc(d) + 18; const f = flick(t, seed + i * 7, 0.55 * (i % 3 === 0 ? 1 : 0.2));
      g.save(); g.globalCompositeOperation = 'lighter'; glow(g, lx, ly + 14, 280 * b.sc(d) + 60, M.practical, 0.34 * f); g.restore();
      rect(g, lx - lw / 2, ly, lw, 10 * b.sc(d) + 3, alpha('#fff2d0', 0.9 * f));
      // doors on both walls
      for (const side of [-1, 1]) {
        if ((i + (side > 0 ? 1 : 0)) % 2) continue;
        const xa = wx(d, side), xb = wx(d2, side), ya0 = top(d) + (bot(d) - top(d)) * 0.17, yb0 = top(d2) + (bot(d2) - top(d2)) * 0.17;
        poly(g, [[xa, ya0], [xb, yb0], [xb, bot(d2)], [xa, bot(d)]], shade(M.wall, -0.5));
        const ia = lerp(xa, xb, 0.1), ib = lerp(xa, xb, 0.9);
        poly(g, [[ia, lerp(ya0, bot(d), 0.05) + 8], [ib, lerp(yb0, bot(d2), 0.05) + 8], [ib, bot(d2) - 2], [ia, bot(d) - 2]], mix(M.wall, '#6a4a3a', 0.4));
        circle(g, lerp(ia, ib, 0.82), lerp(bot(d), ya0, 0.42), 5 * b.sc(d) + 1.5, '#c8a85a');
      }
    },
  });
  L(0.8, (g) => { g.fillStyle = 'rgba(0,0,0,.4)'; g.fillRect(-W, 0, W * 3, 6); });
}
export function alley(g, L, o) {
  const { M, t, seed } = o, R = rng(seed);
  corridor(g, L, o, {
    wallL: mix(M.wall, '#5a3a34', 0.4), wallR: mix(M.wall, '#4a3a3a', 0.4), ceil: M.sky[1], endColor: M.practical, fog: M.fog,
    bg(g, M) { g.fillStyle = linGrad(g, 0, 0, 0, 900, M.sky); g.fillRect(-W, -H, W * 3, H * 2); FX.stars(g, 0, { seed, count: 60, area: [0, 0, W, 500] }); },
    band(g, b) {
      const { d, d2, wx, top, bot, i } = b;
      for (const side of [-1, 1]) {
        const xa = wx(d, side), xb = wx(d2, side);
        // brick courses
        g.strokeStyle = 'rgba(0,0,0,.3)'; g.lineWidth = 2 * b.sc(d) + 1;
        for (let k = 1; k < 8; k++) { const ya = lerp(top(d), bot(d), k / 8), yb = lerp(top(d2), bot(d2), k / 8); g.beginPath(); g.moveTo(xa, ya); g.lineTo(xb, yb); g.stroke(); }
        if ((i + (side > 0 ? 1 : 0)) % 3 === 0) { const ya0 = top(d) + (bot(d) - top(d)) * 0.18; poly(g, [[xa, ya0], [xb, top(d2) + (bot(d2) - top(d2)) * 0.18], [xb, bot(d2)], [xa, bot(d)]], shade(M.dark, 0.05)); }
        if (i === 2 && side < 0) { const hh = (bot(d) - top(d)) * 0.2; poly(g, [[xa + 8, bot(d) - hh * 1.3], [xb + 6, bot(d2) - hh * 1.3], [xb + 6, bot(d2) - 2], [xa + 8, bot(d) - 2]], mix(M.wall, '#2a5a4a', 0.55)); }
        if (i === 4 && side > 0) { const lx = xa - 40 * b.sc(d), ly = top(d) + (bot(d) - top(d)) * 0.3; glow(g, lx, ly, 330 * b.sc(d) + 50, M.practical, 0.45 * flick(t, seed + 9, 0.5)); circle(g, lx, ly, 10 * b.sc(d) + 3, '#fff1c0'); }
      }
    },
  });
  L(0.9, (g) => { // wet ground sheen + puddle
    g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = linGrad(g, 0, 1100, 0, 1500, [alpha(M.practical, 0.12), alpha(M.practical, 0)]); g.fillRect(200, 1100, 700, 500); g.restore();
    g.fillStyle = alpha(M.sky[1], 0.5); g.beginPath(); g.ellipse(360, 1560, 190, 26, 0, 0, Math.PI * 2); g.fill();
    FX.steam?.(g, t);
  });
}

/* ---------- ELEVATOR ---------- */
export function elevator(g, L, o) {
  const { M, t, seed, FY, lt = 0, inside = false, openAmt: oa = null } = o;
  const open = oa != null ? oa : ease.inOut(prog(lt, 0.35, 1.5));
  if (!inside) {
    L(0.65, (g) => {
      const wall = mix(M.wall, '#6a7a90', 0.3); g.fillStyle = linGrad(g, 0, 0, W, 0, [shade(wall, -0.2), wall, shade(wall, -0.2)]); g.fillRect(-W, -H, W * 3, FY + H);
      for (let x = -W; x < W * 2; x += 240) { rect(g, x, 0, 4, FY, 'rgba(0,0,0,.35)'); rect(g, x + 4, 0, 2, FY, 'rgba(255,255,255,.07)'); }
      g.fillStyle = linGrad(g, 0, FY, 0, FY + 800, [shade(M.floor, 0.12), M.floor, shade(M.floor, -0.4)]); g.fillRect(-W, FY, W * 3, H);
      g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 3; for (let i = -10; i <= 10; i++) { g.beginPath(); g.moveTo(540 + i * 90, FY); g.lineTo(540 + i * 330, FY + 900); g.stroke(); } for (let k = 1; k < 6; k++) { g.beginPath(); g.moveTo(-W, FY + k * k * 20); g.lineTo(2 * W, FY + k * k * 20); g.stroke(); }
      rect(g, -W, FY - 28, W * 3, 28, shade(wall, -0.5));
      // ceiling light
      rect(g, 0, 0, W, 40, shade(M.wall, -0.5)); glow(g, 540, 60, 520, M.key, 0.2 * flick(t, seed, 0.4));
    });
    L(0.92, (g) => {
      const ex = 250, ew = 580, ey = 300, eh = FY - ey + 4, a = open;
      rect(g, ex - 44, ey - 44, ew + 88, eh + 44, shade(M.wall, -0.5)); rect(g, ex - 44, ey - 44, ew + 88, 10, alpha(M_rim(M), 0.4));
      // interior (visible when open)
      const inner = ew * 0.5 * a;
      g.save(); g.beginPath(); g.rect(ex, ey, ew, eh); g.clip();
      g.fillStyle = linGrad(g, 0, ey, 0, FY, [mix(M.practical, '#fff', 0.25), mix(M.practical, M.wall, 0.45)]); g.fillRect(ex, ey, ew, eh);
      seg(g, [[ex + 20, FY - 380], [ex + ew - 20, FY - 380]], 12, '#b8c0cc'); // handrail
      rect(g, ex, FY - 24, ew, 24, shade(M.floor, 0.1));
      g.restore();
      glow(g, ex + ew / 2, ey + eh * 0.55, 700, M.practical, 0.34 * a);
      // door leaves
      const lw = ew / 2 - inner;
      for (const s of [0, 1]) {
        const x0 = s ? ex + ew - lw : ex; g.fillStyle = linGrad(g, x0, 0, x0 + lw, 0, [shade('#8a95a6', s ? -0.1 : 0.05), '#aab4c2', shade('#8a95a6', s ? 0.05 : -0.1)]); g.fillRect(x0, ey, lw, eh);
        g.fillStyle = 'rgba(255,255,255,.08)'; for (let k = 0; k < 6; k++) g.fillRect(x0 + (lw * k) / 6, ey, 3, eh); rect(g, s ? x0 : x0 + lw - 4, ey, 4, eh, 'rgba(0,0,0,.45)');
      }
      // floor indicator + call button
      rr(g, ex + ew / 2 - 70, ey - 120, 140, 66, 10); g.fillStyle = '#05080e'; g.fill();
      const fl = 6 - ((Math.floor(t * 0.9) + (seed & 3)) % 6); C.text(g, String(Math.max(1, fl)), ex + ew / 2 - 26, ey - 87, { size: 46, color: '#ff6a4a', font: 'Nunito', weight: 900, glow: 14, glowColor: '#ff3a2a' });
      poly(g, [[ex + ew / 2 + 32, ey - 72], [ex + ew / 2 + 54, ey - 72], [ex + ew / 2 + 43, ey - 100]], '#ff6a4a');
      rr(g, ex + ew + 70, ey + eh * 0.42, 46, 110, 10); g.fillStyle = '#10151e'; g.fill(); circle(g, ex + ew + 93, ey + eh * 0.42 + 34, 11, alpha('#ffcf6a', 0.8 + 0.2 * Math.sin(t * 4))); circle(g, ex + ew + 93, ey + eh * 0.42 + 76, 11, '#5a6270');
      // light spill on floor
      g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = linGrad(g, 0, FY, 0, FY + 420, [alpha(M.practical, 0.35 * a), alpha(M.practical, 0)]); g.beginPath(); g.moveTo(ex, FY); g.lineTo(ex + ew, FY); g.lineTo(ex + ew + 260, FY + 420); g.lineTo(ex - 260, FY + 420); g.closePath(); g.fill(); g.restore();
    });
  } else {
    L(0.7, (g) => {
      const wall = '#8e99a9'; g.fillStyle = linGrad(g, 0, 0, W, 0, [shade(wall, -0.45), shade(wall, -0.1), shade(wall, -0.45)]); g.fillRect(-W, -H, W * 3, H * 3);
      for (let x = -W; x < W * 2; x += 180) rect(g, x, 0, 3, H, 'rgba(0,0,0,.35)');
      rect(g, 0, 0, W, 120, shade(wall, -0.6)); const f = flick(t, seed, 0.5);
      rr(g, 240, 36, 600, 54, 10); g.fillStyle = alpha('#fff4d8', 0.85 * f); g.fill(); glow(g, 540, 70, 760, M.practical, 0.3 * f);
      seg(g, [[-100, 1040], [W + 100, 1040]], 18, '#c8d0dc'); seg(g, [[-100, 1054], [W + 100, 1054]], 4, 'rgba(0,0,0,.4)');
      rect(g, -W, FY - 10, W * 3, 800, shade(M.floor, -0.1)); g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 3; for (let k = 0; k < 8; k++) { g.beginPath(); g.moveTo(-W, FY + k * 70); g.lineTo(2 * W, FY + k * 70); g.stroke(); }
      rr(g, 800, 640, 150, 440, 18); g.fillStyle = '#10151e'; g.fill();
      for (let r = 0; r < 4; r++) for (let c = 0; c < 2; c++) { const on = ((r * 2 + c + (seed & 3)) % 5) === 0; circle(g, 838 + c * 74, 690 + r * 100, 22, on ? '#ffcf6a' : '#4a5260'); if (on) glow(g, 838 + c * 74, 690 + r * 100, 70, '#ffcf6a', 0.4); }
      rr(g, 380, 150, 320, 90, 12); g.fillStyle = '#05080e'; g.fill(); C.text(g, String(Math.max(1, 6 - ((Math.floor(t * 1.4) + (seed & 3)) % 6))), 540, 196, { size: 64, color: '#ff6a4a', font: 'Nunito', weight: 900, glow: 18, glowColor: '#ff3a2a' });
    });
  }
}

/* ---------- STAIRWELL ---------- */
export function stairs(g, L, o) {
  const { M, t, seed, FY } = o, R = rng(seed);
  L(0.6, (g) => {
    g.fillStyle = linGrad(g, 0, 0, 0, H, [shade(M.wall, -0.35), M.wall, shade(M.wall, -0.3)]); g.fillRect(-W, -H, W * 3, H * 3);
    g.fillStyle = 'rgba(255,255,255,.035)'; for (let k = 0; k < 18; k++) g.fillRect(-W + k * 170 + (k % 2) * 30, -H, 3, H * 3);
    // stencilled floor number
    C.text(g, String(6 - (o.floorOffset || 0)), 220, 560, { size: 340, color: alpha('#fff', 0.1), font: 'Nunito', weight: 900 });
    // emergency light
    rr(g, 850, 220, 150, 70, 12); g.fillStyle = '#071a10'; g.fill(); C.text(g, 'EXIT', 925, 256, { size: 38, color: '#5fffa8', font: 'Nunito', weight: 900, glow: 16, glowColor: '#2aff80' });
    const red = 0.4 + 0.6 * Math.max(0, Math.sin(t * 3)); glow(g, 120, 160, 340, '#ff3a2a', 0.22 * red); circle(g, 120, 160, 12, alpha('#ff5a4a', 0.7 + 0.3 * red));
  });
  L(0.85, (g) => {
    // back flight (descending to the right), front flight rising to the left
    const flight = (x0, y0, n, dx, dy, col, thick) => { for (let i = 0; i < n; i++) { const x = x0 + i * dx, y = y0 + i * dy; rect(g, x, y, dx + 2, thick, col); rect(g, x, y, dx + 2, 8, shade(col, 0.3)); rect(g, x + dx - 2, y + 8, 4, dy, shade(col, -0.4)); } };
    flight(380, 760, 11, 62, -40, shade(M.floor, 0.05), 220);
    // underside slab
    poly(g, [[380, 980], [1062, 580], [1062, 1100], [380, 1100]], shade(M.floor, -0.35));
    flight(-100, 1260, 12, 68, -46, shade(M.floor, 0.12), 200);
    // railings
    seg(g, [[-100, 1060], [716, 590]], 12, '#9aa5b8'); for (let k = 0; k < 14; k++) { const x = -60 + k * 60, y = 1040 - k * 33.6; seg(g, [[x, y], [x, y + 190 - k * 4]], 5, '#7a8598'); }
    seg(g, [[380, 600], [1062, 360]], 10, '#8892a4');
    // landing
    rect(g, -W, FY + 20, W * 3, 800, shade(M.floor, -0.15)); rect(g, -W, FY + 20, W * 3, 10, alpha(M_rim(M), 0.2));
    glow(g, 880, 400, 600, M.practical, 0.18 * flick(t, seed, 0.4));
  });
}

/* ---------- BUNKER ---------- */
export function bunker(g, L, o) {
  const { M, t, seed, FY } = o, R = rng(seed);
  L(0.6, (g) => {
    g.fillStyle = linGrad(g, 0, 0, 0, FY, [shade(M.wall, -0.3), M.wall]); g.fillRect(-W, -H, W * 3, FY + H);
    g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 3; for (let x = -W; x < 2 * W; x += 220) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, FY); g.stroke(); } for (let y = 120; y < FY; y += 160) { g.beginPath(); g.moveTo(-W, y); g.lineTo(2 * W, y); g.stroke(); }
    for (let k = 0; k < 3; k++) seg(g, [[-100, 150 + k * 40], [W + 100, 150 + k * 40]], 18, shade(M.dark, 0.12 + k * 0.03));
    for (let x = 120; x < W; x += 260) rect(g, x, 130, 14, 130, shade(M.dark, 0.2));
    rect(g, -W, FY, W * 3, H, shade(M.floor, -0.1));
    // steel door
    rect(g, 60, 360, 300, FY - 360, shade(M.wall, 0.12)); g.strokeStyle = shade(M.wall, -0.5); g.lineWidth = 8; g.strokeRect(60, 360, 300, FY - 360); circle(g, 306, 820, 34, '#8f9bb0'); ring(g, 306, 820, 34, 6, '#4a5468');
    for (let k = 0; k < 8; k++) circle(g, 90 + (k % 2) * 240, 400 + Math.floor(k / 2) * 160, 7, '#4a5468');
  });
  L(0.85, (g) => {
    shelf(g, 640, FY - 460, 360, 460, shade(M.dark, 0.18), seed, M);
    rr(g, 440, FY - 100, 200, 100, 10); g.fillStyle = shade(M.wall, -0.2); g.fill();
    lampHang(g, 540, -60, M, t, seed, 420);
  });
}

/* ---------- CITY / street ---------- */
export function city(g, L, o) {
  const { M, t, seed, FY, scroll = 0, weather = '' } = o;
  L(0.3, (g) => { g.fillStyle = linGrad(g, 0, -300, 0, 1200, M.sky); g.fillRect(-W, -H, W * 3, H * 3); FX.stars(g, 0, { seed, count: 80, area: [-100, 0, W + 200, 700] }); FX.moon(g, 780, 330, 54); FX.clouds(g, { seed, y: 420, color: M.fog, a: 0.12, count: 5 }); });
  L(0.5, (g) => { FX.skyline(g, { seed, x: -100, y: 1130, w: W + 300, minH: 160, maxH: 640, color: shade(M.dark, 0.14), windowColor: M.practical, lit: 0.22, minW: 70, maxW: 150 }); });
  L(0.72, (g) => { FX.skyline(g, { seed: seed + 9, x: -140 - (scroll * 0.2 % 160), y: 1200, w: W + 400, minH: 120, maxH: 420, color: shade(M.dark, 0.06), windowColor: M.practical, lit: 0.3, minW: 90, maxW: 190 }); FX.fog(g, 960, 300, M.fog, 0.4); });
  L(0.95, (g) => {
    g.fillStyle = linGrad(g, 0, FY - 20, 0, H, [shade(M.floor, 0.1), M.floor, shade(M.floor, -0.45)]); g.fillRect(-W, FY - 20, W * 3, H);
    rect(g, -W, FY - 24, W * 3, 8, alpha(M_rim(M), 0.22));
    for (let k = 0; k < 6; k++) { const x = ((k * 420 - scroll * 0.9) % 2520 + 2520) % 2520 - 700; rect(g, x, FY + 150, 180, 16, 'rgba(255,255,255,.12)'); }
    FX.lampPost(g, 150 - (scroll * 0.6 % 800), FY, 460, { color: '#04070d', light: M.practical, a: 0.2 });
    FX.lampPost(g, 920 - (scroll * 0.6 % 800) + 0, FY, 460, { color: '#04070d', light: M.practical, a: 0.2 });
    // wrecked car
    rr(g, 600, FY - 110, 300, 84, 16); g.fillStyle = shade(M.dark, 0.14); g.fill(); rr(g, 660, FY - 170, 170, 70, 18); g.fill(); circle(g, 660, FY - 22, 30, '#02030a'); circle(g, 850, FY - 22, 30, '#02030a');
  });
  if (/rain|storm/.test(weather)) { /* rain drawn by caller */ }
}
export function forest(g, L, o) {
  const { M, t, seed, FY } = o;
  L(0.3, (g) => { g.fillStyle = linGrad(g, 0, -200, 0, 1200, M.sky); g.fillRect(-W, -H, W * 3, H * 3); FX.stars(g, 0, { seed, count: 70, area: [-100, 0, W + 200, 600] }); FX.moon(g, 280, 380, 60); });
  L(0.5, (g) => { FX.hills(g, { seed, y: 1250, amp: 160, color: shade(M.dark, 0.12), freq: 0.004 }); });
  for (const [d, col, y, s] of [[0.62, shade(M.dark, 0.1), 1290, 1.4], [0.8, shade(M.dark, 0.03), 1350, 1.9], [1.0, '#03060b', 1420, 2.6]]) L(d, (g) => { const R = rng(seed + (d * 10 | 0)); for (let x = -150; x < W + 250; x += 150 + R() * 110) FX.pine(g, x, y, s * (0.8 + R() * 0.5), col); if (d < 1) FX.fog(g, y - 140, 260, M.fog, 0.35); });
  L(0.95, (g) => { g.fillStyle = linGrad(g, 0, FY - 60, 0, H, [shade(M.floor, 0.05), shade(M.floor, -0.5)]); g.fillRect(-W, FY - 60, W * 3, H); });
}
export function custom(g, L, o) {
  const img = o.image; L(0.8, (g) => {
    if (img && img.width) { const k = Math.max((W + 160) / img.width, (H + 240) / img.height); const w = img.width * k, h = img.height * k; g.drawImage(img, W / 2 - w / 2, H / 2 - h / 2, w, h); }
    else { g.fillStyle = M0(o); g.fillRect(-W, -H, W * 3, H * 3); }
  });
}
const M0 = (o) => o.M.wall;

export const SETS = { room, door: doorSet, hallway, alley, elevator, stairs, bunker, city, forest, custom };
