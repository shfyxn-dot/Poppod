/* SurvivalVerse Studio — deterministic Canvas scene engine.
   drawFrame(ctx, comp, t) is a PURE function of time: same t => identical pixels,
   so preview, scrubbing, contact sheets and the final frame-by-frame render always agree.
   Logical canvas is 1080x1920; callers pre-scale the context for other output sizes. */
(function () {
  const SV = (window.SV = window.SV || {});
  const W = 1080, H = 1920, TAU = Math.PI * 2, HORIZON = 1060, FEET_Y = 1250;
  SV.W = W; SV.H = H;
  SV.charAssets = SV.charAssets || {}; // name -> {height,yOff,facesLeft,slots:{idle:Image,...}}
  SV.bgImages = SV.bgImages || {};
  const H1 = (n) => SV.hash(n);
  const clamp = (v, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, t) => a + (b - a) * t;
  const ease = (t) => t * t * (3 - 2 * t);
  const easeOut = (t) => 1 - Math.pow(1 - t, 3);
  const mod = (a, n) => ((a % n) + n) % n;
  const rad = (d) => (d * Math.PI) / 180;

  const MOODS = {
    night: { sky: ["#04080f", "#14293f"], far: "#0c1828", mid: "#09111b", near: "#060b12", ground: ["#16202b", "#080c12"], lane: "#33465a", win: "#ffd88a", fog: "#4a6a8a", stars: true, moon: true, lamp: "#ffd9a0" },
    dusk: { sky: ["#2a1b3d", "#e0735a"], far: "#4a2a47", mid: "#2f1c38", near: "#1c1125", ground: ["#34283a", "#130c19"], lane: "#6a5470", win: "#ffc46b", fog: "#b46a68", sun: true, lamp: "#ffcf8a" },
    day: { sky: ["#6ab0dc", "#e3f3f8"], far: "#a3bccb", mid: "#8199a9", near: "#5f7886", ground: ["#7a8590", "#444b54"], lane: "#c3ccd5", win: "#d6ebff", fog: "#eaf3f8", sun: true, clouds: true, lamp: "#fff4cf" },
    red: { sky: ["#240606", "#9a2a24"], far: "#400f0f", mid: "#2c0909", near: "#1a0505", ground: ["#2e1212", "#100404"], lane: "#6a2626", win: "#ff8a6a", fog: "#9a2e2e", lamp: "#ff9a7a" },
    fog: { sky: ["#4c5762", "#a3afb7"], far: "#80909a", mid: "#62727d", near: "#3f4c55", ground: ["#505b64", "#262c32"], lane: "#8a969f", win: "#ebe5c4", fog: "#bcc7cd", lamp: "#fff0c0" },
  };
  const moodOf = (bg) => MOODS[bg.mood] || MOODS.dusk;

  /* ---------- offscreen cache ---------- */
  const cache = new Map();
  function mk(w, h) { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; }
  function cached(key, w, h, build) {
    let c = cache.get(key);
    if (!c) { c = mk(w, h); build(c.getContext("2d"), c); cache.set(key, c); }
    return c;
  }
  SV.clearEngineCache = () => cache.clear();

  /* ---------- backgrounds ---------- */
  function skyCanvas(P, mood) {
    return cached("sky:" + mood, W, 1120, (g) => {
      const gr = g.createLinearGradient(0, 0, 0, HORIZON + 40);
      gr.addColorStop(0, P.sky[0]); gr.addColorStop(1, P.sky[1]);
      g.fillStyle = gr; g.fillRect(0, 0, W, 1120);
      if (P.stars) {
        for (let i = 0; i < 110; i++) {
          g.globalAlpha = 0.25 + H1(i * 3 + 2) * 0.6; g.fillStyle = "#fff";
          const r = 1 + H1(i * 3 + 3) * 2;
          g.beginPath(); g.arc(H1(i * 3) * W, H1(i * 3 + 1) * 760, r, 0, TAU); g.fill();
        }
        g.globalAlpha = 1;
      }
      if (P.moon) {
        const rg = g.createRadialGradient(820, 330, 60, 820, 330, 340);
        rg.addColorStop(0, "rgba(190,215,255,.35)"); rg.addColorStop(1, "rgba(190,215,255,0)");
        g.fillStyle = rg; g.fillRect(380, 0, 700, 700);
        g.fillStyle = "#eaf2ff"; g.beginPath(); g.arc(820, 330, 88, 0, TAU); g.fill();
        g.fillStyle = "rgba(120,140,170,.35)";
        [[795, 310, 18], [850, 355, 14], [830, 290, 10]].forEach(([x, y, r]) => { g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); });
      }
      if (P.sun) {
        const sy = mood === "day" ? 300 : 980, sr = mood === "day" ? 70 : 170;
        const rg = g.createRadialGradient(mood === "day" ? 800 : 300, sy, sr * 0.3, mood === "day" ? 800 : 300, sy, sr * 4);
        rg.addColorStop(0, "rgba(255,220,160,.55)"); rg.addColorStop(1, "rgba(255,220,160,0)");
        g.fillStyle = rg; g.fillRect(0, 0, W, 1120);
        g.fillStyle = mood === "day" ? "#fff6d8" : "#ffb878";
        g.beginPath(); g.arc(mood === "day" ? 800 : 300, sy, sr, 0, TAU); g.fill();
      }
      if (P.clouds) {
        g.fillStyle = "rgba(255,255,255,.55)";
        [[200, 260, 180], [640, 180, 220], [900, 420, 150]].forEach(([x, y, w]) => {
          for (let k = 0; k < 4; k++) { g.beginPath(); g.ellipse(x + k * w * 0.25, y + Math.sin(k * 2) * 12, w * 0.3, w * 0.12, 0, 0, TAU); g.fill(); }
        });
      }
    });
  }

  const PER = 1620;
  function cityLayer(P, mood, kind) {
    return cached(`city:${mood}:${kind}`, PER, 1120, (g) => {
      const base = [1052, 1078, 1104][kind], col = [P.far, P.mid, P.near][kind];
      const seed = 1000 + kind * 77;
      let x = -30, i = 0;
      while (x < PER) {
        const w = [100, 130, 160][kind] * (0.7 + H1(seed + i * 5) * 0.9);
        const h = [360, 290, 210][kind] * (0.45 + H1(seed + i * 5 + 1) * 1.0);
        g.fillStyle = col;
        g.beginPath();
        if (H1(seed + i * 5 + 2) < 0.28) { // ruined, slanted top
          g.moveTo(x, base); g.lineTo(x, base - h); g.lineTo(x + w * 0.55, base - h - 40 * H1(seed + i)); g.lineTo(x + w * 0.8, base - h * 0.78); g.lineTo(x + w, base - h * 0.9); g.lineTo(x + w, base);
        } else { g.rect(x, base - h, w, h); }
        g.fill();
        if (kind >= 1) {
          for (let wy = base - h + 26; wy < base - 40; wy += 54) for (let wx = x + 14; wx < x + w - 24; wx += 36) {
            const r = H1(seed + wx * 13 + wy * 7);
            if (r < 0.14) { g.fillStyle = P.win; g.globalAlpha = 0.78; g.fillRect(wx, wy, 20, 30); }
            else if (r < 0.5) { g.fillStyle = "#000"; g.globalAlpha = 0.28; g.fillRect(wx, wy, 20, 30); }
            g.globalAlpha = 1;
          }
        }
        if (H1(seed + i * 5 + 3) < 0.2) {
          g.strokeStyle = col; g.lineWidth = 4; g.beginPath(); g.moveTo(x + w / 2, base - h); g.lineTo(x + w / 2, base - h - 70); g.stroke();
        }
        x += w + 4 + H1(seed + i * 5 + 4) * 10; i++;
      }
      // haze toward the horizon
      const hz = g.createLinearGradient(0, base - 220, 0, base);
      hz.addColorStop(0, "rgba(0,0,0,0)"); hz.addColorStop(1, hexA(P.fog, kind === 0 ? 0.32 : kind === 1 ? 0.18 : 0.05));
      g.globalCompositeOperation = "source-atop"; g.fillStyle = hz; g.fillRect(0, base - 240, PER, 260); g.globalCompositeOperation = "source-over";
    });
  }
  function forestLayer(P, mood, kind) {
    return cached(`forest:${mood}:${kind}`, PER, 1120, (g) => {
      const base = [1060, 1090, 1130][kind], col = [P.far, P.mid, P.near][kind];
      g.fillStyle = col;
      let x = -30, i = 0;
      while (x < PER) {
        const w = [80, 110, 150][kind] * (0.8 + H1(i * 3 + kind * 50) * 0.7), h = [330, 420, 560][kind] * (0.6 + H1(i * 3 + 1 + kind * 50) * 0.8);
        g.fillRect(x + w / 2 - 6, base - 50, 12, 50);
        for (let k = 0; k < 4; k++) {
          const ty = base - 40 - k * (h / 4.4), tw = w * (1 - k * 0.19);
          g.beginPath(); g.moveTo(x + w / 2 - tw / 2, ty); g.lineTo(x + w / 2, ty - h / 3.1); g.lineTo(x + w / 2 + tw / 2, ty); g.closePath(); g.fill();
        }
        x += w * 0.78; i++;
      }
      const hz = g.createLinearGradient(0, base - 300, 0, base);
      hz.addColorStop(0, "rgba(0,0,0,0)"); hz.addColorStop(1, hexA(P.fog, kind === 0 ? 0.45 : kind === 1 ? 0.25 : 0.08));
      g.globalCompositeOperation = "source-atop"; g.fillStyle = hz; g.fillRect(0, base - 320, PER, 340); g.globalCompositeOperation = "source-over";
    });
  }
  function hexA(hex, a) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }
  function tileLayer(ctx, layer, off) {
    const x = -mod(off, PER);
    ctx.drawImage(layer, x, 0); ctx.drawImage(layer, x + PER, 0); if (x + 2 * PER < W) ctx.drawImage(layer, x + 2 * PER, 0);
  }

  function groundCanvas(P, mood, type) {
    return cached(`ground:${type}:${mood}`, W, H - HORIZON + 20, (g) => {
      const h = H - HORIZON + 20;
      const gr = g.createLinearGradient(0, 0, 0, h);
      if (type === "forest") { gr.addColorStop(0, "#1c2b22"); gr.addColorStop(0.15, "#2a2a1f"); gr.addColorStop(1, "#0b0e0a"); }
      else { gr.addColorStop(0, P.ground[0]); gr.addColorStop(1, P.ground[1]); }
      g.fillStyle = gr; g.fillRect(0, 0, W, h);
      if (type === "city") {
        g.fillStyle = "rgba(255,255,255,.07)"; g.fillRect(0, 0, W, 70); // sidewalk
        g.fillStyle = "rgba(0,0,0,.45)"; g.fillRect(0, 68, W, 6); // curb shadow
        g.fillStyle = "rgba(0,0,0,.18)";
        for (let i = 0; i < 40; i++) g.fillRect(H1(i) * W, 80 + H1(i + 50) * (h - 100), 40 + H1(i + 9) * 120, 3 + H1(i + 30) * 6); // asphalt wear
      } else if (type === "forest") {
        g.fillStyle = "rgba(0,0,0,.25)";
        for (let i = 0; i < 60; i++) { g.beginPath(); g.ellipse(H1(i) * W, 40 + H1(i + 60) * (h - 60), 20 + H1(i + 9) * 60, 4 + H1(i + 3) * 8, 0, 0, TAU); g.fill(); }
      }
    });
  }

  function drawCar(g, x, y, seed, P, t) {
    g.save(); g.translate(x, y);
    g.fillStyle = "#0b1119"; g.strokeStyle = "rgba(255,255,255,.08)"; g.lineWidth = 3;
    g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -68); g.quadraticCurveTo(8, -86, 40, -88); g.lineTo(88, -92); g.lineTo(122, -150); g.lineTo(226, -150); g.lineTo(270, -92); g.lineTo(304, -86); g.quadraticCurveTo(320, -80, 320, -52); g.lineTo(320, 0); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = "rgba(120,160,200,.16)"; g.beginPath(); g.moveTo(132, -98); g.lineTo(150, -140); g.lineTo(216, -140); g.lineTo(246, -98); g.closePath(); g.fill();
    g.fillStyle = "#05080c";[[64, 0], [256, 0]].forEach(([wx]) => { g.beginPath(); g.arc(wx, 0, 36, 0, TAU); g.fill(); g.strokeStyle = "rgba(255,255,255,.1)"; g.stroke(); });
    if (H1(seed) < 0.5) { // dead headlights flicker
      const a = 0.18 + 0.2 * (H1(Math.floor(t * 9) + seed) > 0.6 ? 1 : 0);
      const lg = g.createRadialGradient(318, -50, 4, 318, -50, 150); lg.addColorStop(0, hexA(P.lamp, a)); lg.addColorStop(1, hexA(P.lamp, 0));
      g.fillStyle = lg; g.fillRect(250, -200, 300, 300);
    }
    g.restore();
  }
  function drawLamp(g, x, y, seed, P, t) {
    g.save(); g.translate(x, y);
    g.strokeStyle = "#0a1018"; g.lineWidth = 14; g.lineCap = "round";
    g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -520); g.quadraticCurveTo(0, -560, 50, -560); g.lineTo(90, -560); g.stroke();
    const flick = seed % 3 === 0 ? (H1(Math.floor(t * 14) + seed) > 0.18 ? 1 : 0.15) : 0.85 + 0.1 * Math.sin(t * 3 + seed);
    const lg = g.createRadialGradient(90, -548, 4, 90, -548, 360);
    lg.addColorStop(0, hexA(P.lamp, 0.55 * flick)); lg.addColorStop(1, hexA(P.lamp, 0));
    g.fillStyle = lg; g.fillRect(-300, -900, 800, 1000);
    g.fillStyle = hexA(P.lamp, 0.4 + 0.6 * flick); g.beginPath(); g.ellipse(90, -552, 26, 10, 0, 0, TAU); g.fill();
    g.restore();
  }
  function drawCrate(g, x, y, seed) {
    g.save(); g.translate(x, y); g.fillStyle = "#0a1017"; g.strokeStyle = "rgba(255,255,255,.07)"; g.lineWidth = 3;
    for (let i = 0; i < 3; i++) { const w = 90 + H1(seed + i) * 60, h = 70 + H1(seed + i + 4) * 50; g.beginPath(); g.rect(i * 80 - 20, -h, w, h); g.fill(); g.stroke(); }
    g.restore();
  }
  function drawBarricade(g, x, y) {
    g.save(); g.translate(x, y); g.fillStyle = "#0b1118"; g.fillRect(0, -110, 260, 22); g.fillRect(0, -70, 260, 22); g.fillRect(20, -120, 20, 120); g.fillRect(220, -120, 20, 120);
    g.fillStyle = "rgba(255,80,60,.55)"; for (let i = 0; i < 4; i++) g.fillRect(14 + i * 62, -109, 26, 20);
    g.restore();
  }

  function drawCityWorld(ctx, sc, st, t, P) {
    const mood = sc.bg.mood;
    ctx.drawImage(skyCanvas(P, mood), 0, 0);
    tileLayer(ctx, cityLayer(P, mood, 0), st.scroll * 0.1);
    tileLayer(ctx, cityLayer(P, mood, 1), st.scroll * 0.25);
    tileLayer(ctx, cityLayer(P, mood, 2), st.scroll * 0.5);
    ctx.drawImage(groundCanvas(P, mood, "city"), 0, HORIZON - 20);
    // lane markings + props scroll at 1.0
    ctx.fillStyle = P.lane;
    for (let k = Math.floor(st.scroll / 240) - 1; k < Math.floor(st.scroll / 240) + 6; k++) ctx.fillRect(k * 240 - st.scroll, 1640, 130, 12);
    const SL = 560;
    for (let k = Math.floor(st.scroll / SL) - 1; k < Math.floor(st.scroll / SL) + 4; k++) {
      const x = k * SL - st.scroll + 40, r = H1(k * 13 + (sc.seed & 0xffff));
      if (r < 0.2) drawCar(ctx, x, 1190, k, P, t);
      else if (r < 0.5) drawLamp(ctx, x + 100, 1130, k, P, t);
      else if (r < 0.62) drawCrate(ctx, x, 1170, k);
      else if (r < 0.7) drawBarricade(ctx, x, 1180);
    }
  }
  function drawForestWorld(ctx, sc, st, t, P) {
    const mood = sc.bg.mood;
    ctx.drawImage(skyCanvas(P, mood), 0, 0);
    tileLayer(ctx, forestLayer(P, mood, 0), st.scroll * 0.1);
    tileLayer(ctx, forestLayer(P, mood, 1), st.scroll * 0.3);
    ctx.drawImage(groundCanvas(P, mood, "forest"), 0, HORIZON - 20);
    tileLayer(ctx, forestLayer(P, mood, 2), st.scroll * 0.7);
    // path edge stones + fireflies/embers
    ctx.fillStyle = "rgba(0,0,0,.35)";
    for (let k = Math.floor(st.scroll / 200) - 1; k < Math.floor(st.scroll / 200) + 7; k++) { ctx.beginPath(); ctx.ellipse(k * 200 - st.scroll, 1150 + H1(k) * 30, 40 + H1(k + 3) * 30, 12, 0, 0, TAU); ctx.fill(); }
  }
  function drawRoomWorld(ctx, sc, st, t, P, bunker) {
    const mood = sc.bg.mood;
    const stat = cached(`room:${bunker ? "b" : "r"}:${mood}`, W, H, (g) => {
      const wall = g.createLinearGradient(0, 0, 0, 1180);
      if (bunker) { wall.addColorStop(0, "#2b3238"); wall.addColorStop(1, "#444d54"); }
      else if (mood === "day") { wall.addColorStop(0, "#b9a98f"); wall.addColorStop(1, "#8d7d66"); }
      else if (mood === "red") { wall.addColorStop(0, "#2a1414"); wall.addColorStop(1, "#4a2420"); }
      else { wall.addColorStop(0, "#1b2230"); wall.addColorStop(1, "#2c3342"); }
      g.fillStyle = wall; g.fillRect(0, 0, W, 1180);
      if (bunker) {
        g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = 4;
        for (let x = 0; x <= W; x += 270) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 1180); g.stroke(); }
        for (let y = 200; y < 1180; y += 330) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
        g.strokeStyle = "#1a1f23"; g.lineWidth = 26;
        [300, 360].forEach((y) => { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); });
        g.fillStyle = "#6a1f1f"; [180, 520, 860].forEach((x) => { g.beginPath(); g.arc(x, 330, 20, 0, TAU); g.fill(); });
        g.fillStyle = "#20272c"; g.fillRect(760, 560, 230, 600); g.strokeStyle = "#0d1114"; g.lineWidth = 8; g.strokeRect(760, 560, 230, 600);
        g.beginPath(); g.arc(875, 860, 38, 0, TAU); g.stroke();
      } else {
        g.fillStyle = "rgba(255,255,255,.035)"; for (let x = 0; x < W; x += 90) g.fillRect(x, 0, 44, 1180);
        // window
        g.fillStyle = "#0a0f16"; g.fillRect(596, 300, 360, 520);
        const sk = g.createLinearGradient(0, 316, 0, 804); sk.addColorStop(0, P.sky[0]); sk.addColorStop(1, P.sky[1]);
        g.fillStyle = sk; g.fillRect(612, 316, 328, 488);
        g.fillStyle = "#050a10";[[620, 640, 60, 164], [690, 590, 80, 214], [790, 660, 70, 144], [870, 610, 64, 194]].forEach(([x, y, w, h]) => g.fillRect(x, y, w, h));
        g.fillStyle = "#0a0f16"; g.fillRect(768, 300, 16, 520); g.fillRect(596, 548, 360, 16);
        g.fillStyle = "rgba(0,0,0,.35)"; g.fillRect(560, 280, 40, 560); g.fillRect(952, 280, 40, 560);
        // shelf
        g.fillStyle = "#121722"; g.fillRect(60, 420, 300, 740);
        g.fillStyle = "#1c2330"; for (let y = 420; y < 1160; y += 148) g.fillRect(60, y, 300, 14);
        for (let r = 0; r < 5; r++) for (let b = 0; b < 8; b++) { g.fillStyle = ["#3b2a2f", "#2a3b4a", "#4a3d2a", "#2f4a3a"][(r * 3 + b) % 4]; g.fillRect(76 + b * 34, 432 + r * 148 + 20, 26, 110 - (b % 3) * 14); }
      }
      // floor
      const fl = g.createLinearGradient(0, 1160, 0, H); fl.addColorStop(0, bunker ? "#2a3035" : "#2b231e"); fl.addColorStop(1, "#0b0a09");
      g.fillStyle = fl; g.fillRect(0, 1160, W, H - 1160);
      g.fillStyle = "rgba(0,0,0,.35)"; g.fillRect(0, 1150, W, 14);
      g.strokeStyle = "rgba(0,0,0,.4)"; g.lineWidth = 3;
      for (let i = 0; i < 12; i++) { const y = 1170 + i * i * 5 + i * 12; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
    });
    ctx.drawImage(stat, 0, 0);
    // dynamic light
    if (bunker) {
      const pulse = 0.5 + 0.5 * Math.sin(t * 4.2);
      const g2 = ctx.createRadialGradient(150, 320, 10, 150, 320, 700);
      g2.addColorStop(0, `rgba(255,40,30,${0.1 + 0.32 * pulse})`); g2.addColorStop(1, "rgba(255,40,30,0)");
      ctx.fillStyle = g2; ctx.fillRect(0, 0, W, 1300);
    } else {
      const ang = Math.sin(t * 1.3) * 0.05, fl = H1(Math.floor(t * 11)) > 0.9 ? 0.45 : 1;
      ctx.save(); ctx.translate(250, 0); ctx.rotate(ang);
      ctx.strokeStyle = "#0b0f15"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, 300); ctx.stroke();
      const lg = ctx.createRadialGradient(0, 330, 6, 0, 330, 520);
      lg.addColorStop(0, hexA(P.lamp, 0.5 * fl)); lg.addColorStop(1, hexA(P.lamp, 0));
      ctx.fillStyle = lg; ctx.fillRect(-520, 0, 1040, 1100);
      ctx.fillStyle = hexA(P.lamp, fl); ctx.beginPath(); ctx.moveTo(-34, 330); ctx.lineTo(34, 330); ctx.lineTo(22, 296); ctx.lineTo(-22, 296); ctx.fill();
      ctx.restore();
    }
  }

  /* ---------- extra locations: door / elevator / stairs / hallway / alley / custom image ---------- */
  const WALLS = { night: ["#161c26", "#252d3a"], dusk: ["#2a2230", "#3d3040"], day: ["#8b8272", "#6e6658"], red: ["#2a1214", "#43201f"], fog: ["#4a525a", "#68727a"] };
  const wallCols = (m) => WALLS[m] || WALLS.night;
  function tint(ctx, mood) {
    const c = mood === "red" ? "rgba(130,12,12,.28)" : mood === "day" ? "rgba(255,245,225,.10)" : mood === "fog" ? "rgba(190,205,210,.14)" : mood === "dusk" ? "rgba(255,140,90,.08)" : null;
    if (c) { ctx.fillStyle = c; ctx.fillRect(0, 0, W, H); }
  }
  function floorFill(g, color) {
    const fl = g.createLinearGradient(0, 1160, 0, H); fl.addColorStop(0, color); fl.addColorStop(1, "#070606");
    g.fillStyle = fl; g.fillRect(0, 1160, W, H - 1160);
    g.fillStyle = "rgba(0,0,0,.4)"; g.fillRect(0, 1150, W, 14);
    g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = 3;
    for (let i = 0; i < 12; i++) { const y = 1172 + i * i * 5 + i * 12; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
  }
  function wallFill(g, mood, stripes) {
    const wc = wallCols(mood), gr = g.createLinearGradient(0, 0, 0, 1180);
    gr.addColorStop(0, wc[0]); gr.addColorStop(1, wc[1]); g.fillStyle = gr; g.fillRect(0, 0, W, 1180);
    if (stripes) { g.fillStyle = "rgba(255,255,255,.03)"; for (let x = 0; x < W; x += 80) g.fillRect(x, 0, 38, 1180); }
  }
  function glow(ctx, x, y, r, color, a) {
    const g = ctx.createRadialGradient(x, y, 4, x, y, r); g.addColorStop(0, hexA(color, a)); g.addColorStop(1, hexA(color, 0));
    ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  function drawDoorWorld(ctx, sc, st, t, P) {
    const open = sc.bg.variant === "open", mood = sc.bg.mood;
    ctx.drawImage(cached(`door:${mood}:${open ? 1 : 0}`, W, H, (g) => {
      wallFill(g, mood, true); floorFill(g, "#241d19");
      g.fillStyle = "#0c1016"; g.fillRect(280, 306, 520, 862); // frame
      if (!open) {
        const lg = g.createLinearGradient(300, 0, 780, 0); lg.addColorStop(0, "#43342b"); lg.addColorStop(1, "#2c221c");
        g.fillStyle = lg; g.fillRect(300, 326, 480, 834);
        g.strokeStyle = "rgba(0,0,0,.5)"; g.lineWidth = 7;
        [[340, 372, 170, 290], [570, 372, 170, 290], [340, 740, 170, 360], [570, 740, 170, 360]].forEach(([x, y, w, h]) => g.strokeRect(x, y, w, h));
        g.strokeStyle = "rgba(255,255,255,.06)"; g.lineWidth = 2;
        [[344, 376, 162, 282], [574, 376, 162, 282]].forEach(([x, y, w, h]) => g.strokeRect(x, y, w, h));
        g.fillStyle = "#b8a56a"; g.fillRect(500, 410, 80, 44); g.fillStyle = "#1a1408"; g.font = "bold 30px Nunito, sans-serif"; g.textAlign = "center"; g.fillText("7B", 540, 442);
        g.fillStyle = "#050505"; g.beginPath(); g.arc(540, 520, 13, 0, TAU); g.fill(); g.strokeStyle = "#8c8c8c"; g.lineWidth = 4; g.stroke();
        g.fillStyle = "#9aa3ab"; g.fillRect(704, 690, 46, 70); g.fillStyle = "#cfd6db"; g.fillRect(714, 700, 26, 30); // deadbolt
        g.fillStyle = "#b9a15c"; g.beginPath(); g.arc(727, 820, 24, 0, TAU); g.fill(); g.fillRect(705, 812, 62, 16); // handle
        g.strokeStyle = "#a9b2ba"; g.lineWidth = 5; g.beginPath(); g.moveTo(322, 640); g.quadraticCurveTo(380, 690, 440, 640); g.stroke(); // chain
      } else {
        const dg = g.createLinearGradient(300, 330, 780, 1160); dg.addColorStop(0, "#04070a"); dg.addColorStop(1, "#0d141b");
        g.fillStyle = dg; g.fillRect(300, 326, 480, 834);
        const lg = g.createLinearGradient(300, 0, 780, 0); lg.addColorStop(0, "#43342b"); lg.addColorStop(1, "#2c221c");
        g.fillStyle = lg; g.beginPath(); g.moveTo(300, 326); g.lineTo(470, 392); g.lineTo(470, 1096); g.lineTo(300, 1160); g.closePath(); g.fill();
        g.strokeStyle = "rgba(0,0,0,.5)"; g.lineWidth = 5; g.strokeRect(330, 480, 110, 230);
        g.fillStyle = "rgba(160,190,220,.10)"; g.fillRect(470, 392, 14, 704); // light spill edge
        g.fillStyle = "#b9a15c"; g.beginPath(); g.arc(452, 800, 14, 0, TAU); g.fill();
      }
      g.fillStyle = "#1b1714"; g.fillRect(330, 1166, 420, 34); // mat
    }), 0, 0);
    const f = 0.7 + 0.3 * Math.sin(t * 3.1) * (H1(Math.floor(t * 9)) > 0.1 ? 1 : 0.2);
    [150, 930].forEach((x) => { glow(ctx, x, 560, 330, P.lamp, 0.34 * f); ctx.fillStyle = hexA(P.lamp, 0.9 * f); ctx.fillRect(x - 16, 540, 32, 46); });
    if (open) { const a = 0.05 + 0.04 * Math.sin(t * 2); glow(ctx, 620, 820, 320, "#8fb4e0", a); }
    tint(ctx, mood);
  }

  function drawElevatorWorld(ctx, sc, st, t, P) {
    const open = sc.bg.variant === "open", mood = sc.bg.mood;
    ctx.drawImage(cached(`elev:${mood}:${open ? 1 : 0}`, W, H, (g) => {
      const wc = wallCols(mood), gr = g.createLinearGradient(0, 0, 0, 1180); gr.addColorStop(0, "#252c32"); gr.addColorStop(1, "#38424a");
      g.fillStyle = gr; g.fillRect(0, 0, W, 1180);
      g.strokeStyle = "rgba(0,0,0,.4)"; g.lineWidth = 4; for (let x = 0; x <= W; x += 180) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 1180); g.stroke(); }
      // tiled floor
      const fl = g.createLinearGradient(0, 1160, 0, H); fl.addColorStop(0, "#20262b"); fl.addColorStop(1, "#08090a"); g.fillStyle = fl; g.fillRect(0, 1160, W, H - 1160);
      g.strokeStyle = "rgba(255,255,255,.05)"; g.lineWidth = 3;
      for (let i = 0; i < 9; i++) { const y = 1170 + i * i * 7 + i * 10; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
      g.fillStyle = "rgba(0,0,0,.4)"; g.fillRect(0, 1150, W, 14);
      g.fillStyle = "#0f1317"; g.fillRect(262, 372, 556, 800); // frame
      if (!open) {
        [[278, 534], [546, 802]].forEach(([a, b]) => {
          const mg = g.createLinearGradient(a, 0, b, 0); mg.addColorStop(0, "#7d8892"); mg.addColorStop(0.5, "#58626c"); mg.addColorStop(1, "#7a858f");
          g.fillStyle = mg; g.fillRect(a, 388, b - a - 4, 770);
          g.strokeStyle = "rgba(255,255,255,.05)"; g.lineWidth = 2; for (let y = 400; y < 1150; y += 9) { g.beginPath(); g.moveTo(a, y); g.lineTo(b - 4, y); g.stroke(); }
        });
        g.fillStyle = "#06090c"; g.fillRect(536, 388, 8, 770);
      } else {
        const ig = g.createLinearGradient(0, 388, 0, 1158); ig.addColorStop(0, "#f6e9c0"); ig.addColorStop(1, "#6b5a3c");
        g.fillStyle = ig; g.fillRect(278, 388, 524, 770);
        g.strokeStyle = "rgba(0,0,0,.18)"; g.lineWidth = 3; for (let x = 340; x < 780; x += 110) { g.beginPath(); g.moveTo(x, 388); g.lineTo(x, 1158); g.stroke(); }
        g.strokeStyle = "#a7b0b8"; g.lineWidth = 10; g.beginPath(); g.moveTo(300, 820); g.lineTo(780, 820); g.stroke();
        [[278, 338], [742, 802]].forEach(([a, b]) => { const mg = g.createLinearGradient(a, 0, b, 0); mg.addColorStop(0, "#7d8892"); mg.addColorStop(1, "#4d5760"); g.fillStyle = mg; g.fillRect(a, 388, b - a, 770); });
      }
      g.fillStyle = "#050709"; g.fillRect(380, 282, 320, 76); g.strokeStyle = "#2a323a"; g.lineWidth = 5; g.strokeRect(380, 282, 320, 76);
      g.fillStyle = "#11171c"; g.fillRect(868, 640, 84, 170); g.strokeStyle = "#2a323a"; g.strokeRect(868, 640, 84, 170);
    }), 0, 0);
    // indicator + call buttons
    const on = H1(Math.floor(t * 10)) > 0.08;
    ctx.font = "bold 58px Nunito, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillStyle = on ? (open ? "#4dff9a" : "#ff3b3b") : "#401010"; ctx.fillText((open ? "▼ " : "▲ ") + "7", 540, 322);
    [700, 760].forEach((y, i) => { ctx.fillStyle = i === 0 && Math.sin(t * 4) > 0 ? "#ffe9a0" : "#59616a"; ctx.beginPath(); ctx.arc(910, y, 15, 0, TAU); ctx.fill(); });
    if (open) {
      const fl = 0.85 + 0.15 * Math.sin(t * 7) * (H1(Math.floor(t * 8)) > 0.2 ? 1 : 0.3);
      glow(ctx, 540, 1180, 520, "#ffe6a8", 0.25 * fl);
      ctx.fillStyle = `rgba(255,236,170,${0.10 * fl})`; ctx.beginPath(); ctx.moveTo(278, 1158); ctx.lineTo(802, 1158); ctx.lineTo(1040, H); ctx.lineTo(40, H); ctx.closePath(); ctx.fill();
    }
    glow(ctx, 540, 100, 600, "#bcd8ff", 0.10 + 0.04 * Math.sin(t * 5));
    tint(ctx, sc.bg.mood);
  }

  function drawStairsWorld(ctx, sc, st, t, P) {
    const mood = sc.bg.mood;
    ctx.drawImage(cached(`stairs:${mood}`, W, H, (g) => {
      wallFill(g, mood, false);
      g.fillStyle = "rgba(0,0,0,.25)"; for (let y = 140; y < 1160; y += 220) g.fillRect(0, y, W, 6);
      g.fillStyle = "rgba(255,255,255,.06)"; g.font = "bold 360px Nunito, sans-serif"; g.textAlign = "center"; g.fillText("7", 260, 600);
      g.fillStyle = "#06090d"; g.fillRect(780, 180, 170, 330); g.fillStyle = "#223345"; g.fillRect(790, 190, 150, 310); // window
      g.fillStyle = "#06090d"; g.fillRect(860, 190, 10, 310); g.fillRect(790, 340, 150, 10);
      floorFill(g, "#22262b");
      // flight A: rising to the right
      const N = 11, dx = 58, dy = 52, x0 = -20, y0 = 1170;
      g.fillStyle = "#171c22"; g.beginPath(); g.moveTo(x0, y0);
      for (let i = 0; i < N; i++) { g.lineTo(x0 + i * dx, y0 - (i + 1) * dy); g.lineTo(x0 + (i + 1) * dx, y0 - (i + 1) * dy); }
      g.lineTo(x0 + N * dx, y0); g.closePath(); g.fill();
      g.strokeStyle = "rgba(255,255,255,.13)"; g.lineWidth = 4;
      for (let i = 0; i < N; i++) { g.beginPath(); g.moveTo(x0 + i * dx, y0 - (i + 1) * dy); g.lineTo(x0 + (i + 1) * dx, y0 - (i + 1) * dy); g.stroke(); }
      // landing + rail
      g.fillStyle = "#171c22"; g.fillRect(x0 + N * dx, y0 - N * dy, W, N * dy + 40);
      g.strokeStyle = "#0a0d11"; g.lineWidth = 9;
      g.beginPath(); g.moveTo(x0, y0 - 200); g.lineTo(x0 + N * dx, y0 - N * dy - 200); g.lineTo(W, y0 - N * dy - 200); g.stroke();
      g.lineWidth = 6; for (let i = 0; i <= N; i += 2) { g.beginPath(); g.moveTo(x0 + i * dx, y0 - i * dy - 20); g.lineTo(x0 + i * dx, y0 - i * dy - 200); g.stroke(); }
      // exit sign
      g.fillStyle = "#06150c"; g.fillRect(820, 560, 150, 56); g.strokeStyle = "#1c3a28"; g.lineWidth = 4; g.strokeRect(820, 560, 150, 56);
    }), 0, 0);
    ctx.fillStyle = "#4dff9a"; ctx.font = "bold 36px Nunito, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.globalAlpha = 0.75 + 0.25 * Math.sin(t * 3); ctx.fillText("EXIT", 895, 590); ctx.globalAlpha = 1;
    const f = H1(Math.floor(t * 12)) > 0.12 ? 1 : 0.25;
    glow(ctx, 620, 40, 700, P.lamp, 0.32 * f); glow(ctx, 865, 340, 260, "#7fb0ff", 0.18);
    ctx.fillStyle = hexA(P.lamp, 0.85 * f); ctx.fillRect(560, 0, 120, 14);
    ctx.fillStyle = "rgba(255,255,255,.18)";
    for (let i = 0; i < 18; i++) { const px = mod(H1(i) * W + t * (6 + i % 4), W), py = mod(H1(i + 40) * 1100 - t * (10 + i % 5), 1100); ctx.fillRect(px, py, 3, 3); }
    tint(ctx, mood);
  }

  function drawHallwayWorld(ctx, sc, st, t, P) {
    const mood = sc.bg.mood;
    ctx.drawImage(cached(`hall:${mood}`, W, H, (g) => {
      wallFill(g, mood, true);
      g.fillStyle = "rgba(0,0,0,.28)"; g.fillRect(0, 780, W, 380); g.fillStyle = "rgba(255,255,255,.07)"; g.fillRect(0, 776, W, 6);
      g.fillStyle = "rgba(0,0,0,.45)"; g.fillRect(0, 0, W, 90);
      floorFill(g, "#2a1d1e");
      g.fillStyle = "rgba(120,30,34,.35)"; g.fillRect(180, 1176, W - 360, H - 1176); // runner
    }), 0, 0);
    const SL = 620;
    for (let k = Math.floor(st.scroll / SL) - 1; k < Math.floor(st.scroll / SL) + 3; k++) {
      const x = k * SL - st.scroll + 90, n = 100 + Math.floor(H1(k * 5 + 3) * 90);
      ctx.fillStyle = "#0c1015"; ctx.fillRect(x - 12, 506, 284, 660);
      ctx.fillStyle = "#33271f"; ctx.fillRect(x, 520, 260, 640);
      ctx.strokeStyle = "rgba(0,0,0,.45)"; ctx.lineWidth = 5; ctx.strokeRect(x + 30, 560, 200, 240); ctx.strokeRect(x + 30, 840, 200, 270);
      ctx.fillStyle = "#b8a56a"; ctx.fillRect(x + 100, 470, 60, 32); ctx.fillStyle = "#1a1408"; ctx.font = "bold 22px Nunito, sans-serif"; ctx.textAlign = "center"; ctx.fillText(String(n), x + 130, 494);
      const sx = x + 440, f = H1(Math.floor(t * 11) + k) > 0.1 ? 1 : 0.2;
      glow(ctx, sx, 560, 300, P.lamp, 0.3 * f); ctx.fillStyle = hexA(P.lamp, 0.9 * f); ctx.fillRect(sx - 14, 540, 28, 44);
      if (H1(k * 9 + 1) > 0.6) { ctx.fillStyle = "#06150c"; ctx.fillRect(x + 60, 380, 140, 50); ctx.fillStyle = "#4dff9a"; ctx.font = "bold 30px Nunito, sans-serif"; ctx.fillText("EXIT", x + 130, 414); }
    }
    glow(ctx, 540, 60, 700, P.lamp, 0.16);
    tint(ctx, mood);
  }

  function drawAlleyWorld(ctx, sc, st, t, P) {
    const mood = sc.bg.mood;
    ctx.drawImage(cached(`alley:${mood}`, W, H, (g) => {
      const sk = g.createLinearGradient(0, 0, 0, 500); sk.addColorStop(0, P.sky[0]); sk.addColorStop(1, P.sky[1]); g.fillStyle = sk; g.fillRect(0, 0, W, 520);
      g.fillStyle = "#0b1017"; g.fillRect(300, 220, 480, 940);
      g.fillStyle = "#ffc46b"; g.globalAlpha = 0.5; g.fillRect(380, 330, 50, 70); g.fillRect(600, 460, 50, 70); g.globalAlpha = 1;
      const wallBricks = (x0, x1) => {
        const gr = g.createLinearGradient(x0, 0, x1, 0); gr.addColorStop(0, "#1a1210"); gr.addColorStop(1, "#271b17");
        g.fillStyle = gr; g.fillRect(x0, 0, x1 - x0, 1170);
        g.strokeStyle = "rgba(0,0,0,.4)"; g.lineWidth = 2;
        for (let r = 0, y = 0; y < 1170; r++, y += 30) { g.beginPath(); g.moveTo(x0, y); g.lineTo(x1, y); g.stroke(); for (let x = x0 + (r % 2) * 30; x < x1; x += 60) { g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + 30); g.stroke(); } }
      };
      wallBricks(0, 300); wallBricks(780, W);
      g.strokeStyle = "#07090c"; g.lineWidth = 8; // fire escape + pipes
      for (let i = 0; i < 5; i++) { g.beginPath(); g.moveTo(800, 300 + i * 160); g.lineTo(1040, 300 + i * 160 + 70); g.lineTo(800, 300 + (i + 1) * 160); g.stroke(); }
      g.lineWidth = 12; [[110, 0, 110, 1170], [950, 0, 950, 1170]].forEach(([a, b, c, d]) => { g.beginPath(); g.moveTo(a, b); g.lineTo(c, d); g.stroke(); });
      const fl = g.createLinearGradient(0, 1160, 0, H); fl.addColorStop(0, "#1a1f26"); fl.addColorStop(1, "#06080a"); g.fillStyle = fl; g.fillRect(0, 1160, W, H - 1160);
      g.fillStyle = "rgba(160,190,220,.10)"; g.beginPath(); g.ellipse(620, 1330, 260, 36, 0, 0, TAU); g.fill();
      g.fillStyle = "#0e2018"; g.fillRect(40, 1000, 250, 170); g.fillStyle = "#16301f"; g.fillRect(30, 980, 270, 36); // dumpster
      g.fillStyle = "#1b1410"; g.fillRect(850, 1060, 110, 110); g.fillRect(900, 990, 100, 80);
    }), 0, 0);
    const f = H1(Math.floor(t * 13)) > 0.15 ? 1 : 0.2;
    ctx.strokeStyle = "#0a0d11"; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(540, 0); ctx.lineTo(540, 190); ctx.stroke();
    glow(ctx, 540, 210, 520, P.lamp, 0.42 * f); ctx.fillStyle = hexA(P.lamp, f); ctx.beginPath(); ctx.arc(540, 206, 16, 0, TAU); ctx.fill();
    for (let i = 0; i < 6; i++) { const p = mod(t * 0.35 + i / 6, 1); ctx.fillStyle = `rgba(210,220,230,${0.14 * (1 - p)})`; ctx.beginPath(); ctx.ellipse(800 + Math.sin(t + i) * 24, 1170 - p * 420, 40 + p * 70, 30 + p * 40, 0, 0, TAU); ctx.fill(); }
    tint(ctx, mood);
  }

  function drawCustomWorld(ctx, sc, st, t) {
    const img = SV.bgImages[sc.bg.name];
    if (!img || !img.width) { drawRoomWorld(ctx, sc, st, t, MOODS.night, false); return; }
    const k = Math.max(W / img.width, H / img.height) * 1.04, w = img.width * k, h = img.height * k;
    ctx.drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
    ctx.fillStyle = "rgba(0,0,0,.28)"; ctx.fillRect(0, 1180, W, H - 1180);
    ctx.fillStyle = "rgba(0,0,0,.12)"; ctx.fillRect(0, 0, W, H);
  }

  function drawWorld(ctx, sc, st, t) {
    const ty = sc.bg.type;
    const P = ty === "custom" ? MOODS.night : moodOf(sc.bg);
    if (ty === "room") drawRoomWorld(ctx, sc, st, t, P, false);
    else if (ty === "bunker") drawRoomWorld(ctx, sc, st, t, P, true);
    else if (ty === "forest") drawForestWorld(ctx, sc, st, t, P);
    else if (ty === "door") drawDoorWorld(ctx, sc, st, t, P);
    else if (ty === "elevator") drawElevatorWorld(ctx, sc, st, t, P);
    else if (ty === "stairs") drawStairsWorld(ctx, sc, st, t, P);
    else if (ty === "hallway") drawHallwayWorld(ctx, sc, st, t, P);
    else if (ty === "alley") drawAlleyWorld(ctx, sc, st, t, P);
    else if (ty === "custom") drawCustomWorld(ctx, sc, st, t);
    else drawCityWorld(ctx, sc, st, t, P);
    return P;
  }

  /* ---------- weather / atmosphere ---------- */
  function drawFog(ctx, t, P, amt, seed) {
    for (let i = 0; i < 7; i++) {
      const cx = mod(H1(i + seed) * (W + 900) + t * (14 + (i % 3) * 9), W + 900) - 450;
      const cy = 760 + H1(i + 9 + seed) * 560, r = 420 + H1(i + 19) * 260;
      const g = ctx.createRadialGradient(cx, cy, 20, cx, cy, r);
      g.addColorStop(0, hexA(P.fog, 0.5 * amt)); g.addColorStop(1, hexA(P.fog, 0));
      ctx.fillStyle = g; ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    }
  }
  function drawRain(ctx, t, amt, heavy) {
    const n = Math.floor((heavy ? 320 : 190) * amt);
    ctx.strokeStyle = "rgba(200,222,255,.34)"; ctx.lineWidth = heavy ? 3.5 : 2.5; ctx.lineCap = "round";
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const sp = 1500 + H1(i * 3 + 2) * 1000;
      const y = mod(H1(i * 3) * (H + 200) + t * sp, H + 200) - 100;
      const x = mod(H1(i * 3 + 1) * (W + 500) - t * sp * 0.28, W + 500) - 250;
      ctx.moveTo(x, y); ctx.lineTo(x - 16, y + 56);
    }
    ctx.stroke();
  }
  function lightningAmt(t, seed) {
    const slot = Math.floor(t / 3.6);
    let a = 0;
    for (let s = slot - 1; s <= slot; s++) {
      if (H1(s * 7 + (seed & 0xff)) < 0.6) {
        const dt = t - (s * 3.6 + H1(s + 3) * 2.2);
        if (dt >= 0 && dt < 1.2) a = Math.max(a, Math.exp(-dt * 6.5) * (0.75 + 0.25 * Math.sin(dt * 55)));
      }
    }
    return a;
  }

  /* ---------- stickman rig ---------- */
  const POSE_SPEED = { walk: 190, run: 560 };
  function pt(ax, ay, deg, len) { const r = rad(deg); return [ax + Math.sin(r) * len, ay + Math.cos(r) * len]; }

  function drawFigure(ctx, o) {
    const { t, pose } = o, tt = t + o.phase;
    let hipY = -210, lean = 0, bob = 0, rot = 0, lift = 0;
    let lTh = 3, lKn = 0, rTh = -3, rKn = 0, lUp = 6, lFl = 8, rUp = -6, rFl = 6, tilt = 0;
    const talk = o.talk;
    const zombie = o.kind === "zombie" || o.kind === "silhouette";
    switch (pose) {
      case "walk": { const c = (tt * TAU) / 0.95, s = Math.sin(c); lTh = 30 * s; rTh = -30 * s; lKn = -38 * Math.max(0, Math.cos(c)); rKn = -38 * Math.max(0, -Math.cos(c)); lUp = -26 * s; rUp = 26 * s; lFl = lUp + 18; rFl = rUp + 18; bob = -Math.abs(s) * 9; lean = 4; break; }
      case "run": { const c = (tt * TAU) / 0.56, s = Math.sin(c); lTh = 58 * s; rTh = -58 * s; lKn = -80 * Math.max(0, Math.cos(c)); rKn = -80 * Math.max(0, -Math.cos(c)); lUp = -52 * s; rUp = 52 * s; lFl = lUp + 90; rFl = rUp + 90; bob = -Math.abs(Math.sin(c)) * 18; lean = 15; break; }
      case "scared": { const sh = Math.sin(tt * 47) * 3; lTh = 14; lKn = -18; rTh = -10; rKn = -14; lUp = 95 + sh; lFl = 205 - sh; rUp = 110 - sh; rFl = 195 + sh; hipY = -198; lean = -6; bob = sh; tilt = -6 + sh; break; }
      case "crouch": { hipY = -150; lTh = 66; lKn = -66; rTh = 50; rKn = -50; lean = 22; lUp = 40; lFl = 75; rUp = 20; rFl = 60; break; }
      case "sit": { hipY = -104; lTh = 90; lKn = -90; rTh = 84; rKn = -84; lUp = 20; lFl = 70; rUp = 10; rFl = 60; break; }
      case "point": { rUp = 88; rFl = 90; lUp = 4; lFl = 6; lean = 3; break; }
      case "hands_up": case "handsup": { lUp = 160 + Math.sin(tt * 5) * 3; lFl = 172; rUp = 150 - Math.sin(tt * 5) * 3; rFl = 170; lTh = 6; rTh = -6; break; }
      case "fall": case "collapse": case "dead": { const u = easeOut(clamp((t - o.poseT) / 0.7)); rot = -u * (Math.PI / 2); lift = u * 18; lUp = 40 * u; lFl = 70 * u; rUp = -30 * u; rFl = -50 * u; lTh = 20 * u; rTh = -20 * u; break; }
      default: { bob = Math.sin(tt * 2.1) * 2.6; lUp = 6 + Math.sin(tt * 1.7) * 3; rUp = -6 - Math.sin(tt * 1.7) * 3; }
    }
    if (zombie) { // shambling, arms forward
      const c = (tt * TAU) / 1.7, s = Math.sin(c);
      lTh = 20 * s; rTh = -20 * s; lKn = -14 * Math.max(0, Math.cos(c)); rKn = -14 * Math.max(0, -Math.cos(c));
      lUp = 84 + Math.sin(tt * 1.9) * 6; lFl = 92; rUp = 94 + Math.cos(tt * 1.5) * 6; rFl = 100;
      lean = 13 + Math.sin(tt * 0.9) * 3; tilt = Math.sin(tt * 1.3) * 12; bob = -Math.abs(s) * 5;
    } else if (talk > 0.01 && (pose === "idle" || pose === "walk")) {
      const g = Math.sin(tt * 3.1) * 0.5 + Math.sin(tt * 4.7) * 0.5;
      rUp = lerp(rUp, 50 + 28 * g, talk); rFl = lerp(rFl, rUp + 55 + 25 * Math.sin(tt * 4.3), talk);
      tilt = 4 * Math.sin(tt * 3.7) * talk; bob += Math.sin(tt * 7) * 1.4 * talk;
    }
    const hip = [0, hipY + bob], TL = 172;
    const lr = rad(lean);
    const neck = [hip[0] + Math.sin(lr) * TL, hip[1] - Math.cos(lr) * TL];
    const sh = [lerp(hip[0], neck[0], 0.92), lerp(hip[1], neck[1], 0.92)];
    const HR = zombie ? 50 : 58, hd = rad(lean + tilt);
    const head = [neck[0] + Math.sin(hd) * (HR + 6), neck[1] - Math.cos(hd) * (HR + 6)];
    const legs = [[lTh, lKn], [rTh, rKn]].map(([th, kn]) => {
      const k = pt(hip[0], hip[1], th, 105); const f = pt(k[0], k[1], th + kn, 105); return [k, f];
    });
    const arms = [[lUp, lFl], [rUp, rFl]].map(([up, fl]) => { const e = pt(sh[0], sh[1], up, 86); const h = pt(e[0], e[1], fl, 84); return [e, h]; });

    ctx.save();
    ctx.translate(o.x, o.y + lift);
    ctx.scale(o.scale * o.facing, o.scale);
    if (o.alpha != null && o.alpha < 1) ctx.globalAlpha = o.alpha;
    // shadow
    ctx.fillStyle = "rgba(0,0,0,.38)"; ctx.beginPath(); ctx.ellipse(0, 4 - lift / o.scale, 96, 15, 0, 0, TAU); ctx.fill();
    ctx.rotate(rot);

    const body = o.kind === "silhouette" ? "#04070b" : zombie ? "#86a692" : "#f1f5f8";
    const halo = o.kind === "silhouette" ? "#04070b" : "rgba(4,8,14,.72)";
    const path = () => {
      ctx.beginPath();
      ctx.moveTo(arms[1][1][0], arms[1][1][1]); ctx.lineTo(arms[1][0][0], arms[1][0][1]); ctx.lineTo(sh[0], sh[1]); // far arm
      ctx.moveTo(legs[1][1][0], legs[1][1][1]); ctx.lineTo(legs[1][0][0], legs[1][0][1]); ctx.lineTo(hip[0], hip[1]);
      ctx.moveTo(hip[0], hip[1]); ctx.lineTo(neck[0], neck[1]);
      ctx.moveTo(legs[0][1][0], legs[0][1][1]); ctx.lineTo(legs[0][0][0], legs[0][0][1]); ctx.lineTo(hip[0], hip[1]);
      ctx.moveTo(arms[0][1][0], arms[0][1][1]); ctx.lineTo(arms[0][0][0], arms[0][0][1]); ctx.lineTo(sh[0], sh[1]);
    };
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.strokeStyle = halo; ctx.lineWidth = 26; path(); ctx.stroke();
    ctx.strokeStyle = body; ctx.lineWidth = 15; path(); ctx.stroke();
    // feet
    ctx.lineWidth = 15;
    legs.forEach(([, f]) => { ctx.strokeStyle = halo; ctx.lineWidth = 26; ctx.beginPath(); ctx.moveTo(f[0], f[1]); ctx.lineTo(f[0] + 22, f[1]); ctx.stroke(); ctx.strokeStyle = body; ctx.lineWidth = 15; ctx.beginPath(); ctx.moveTo(f[0], f[1]); ctx.lineTo(f[0] + 22, f[1]); ctx.stroke(); });

    if (o.kind !== "silhouette") {
      const d = o.design;
      if (zombie) { // torn shirt stripes
        ctx.strokeStyle = "rgba(60,40,40,.85)"; ctx.lineWidth = 9;
        for (let i = 1; i < 4; i++) { const p = lerp(0.2, 0.8, i / 4); ctx.beginPath(); ctx.moveTo(lerp(hip[0], neck[0], p) - 10, lerp(hip[1], neck[1], p)); ctx.lineTo(lerp(hip[0], neck[0], p) + 10, lerp(hip[1], neck[1], p) + 8); ctx.stroke(); }
      } else {
        // accent scarf
        ctx.strokeStyle = d.accent; ctx.lineWidth = 22;
        ctx.beginPath(); ctx.moveTo(neck[0] - 12, neck[1] + 4); ctx.lineTo(neck[0] + 12, neck[1] + 4); ctx.stroke();
        ctx.lineWidth = 15; ctx.beginPath(); ctx.moveTo(neck[0] - 10, neck[1] + 6); ctx.lineTo(neck[0] - 28 - Math.sin(tt * 3) * 4, neck[1] + 50 + Math.sin(tt * 2) * 4); ctx.stroke();
      }
    }
    // head
    ctx.save(); ctx.translate(head[0], head[1]); ctx.rotate(hd);
    if (o.kind === "silhouette") { ctx.fillStyle = "#04070b"; ctx.beginPath(); ctx.arc(0, 0, HR, 0, TAU); ctx.fill(); }
    else {
      ctx.fillStyle = zombie ? "#9dbfa8" : "#f7f9fb"; ctx.strokeStyle = "rgba(4,8,14,.9)"; ctx.lineWidth = zombie ? 9 : 11;
      ctx.beginPath(); ctx.arc(0, 0, HR, 0, TAU); ctx.fill(); ctx.stroke();
      const d = o.design;
      if (!zombie) {
        if (d.hat) { ctx.fillStyle = d.accent; ctx.beginPath(); ctx.arc(0, -4, HR + 3, Math.PI * 1.02, Math.PI * 1.98); ctx.closePath(); ctx.fill(); ctx.fillRect(-HR - 3, -10, (HR + 3) * 2, 12); }
        else if (d.hair === "bun") { ctx.fillStyle = "#2a2f38"; ctx.beginPath(); ctx.arc(-8, -HR - 12, 20, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(0, -4, HR + 2, Math.PI * 1.1, Math.PI * 1.9); ctx.fill(); }
        else if (d.hair === "spiky") { ctx.fillStyle = "#2a2f38"; ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = Math.PI * (1.1 + i * 0.16); ctx.lineTo(Math.cos(a) * (HR + 2), Math.sin(a) * (HR + 2)); ctx.lineTo(Math.cos(a + 0.08) * (HR + 22), Math.sin(a + 0.08) * (HR + 22)); } ctx.fill(); }
      }
      drawFace(ctx, o, tt, zombie);
    }
    ctx.restore();
    ctx.restore();
  }

  function drawFace(ctx, o, tt, zombie) {
    const ex = o.expr || "neutral", talk = o.talk;
    const dark = "#0b1118";
    const blink = mod(tt, 3.3) < 0.11;
    const ey = -6, e1 = 14, e2 = 34;
    ctx.lineCap = "round"; ctx.lineWidth = 5; ctx.strokeStyle = dark; ctx.fillStyle = dark;
    const brow = (x, y, a) => { ctx.beginPath(); ctx.moveTo(x - 9, y + Math.sin(a) * -9); ctx.lineTo(x + 9, y + Math.sin(a) * 9); ctx.stroke(); };
    if (zombie) {
      ctx.fillStyle = "#ff2b2b"; ctx.shadowColor = "#ff2b2b"; ctx.shadowBlur = 14;
      [e1, e2].forEach((x) => { ctx.beginPath(); ctx.arc(x, ey, 7, 0, TAU); ctx.fill(); });
      ctx.shadowBlur = 0; ctx.fillStyle = "#2a0a0a";
      const open = 10 + Math.abs(Math.sin(tt * 3)) * 8;
      ctx.beginPath(); ctx.ellipse(24, 26, 15, open, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = "#cfd8cf"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(14, 20); ctx.lineTo(18, 26); ctx.lineTo(22, 20); ctx.lineTo(26, 26); ctx.lineTo(30, 20); ctx.stroke();
      return;
    }
    // eyes
    if (ex === "dead") {
      [e1, e2].forEach((x) => { ctx.beginPath(); ctx.moveTo(x - 6, ey - 6); ctx.lineTo(x + 6, ey + 6); ctx.moveTo(x + 6, ey - 6); ctx.lineTo(x - 6, ey + 6); ctx.stroke(); });
    } else if (blink || ex === "tired") {
      [e1, e2].forEach((x) => { ctx.beginPath(); ctx.moveTo(x - 6, ey + (ex === "tired" ? 1 : 3)); ctx.lineTo(x + 6, ey + (ex === "tired" ? 1 : 3)); ctx.stroke(); });
    } else if (ex === "scared" || ex === "surprised" || ex === "shocked") {
      ctx.fillStyle = "#fff"; ctx.lineWidth = 4;
      [e1, e2].forEach((x) => { ctx.beginPath(); ctx.arc(x, ey, 10, 0, TAU); ctx.fill(); ctx.stroke(); });
      ctx.fillStyle = dark; [e1, e2].forEach((x) => { ctx.beginPath(); ctx.arc(x + 2, ey, 4, 0, TAU); ctx.fill(); });
    } else {
      // part-1 style: big white eyes, dark outline, pupils that drift a little
      const px = Math.sin(tt * 0.7) * 2.2;
      ctx.fillStyle = "#fff"; ctx.lineWidth = 4;
      [e1, e2].forEach((x) => { ctx.beginPath(); ctx.arc(x, ey, 11.5, 0, TAU); ctx.fill(); ctx.stroke(); });
      ctx.fillStyle = dark; [e1, e2].forEach((x) => { ctx.beginPath(); ctx.arc(x + 2 + px, ey + 1, 5.6, 0, TAU); ctx.fill(); });
    }
    // brows
    ctx.lineWidth = 5;
    if (ex === "worried" || ex === "sad") { brow(e1, ey - 20, -0.9); brow(e2, ey - 20, 0.9); }
    else if (ex === "scared" || ex === "surprised" || ex === "shocked") { brow(e1, ey - 26, -0.3); brow(e2, ey - 26, 0.3); }
    else if (ex === "angry" || ex === "determined") { brow(e1, ey - 17, 0.9); brow(e2, ey - 17, -0.9); }
    // mouth
    const my = 24;
    ctx.lineWidth = 5; ctx.fillStyle = "#2a0d10";
    if (talk > 0.05 && ex !== "dead") {
      const open = 3 + (Math.abs(Math.sin(tt * 13.1)) * 0.65 + Math.abs(Math.sin(tt * 5.3)) * 0.35) * 10 * talk;
      ctx.beginPath(); ctx.ellipse(24, my, 9 + open * 0.25, open, 0, 0, TAU); ctx.fill();
    } else if (ex === "happy" || ex === "relieved") { ctx.beginPath(); ctx.arc(24, my - 8, 14, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke(); }
    else if (ex === "sad" || ex === "worried") { ctx.beginPath(); ctx.arc(24, my + 12, 12, 1.15 * Math.PI, 1.85 * Math.PI); ctx.stroke(); }
    else if (ex === "scared" || ex === "surprised" || ex === "shocked") { ctx.beginPath(); ctx.ellipse(24, my + 2, 9, 13 + Math.sin(tt * 40) * (ex === "scared" ? 1.5 : 0), 0, 0, TAU); ctx.fill(); }
    else if (ex === "angry") { ctx.beginPath(); ctx.moveTo(12, my + 3); ctx.lineTo(36, my + 3); ctx.stroke(); }
    else if (ex === "dead") { ctx.beginPath(); ctx.moveTo(14, my + 2); ctx.lineTo(34, my + 2); ctx.stroke(); }
    else { ctx.beginPath(); ctx.moveTo(15, my); ctx.lineTo(33, my); ctx.stroke(); }
  }

  function drawRadio(ctx, x, y, t, active) {
    ctx.save(); ctx.translate(x, y);
    ctx.fillStyle = "#12171d"; ctx.strokeStyle = "rgba(255,255,255,.2)"; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(-70, -170, 140, 170, 14) : ctx.rect(-70, -170, 140, 170); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = "#8aa0b3"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(50, -170); ctx.lineTo(80, -280); ctx.stroke();
    ctx.fillStyle = "#222b33"; ctx.beginPath(); ctx.arc(-18, -80, 42, 0, TAU); ctx.fill();
    ctx.fillStyle = active ? "#6df0a2" : "#34503f"; ctx.beginPath(); ctx.arc(40, -140, 7, 0, TAU); ctx.fill();
    if (active) {
      ctx.strokeStyle = "rgba(109,240,162,.7)"; ctx.lineWidth = 4;
      for (let i = 0; i < 3; i++) { const p = mod(t * 1.4 + i / 3, 1); ctx.globalAlpha = 1 - p; ctx.beginPath(); ctx.arc(80, -280, 20 + p * 70, -0.9, 0.9); ctx.stroke(); }
    }
    ctx.restore();
  }

  /* ---------- scene state & camera ---------- */
  SV.sceneAt = function (comp, t) {
    const S = comp.scenes;
    for (let i = S.length - 1; i >= 0; i--) if (t >= S[i].start) return S[i];
    return S[0];
  };
  SV.sceneState = function (sc, t) {
    const st = {
      hud: Object.assign({}, sc.entry.hud), weather: sc.entry.weather, expr: Object.assign({}, sc.entry.expr),
      pose: { all: { v: "idle", t: sc.start }, by: {} }, zombies: [], titles: [], flashes: [], scroll: sc.index * 977,
    };
    let lastT = sc.start, speed = 0;
    for (const ev of sc.events) {
      if (ev.t > t) break;
      switch (ev.type) {
        case "expr": st.expr[ev.name] = ev.value; break;
        case "weather": st.weather = ev.value; break;
        case "hud": Object.assign(st.hud, ev.kv); break;
        case "pose":
          if (ev.who) st.pose.by[ev.who] = { v: ev.value, t: ev.t };
          else { st.scroll += speed * (ev.t - lastT); lastT = ev.t; st.pose.all = { v: ev.value, t: ev.t }; st.pose.by = {}; speed = POSE_SPEED[ev.value] || 0; }
          break;
        case "zombies": if (ev.count === 0) st.zombies = []; else st.zombies.push({ t0: ev.t, count: ev.count, mode: ev.mode, side: ev.side, seed: (sc.seed & 0xfffff) + Math.floor(ev.t * 10) }); break;
        case "title": if (t < ev.t + ev.dur) st.titles.push(ev); break;
        case "flash": if (t - ev.t < ev.dur) st.flashes.push(ev); break;
        default: break;
      }
    }
    st.scroll += speed * (t - lastT);
    return st;
  };
  function cameraAt(sc, t) {
    let z = 1.1, px = 0, py = 0, sx = 0, sy = 0, rot = 0;
    for (const ev of sc.events) {
      if (ev.type !== "camera" || t < ev.t) continue;
      const dur = Math.max(0.05, ev.dur), u = (t - ev.t) / dur, p = clamp(u), e = ease(p);
      switch (ev.name) {
        case "slow_push_in": case "push_in": case "slow_zoom_in": z *= 1 + 0.16 * e; break;
        case "zoom_in": case "snap_zoom": z *= 1 + 0.38 * easeOut(p); break;
        case "slow_pull_out": case "pull_out": case "slow_zoom_out": z *= 1 + 0.16 * (1 - e); break;
        case "zoom_out": z *= 1 + 0.38 * (1 - easeOut(p)); break;
        case "pan_left": px += lerp(40, -40, e); break;
        case "pan_right": px += lerp(-40, 40, e); break;
        case "tilt_up": py += lerp(-45, 45, e); break;
        case "tilt_down": py += lerp(45, -45, e); break;
        case "dutch": case "dutch_tilt": rot += 0.06 * e; break;
        case "shake": { if (u <= 1) { const a = (ev.amp || 14) * Math.pow(1 - p, 1.4); sx += a * (Math.sin(t * 71.3) + Math.sin(t * 43.9 + 1.7)) * 0.5; sy += a * (Math.sin(t * 59.1 + 0.6) + Math.sin(t * 37.7)) * 0.5; z *= 1 + a / 700; } break; }
        case "handheld": { if (u <= 1) { const a = ev.amp || 5; sx += a * Math.sin(t * 2.3) + a * 0.5 * Math.sin(t * 5.1); sy += a * Math.sin(t * 1.9 + 1) * 0.8; } break; }
        default: break;
      }
    }
    let x = px + sx, y = py + sy;
    const mx = ((z - 1) * W) / (2 * z), my = ((z - 1) * H) / (2 * z);
    x = clamp(x, -mx, mx); y = clamp(y, -my, my);
    return { z, x, y, rot };
  }

  /* ---------- entities ---------- */
  function zombieList(sc, st, t) {
    const out = [];
    st.zombies.forEach((g, gi) => {
      const dt = t - g.t0;
      if (dt < 0) return;
      for (let i = 0; i < g.count; i++) {
        const s = g.seed + i * 31 + gi * 1013, r = (k) => H1(s + k);
        let d = 0.45 + 0.55 * r(1), kind = "zombie", x, y, spd = (45 + 70 * r(3)) * (0.5 + d);
        const sign = g.side === "left" ? -1 : 1;
        if (g.mode === "silhouette") { d = 0.2 + 0.12 * r(1); kind = "silhouette"; spd = 14 + 10 * r(3); }
        else if (g.mode === "distant") { d = 0.3 + 0.2 * r(1); spd = 20 + 16 * r(3); }
        else if (g.mode === "horde") { spd *= 1.5; }
        else if (g.mode === "chase" || g.mode === "run") { spd = 230 + 90 * r(3); }
        const far = g.mode === "silhouette" || g.mode === "distant";
        let tgt;
        if (far) tgt = sign > 0 ? 520 + r(4) * 460 : 60 + r(4) * 460;
        else tgt = 540 + sign * (190 + r(4) * (g.mode === "horde" ? 520 : 300));
        const x0 = far ? tgt + sign * (120 + r(2) * 260) : sign > 0 ? W + 160 + r(2) * (g.mode === "horde" ? 900 : 520) : -160 - r(2) * (g.mode === "horde" ? 900 : 520);
        x = x0 - sign * spd * dt;
        if (sign > 0) x = Math.max(tgt, x); else x = Math.min(tgt, x);
        y = HORIZON + 190 * d;
        if (kind === "silhouette") y = HORIZON - 6 + 40 * r(5);
        const moving = Math.abs(x - tgt) > 2;
        out.push({ kind, x, y, scale: 0.4 + 0.6 * d, facing: -sign, phase: r(6) * 5, pose: "idle", moving, depth: y + r(7), design: null });
      }
    });
    return out;
  }

  function drawSprite(ctx, o, asset) {
    const tt = o.t + o.phase, slots = asset.slots, ex = o.expr || "neutral", p = o.pose;
    let key = slots[ex] ? ex : "idle";
    if (p === "scared" && slots.scared) key = "scared";
    if (p === "walk" && slots.walkA) key = mod(Math.floor(tt / 0.28), 2) && slots.walkB ? "walkB" : "walkA";
    if (p === "run" && slots.runA) key = mod(Math.floor(tt / 0.18), 2) && slots.runB ? "runB" : "runA";
    if ((p === "fall" || p === "collapse" || p === "dead") && slots.fall) key = "fall";
    if (o.talk > 0.05) { // lip-sync: swap to the open-mouth image while speaking
      const tk = slots[ex + "_talk"] ? ex + "_talk" : slots.talk ? "talk" : null;
      if (tk && Math.sin(tt * 14) + 0.8 * Math.sin(tt * 5.3) > 0.1) key = tk;
    }
    const img = slots[key] || slots.idle;
    if (!img || !img.width) return false;
    const h0 = (asset.height || 640) * o.scale, k = h0 / img.height, w0 = img.width * k;
    let bob = 0, rot = 0, sy = 1, tx = 0, lift = 0;
    if (p === "walk") { bob = -Math.abs(Math.sin((tt * Math.PI) / 0.475)) * 14; rot = Math.sin((tt * TAU) / 0.95) * 0.04; }
    else if (p === "run") { bob = -Math.abs(Math.sin((tt * Math.PI) / 0.28)) * 26; rot = 0.12 + Math.sin((tt * TAU) / 0.56) * 0.04; }
    else if (p === "scared") { tx = Math.sin(tt * 47) * 4; rot = -0.05; }
    else if (p === "fall" || p === "collapse" || p === "dead") { const u = easeOut(clamp((o.t - o.poseT) / 0.7)); rot = -u * (Math.PI / 2); lift = u * 14; }
    else sy = 1 + Math.sin(tt * 2.1) * 0.012;
    if (o.talk > 0.05) sy += 0.014 * Math.abs(Math.sin(tt * 13)) * o.talk;
    ctx.save();
    ctx.translate(o.x, o.y + lift);
    ctx.fillStyle = "rgba(0,0,0,.4)"; ctx.beginPath(); ctx.ellipse(0, 4, w0 * 0.34, 15, 0, 0, TAU); ctx.fill();
    ctx.scale(o.facing * (asset.facesLeft ? -1 : 1), 1);
    ctx.translate(tx, bob); ctx.rotate(rot); ctx.scale(1, sy);
    ctx.drawImage(img, -w0 / 2, -h0 + (asset.yOff || 0), w0, h0);
    ctx.restore();
    return true;
  }

  function drawEntities(ctx, sc, st, t, comp) {
    const items = [], S = comp.settings || {};
    const cast = sc.cast;
    const xs = cast.length === 1 ? [540] : cast.length === 2 ? [340, 740] : [230, 540, 850];
    const line = sc.lines.find((l) => t >= l.start && t <= l.end + 0.08);
    const env = line ? clamp((t - line.start) / 0.12) * clamp((line.end + 0.08 - t) / 0.12) : 0;
    const narr = line && line.kind === "NARRATOR";
    const zl = zombieList(sc, st, t);
    const zSide = st.zombies.length ? (st.zombies[0].side === "left" ? -1 : 1) : 0;
    cast.forEach((d, i) => {
      const poseEv = st.pose.by[d.name] || st.pose.all;
      const expr = st.expr[d.name] || (st.zombies.length ? "worried" : "neutral");
      const speaking = line && (line.speaker === d.name || (d.isNarrator && narr) || (narr && S.narratorLips !== false && !S.narratorOnScreen && d.isHero));
      const talk = speaking ? env : 0;
      const facing = cast.length === 1 ? (zSide < 0 ? -1 : 1) : xs[i] < 540 ? 1 : xs[i] > 540 ? -1 : (zSide || 1);
      const asset = SV.charAssets[d.name];
      items.push({ depth: FEET_Y + i * 0.1, fn: () => {
        const o = { x: xs[i], y: FEET_Y, scale: d.scale, facing, design: d, kind: "hero", pose: poseEv.v, poseT: poseEv.t, t, phase: i * 1.37, expr, talk };
        if (!(asset && asset.slots && asset.slots.idle && drawSprite(ctx, o, asset))) drawFigure(ctx, o);
      } });
    });
    zl.forEach((z) => items.push({ depth: z.depth, fn: () => drawFigure(ctx, { x: z.x, y: z.y, scale: z.scale, facing: z.facing, design: null, kind: z.kind, pose: z.moving ? "walk" : "idle", poseT: 0, t, phase: z.phase, expr: "neutral", talk: 0 }) }));
    if (sc.hasRadio) {
      const act = line && line.kind === "RADIO";
      items.push({ depth: FEET_Y - 5, fn: () => drawRadio(ctx, cast.length > 1 ? 540 : 160, FEET_Y, t, !!act) });
    }
    items.sort((a, b) => a.depth - b.depth).forEach((i) => i.fn());
  }

  /* ---------- overlays ---------- */
  function vignette(color, key) {
    return cached("vig:" + key, W, H, (g) => {
      const r = g.createRadialGradient(W / 2, H / 2, 380, W / 2, H / 2, 1250);
      r.addColorStop(0, "rgba(0,0,0,0)"); r.addColorStop(1, color);
      g.fillStyle = r; g.fillRect(0, 0, W, H);
    });
  }
  function rrect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  const ecg = (p) => {
    const g = (c, w, a) => a * Math.exp(-Math.pow((p - c) / w, 2));
    return g(0.12, 0.025, 0.12) + g(0.27, 0.008, -0.18) + g(0.30, 0.010, 1.0) + g(0.33, 0.010, -0.30) + g(0.55, 0.05, 0.22);
  };
  function drawHeartPanel(ctx, bpm, t, y0) {
    const risk = clamp((bpm - 72) / 95), col = bpm < 100 ? "#46e08a" : bpm < 135 ? "#ffbf3a" : "#ff3b4a";
    const x = 50, w = 980, h = 232;
    ctx.save();
    ctx.shadowColor = col; ctx.shadowBlur = 20 + 18 * Math.exp(-mod(t * bpm / 60, 1) * 6);
    ctx.fillStyle = "rgba(5,9,14,.74)"; rrect(ctx, x, y0, w, h, 26); ctx.fill();
    ctx.shadowBlur = 0; ctx.strokeStyle = col; ctx.lineWidth = 4; ctx.globalAlpha = 0.9; rrect(ctx, x, y0, w, h, 26); ctx.stroke(); ctx.globalAlpha = 1;
    // heart + number
    const ph = mod(t * bpm / 60, 1), s = 1 + 0.3 * Math.exp(-ph * 7);
    ctx.save(); ctx.translate(x + 82, y0 + 92); ctx.scale(s * 1.7, s * 1.7); ctx.fillStyle = col; ctx.shadowColor = col; ctx.shadowBlur = 18;
    ctx.beginPath(); ctx.moveTo(0, 14); ctx.bezierCurveTo(-34, -10, -18, -34, 0, -16); ctx.bezierCurveTo(18, -34, 34, -10, 0, 14); ctx.fill(); ctx.restore();
    ctx.shadowBlur = 0; ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#fff"; ctx.font = "bold 104px Nunito, sans-serif"; ctx.fillText(String(Math.round(bpm)), x + 150, y0 + 124);
    ctx.fillStyle = col; ctx.font = "bold 28px Nunito, sans-serif"; ctx.fillText("BPM", x + 160, y0 + 160);
    // ECG trace
    const ex = x + 440, ew = 510, ey = y0 + 96, amp = 62, spd = 250;
    ctx.save(); ctx.beginPath(); ctx.rect(ex, y0 + 18, ew, 150); ctx.clip();
    ctx.strokeStyle = "rgba(255,255,255,.07)"; ctx.lineWidth = 2;
    for (let gx = ex - mod(t * spd, 40); gx < ex + ew; gx += 40) { ctx.beginPath(); ctx.moveTo(gx, y0 + 18); ctx.lineTo(gx, y0 + 168); ctx.stroke(); }
    for (let k = 0; k < 2; k++) {
      ctx.beginPath();
      for (let px = 0; px <= ew; px += 3) { const tau = t - (ew - px) / spd, yy = ey - ecg(mod(tau * bpm / 60, 1)) * amp; if (px === 0) ctx.moveTo(ex + px, yy); else ctx.lineTo(ex + px, yy); }
      ctx.strokeStyle = col; ctx.lineJoin = "round"; ctx.lineCap = "round";
      if (k === 0) { ctx.lineWidth = 10; ctx.globalAlpha = 0.22; } else { ctx.lineWidth = 4; ctx.globalAlpha = 1; }
      ctx.stroke();
    }
    ctx.restore();
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(ex + ew - 4, ey - ecg(ph) * amp, 6, 0, TAU); ctx.fill();
    // noise / detection bar
    const by = y0 + 190;
    ctx.fillStyle = "#9badc2"; ctx.font = "bold 22px Nunito, sans-serif"; ctx.fillText("NOISE", x + 30, by + 14);
    ctx.fillStyle = "rgba(255,255,255,.14)"; rrect(ctx, x + 130, by, 560, 20, 10); ctx.fill();
    ctx.fillStyle = col; rrect(ctx, x + 130, by, Math.max(20, 560 * risk), 20, 10); ctx.fill();
    const label = risk > 0.72 ? "THEY CAN HEAR YOU" : risk > 0.4 ? "RISKY" : "QUIET";
    ctx.textAlign = "right"; ctx.fillStyle = col; ctx.globalAlpha = risk > 0.72 ? 0.55 + 0.45 * Math.abs(Math.sin(t * 7)) : 1;
    ctx.font = "bold 26px Nunito, sans-serif"; ctx.fillText(label, x + w - 30, by + 18);
    ctx.restore();
  }
  function drawHUD(ctx, st, t) {
    const keys = Object.keys(st.hud);
    if (!keys.length) return;
    let y = 215;
    if (st.hud.HEART != null) { drawHeartPanel(ctx, parseFloat(st.hud.HEART) || 72, t, y); y += 252; }
    const rest = keys.filter((k) => k !== "HEART").slice(0, 4);
    ctx.save(); ctx.textBaseline = "middle"; ctx.textAlign = "left";
    let x = 50;
    rest.forEach((k) => {
      const lab = k.replace(/_/g, " "), v = String(st.hud[k]);
      ctx.font = "bold 24px Nunito, sans-serif"; const lw = ctx.measureText(lab).width;
      ctx.font = "bold 36px Nunito, sans-serif"; const vw = ctx.measureText(v).width, w = lw + vw + 70;
      if (x + w > W - 50) { x = 50; y += 78; }
      ctx.fillStyle = "rgba(5,9,14,.74)"; rrect(ctx, x, y, w, 64, 32); ctx.fill();
      ctx.strokeStyle = "rgba(104,217,232,.55)"; ctx.lineWidth = 3; rrect(ctx, x, y, w, 64, 32); ctx.stroke();
      ctx.fillStyle = "#9badc2"; ctx.font = "bold 24px Nunito, sans-serif"; ctx.fillText(lab, x + 26, y + 33);
      ctx.fillStyle = "#fff"; ctx.font = "bold 36px Nunito, sans-serif"; ctx.fillText(v, x + 40 + lw, y + 33);
      x += w + 14;
    });
    ctx.restore();
  }
  function wrapLines(ctx, text, maxW) {
    const words = text.split(/\s+/), lines = []; let cur = "";
    words.forEach((w) => { const tt = cur ? cur + " " + w : w; if (ctx.measureText(tt).width > maxW && cur) { lines.push(cur); cur = w; } else cur = tt; });
    if (cur) lines.push(cur); return lines;
  }
  function drawChoices(ctx, comp, t) {
    const ch = comp.choices;
    if (!ch || !ch.length || t < ch[0].start) return;
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,.38)"; ctx.globalAlpha = clamp((t - ch[0].start) / 0.4); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
    ch.forEach((c) => {
      if (t < c.start) return;
      const idx = c.key === "A" ? 0 : 1, p = easeOut(clamp((t - c.start) / 0.45)), act = t >= c.start && t < c.end + 0.15;
      const w = 470, h = 306, x = 50 + idx * 510, y = 462 + (1 - p) * 70;
      const col = idx === 0 ? [214, 48, 62] : [48, 116, 220];
      ctx.save(); ctx.globalAlpha = p; ctx.translate(x + w / 2, y + h / 2); const sc = act ? 1.04 + 0.012 * Math.sin(t * 9) : 1; ctx.scale(sc, sc); ctx.translate(-w / 2, -h / 2);
      ctx.shadowColor = `rgba(${col},.9)`; ctx.shadowBlur = act ? 36 : 10;
      ctx.fillStyle = "rgba(8,12,20,.88)"; rrect(ctx, 0, 0, w, h, 26); ctx.fill(); ctx.shadowBlur = 0;
      ctx.strokeStyle = `rgb(${col})`; ctx.lineWidth = act ? 7 : 4; rrect(ctx, 0, 0, w, h, 26); ctx.stroke();
      ctx.fillStyle = `rgb(${col})`; ctx.beginPath(); ctx.arc(62, 58, 40, 0, TAU); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.font = "bold 52px Nunito, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(c.key, 62, 66);
      ctx.textAlign = "left"; ctx.textBaseline = "top"; ctx.font = "bold 27px Nunito, sans-serif";
      const lines = wrapLines(ctx, c.text, w - 52).slice(0, 6);
      ctx.fillStyle = act ? "#fff" : "#cdd8e4"; lines.forEach((l, i) => ctx.fillText(l, 26, 116 + i * 33));
      ctx.restore();
    });
    if (comp.cta && t >= comp.cta.start) {
      const p = easeOut(clamp((t - comp.cta.start) / 0.4)), pulse = 1 + 0.05 * Math.sin(t * 8);
      ctx.save(); ctx.globalAlpha = p; ctx.translate(W / 2, 1340); ctx.scale(pulse, pulse);
      ctx.fillStyle = "rgba(255,225,77,.95)"; rrect(ctx, -400, -62, 800, 124, 62); ctx.fill();
      ctx.fillStyle = "#14110a"; ctx.font = "bold 66px Nunito, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText("COMMENT  A  or  B", 0, 4);
      ctx.restore();
    }
    ctx.restore();
  }
  function drawTitle(ctx, ev, t) {
    const a = clamp((t - ev.t) / 0.3) * clamp((ev.t + ev.dur - t) / 0.3);
    ctx.save(); ctx.globalAlpha = a; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 70px Nunito, sans-serif"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "rgba(0,0,0,.85)";
    const txt = ev.text.toUpperCase(), y = 400 - (1 - easeOut(clamp((t - ev.t) / 0.4))) * 24;
    ctx.fillStyle = "rgba(0,0,0,.45)"; const tw = ctx.measureText(txt).width; rrect(ctx, W / 2 - tw / 2 - 40, y - 62, tw + 80, 124, 20); ctx.fill();
    ctx.strokeText(txt, W / 2, y); ctx.fillStyle = "#fff"; ctx.fillText(txt, W / 2, y);
    ctx.restore();
  }
  function drawCaption(ctx, comp, t) {
    const ch = comp.captionChunks;
    let lo = 0, hi = ch.length - 1, f = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (ch[m].start <= t) { f = m; lo = m + 1; } else hi = m - 1; }
    if (f < 0 || t >= ch[f].end) return;
    const c = ch[f];
    ctx.save();
    ctx.font = (c.emph ? "bold 92px" : "bold 84px") + " Nunito, sans-serif"; ctx.textBaseline = "middle"; ctx.textAlign = "left"; ctx.lineJoin = "round";
    const words = c.words.map((w) => w.w.toUpperCase());
    const sp = ctx.measureText(" ").width, ws = words.map((w) => ctx.measureText(w).width);
    const total = ws.reduce((a, b) => a + b, 0) + sp * (words.length - 1);
    let rows = [words.map((_, i) => i)];
    if (total > 930 && words.length > 1) {
      let best = 1, diff = 1e9;
      for (let k = 1; k < words.length; k++) {
        const a = ws.slice(0, k).reduce((p, q) => p + q, 0) + sp * (k - 1), b = ws.slice(k).reduce((p, q) => p + q, 0) + sp * (words.length - k - 1);
        if (Math.abs(a - b) < diff) { diff = Math.abs(a - b); best = k; }
      }
      rows = [words.slice(0, best).map((_, i) => i), words.slice(best).map((_, i) => i + best)];
    }
    const pop = 0.9 + 0.1 * easeOut(clamp((t - c.start) / 0.1));
    const cy = 1470;
    ctx.translate(W / 2, cy); ctx.scale(pop, pop);
    rows.forEach((row, ri) => {
      const rw = row.reduce((a, i) => a + ws[i], 0) + sp * (row.length - 1);
      let x = -rw / 2; const y = (ri - (rows.length - 1) / 2) * 104;
      row.forEach((i) => {
        const w = c.words[i], active = t >= w.start && t < w.end;
        ctx.lineWidth = 20; ctx.strokeStyle = "rgba(0,0,0,.92)"; ctx.strokeText(words[i], x, y);
        ctx.fillStyle = active ? "#ffe14d" : c.emph ? "#ff5a4d" : "#ffffff"; ctx.fillText(words[i], x, y);
        x += ws[i] + sp;
      });
    });
    ctx.restore();
  }

  /* ---------- frame ---------- */
  SV._ov = { drawChoices, drawHUD, drawTitle, cameraAt, zombieList, drawSprite };
  SV.whenStudio = () => (SV.studioReady ? Promise.resolve() : new Promise((r) => (SV._studioWaiters = SV._studioWaiters || []).push(r)));
  SV.drawFrame = function (ctx, comp, t, opt) {
    opt = opt || {};
    if (SV.studio && SV.studioReady && (comp.settings || {}).look !== "classic" && !opt.classic) return SV.studio.drawFrame(ctx, comp, t, opt);
    t = clamp(t, 0, Math.max(0, comp.duration - 1e-4));
    const sc = SV.sceneAt(comp, t);
    ctx.save();
    ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
    if (!sc) { ctx.restore(); return; }
    const st = SV.sceneState(sc, t), cam = cameraAt(sc, t);
    ctx.save();
    ctx.translate(W / 2, H / 2); ctx.rotate(cam.rot); ctx.scale(cam.z, cam.z); ctx.translate(-W / 2 + cam.x, -H / 2 + cam.y);
    const P = drawWorld(ctx, sc, st, t);
    drawEntities(ctx, sc, st, t, comp);
    const indoor = sc.bg.type === "room" || sc.bg.type === "bunker";
    const w = indoor ? "none" : st.weather;
    if (/fog|mist/.test(w)) drawFog(ctx, t, P, 1, sc.seed & 0xff);
    else if (/storm|rain/.test(w)) drawFog(ctx, t, P, 0.45, sc.seed & 0xff);
    if (/rain|storm/.test(w)) drawRain(ctx, t, 1, /storm/.test(w));
    ctx.restore();

    // screen-space light / grade
    if (/storm|lightning/.test(w)) {
      const a = lightningAmt(t, sc.seed);
      if (a > 0.01) { ctx.fillStyle = `rgba(210,230,255,${0.5 * a})`; ctx.fillRect(0, 0, W, H); }
    }
    ctx.drawImage(vignette("rgba(0,0,0,.62)", "k"), 0, 0);
    const bpm = parseFloat(st.hud.HEART);
    if (bpm > 0) {
      const env = Math.exp(-mod(t * bpm / 60, 1) * 7), a = clamp((bpm - 85) / 90) * 0.55 * env;
      if (a > 0.01) { ctx.globalAlpha = a; ctx.drawImage(vignette("rgba(220,10,20,.95)", "r"), 0, 0); ctx.globalAlpha = 1; }
    }
    st.flashes.forEach((f) => { const k = 1 - (t - f.t) / f.dur; ctx.fillStyle = f.color; ctx.globalAlpha = clamp(f.amp * k * k); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; });

    drawChoices(ctx, comp, t);
    if (opt.hud !== false) drawHUD(ctx, st, t);
    st.titles.forEach((ev) => drawTitle(ctx, ev, t));
    if (opt.captions !== false) drawCaption(ctx, comp, t);

    // scene transition (applied last, over captions)
    const lt = t - sc.start;
    if (sc.transition !== "cut" && lt < 0.32) {
      const k = 1 - lt / 0.32;
      if (sc.transition === "flash") { ctx.fillStyle = "#fff"; ctx.globalAlpha = k * k; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
      else if (sc.transition === "glitch" || sc.transition === "whip") {
        ctx.globalAlpha = k * 0.7; ctx.fillStyle = "#000";
        for (let i = 0; i < 7; i++) { const y = H1(i + Math.floor(t * 30)) * H; ctx.fillRect(0, y, W, 20 + H1(i + 5) * 120); }
        ctx.globalAlpha = 1;
      } else { ctx.fillStyle = "#000"; ctx.globalAlpha = k; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
    }
    if (t > comp.duration - 0.35) { ctx.fillStyle = "#000"; ctx.globalAlpha = clamp((t - (comp.duration - 0.35)) / 0.35); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
    ctx.restore();
  };

  SV.thumbTime = (sc) => sc.start + Math.min((sc.end - sc.start) * 0.45, 2.2) + 0.2;
  SV.drawThumb = function (comp, idx, canvas) {
    const sc = comp.scenes[idx], g = canvas.getContext("2d");
    g.save(); g.scale(canvas.width / W, canvas.height / H);
    SV.drawFrame(g, comp, Math.min(SV.thumbTime(sc), sc.end - 0.02));
    g.restore();
  };
})();
