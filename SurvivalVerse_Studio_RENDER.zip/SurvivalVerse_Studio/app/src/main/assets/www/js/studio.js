/* Studio look: GrowKaz engine (rig, fx, styles) driven by the SurvivalVerse auto-director.
   SV.studio.drawFrame(ctx, comp, t, opt) is a pure function of time, like the classic engine. */
import * as C from '../gk/core.js';
import * as R from '../gk/rig2d.js';
import * as FX from '../gk/fx2d.js';
import { SETS } from './sets.js';
const { E, clamp, lerp, ease, prog, alpha, shade, mix, seg, circle, ring, rr, poly, linGrad, radGrad, glow, text, measure, layer, blurLayer, rng, noise } = C;
const SV = window.SV, W = 1080, H = 1920, TAU = Math.PI * 2, FY = 1250;
Object.assign(E, { W, H, vertical: true, fps: 30, words: [], cfg: {} });
const DARK = '#0b1118';

/* ---------- fonts ---------- */
const FONT_FILES = [['Fredoka', '600', 'fredoka-latin-600-normal.woff2'], ['Fredoka', '700', 'fredoka-latin-700-normal.woff2'], ['Nunito', '800', 'nunito-latin-800-normal.woff2'], ['Nunito', '900', 'nunito-latin-900-normal.woff2']];
async function loadFonts() {
  await Promise.all(FONT_FILES.map(async ([fam, w, f]) => { try { const ff = new FontFace(fam, `url(${new URL('../gk/fonts/' + f, import.meta.url).href})`, { weight: w }); await ff.load(); document.fonts.add(ff); } catch (e) { console.warn('font', f, e); } }));
}

/* ---------- faces ---------- */
function heroFace(g, hx, hy, r, o = {}) {
  const ex = { ...(R.EXPR[o.expr] || R.EXPR.neutral), ...(o.override || {}) };
  const fx = hx + (o.front ? 0 : r * 0.3), fy = hy - r * 0.04, ey = fy - r * 0.06;
  const xs = o.front ? [fx - r * 0.36, fx + r * 0.36] : [fx - r * 0.3, fx + r * 0.34], look = o.look || ex.look || [0, 0];
  g.save(); g.lineCap = 'round'; g.lineJoin = 'round';
  ring(g, hx, hy, r - r * 0.04, r * 0.09, DARK);
  const eyeR = ex.eyes === 'ring' || ex.eyes === 'wide' ? r * 0.27 : r * 0.23, drift = Math.sin((o.tt || 0) * 0.8) * r * 0.025;
  xs.forEach((x, i) => {
    const k = o.front ? 1 : i === 0 ? 0.9 : 1;
    if (o.blink || ex.eyes === 'closed') { seg(g, [[x - eyeR * 0.8 * k, ey], [x + eyeR * 0.8 * k, ey]], r * 0.07, DARK); return; }
    if (ex.eyes === 'happy') { g.strokeStyle = DARK; g.lineWidth = r * 0.08; g.beginPath(); g.arc(x, ey + r * 0.05, r * 0.15 * k, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); return; }
    circle(g, x, ey, eyeR * k, '#fff'); ring(g, x, ey, eyeR * k, r * 0.055, DARK);
    const pr = (ex.eyes === 'ring' ? 0.07 : ex.eyes === 'wide' ? 0.085 : 0.115) * r * k;
    circle(g, x + (look[0] * 0.09 + 0.07) * r + drift, ey + (look[1] * 0.09 + 0.015) * r, pr, DARK);
  });
  const by = ey - r * 0.36, bw = r * 0.17, brow = (x, a) => seg(g, [[x - bw, by + a], [x + bw, by - a]], r * 0.07, DARK);
  if (ex.brows === 'worried') { brow(xs[0], -r * 0.07); brow(xs[1], r * 0.07); }
  if (ex.brows === 'angry') { brow(xs[0], r * 0.09); brow(xs[1], -r * 0.09); }
  if (ex.brows === 'raised') xs.forEach((x) => { g.strokeStyle = DARK; g.lineWidth = r * 0.07; g.beginPath(); g.arc(x, by + r * 0.13, r * 0.17, Math.PI * 1.2, Math.PI * 1.8); g.stroke(); });
  if (ex.brows === 'confused') { brow(xs[0], r * 0.07); g.strokeStyle = DARK; g.lineWidth = r * 0.07; g.beginPath(); g.arc(xs[1], by + r * 0.08, r * 0.17, Math.PI * 1.2, Math.PI * 1.8); g.stroke(); }
  const mx = fx + (o.front ? 0 : r * 0.04), my = fy + r * 0.46, talk = o.talk || 0;
  g.strokeStyle = DARK; g.fillStyle = DARK; g.lineWidth = r * 0.08;
  if (talk > 0.05) { g.beginPath(); g.ellipse(mx, my, r * 0.17, r * (0.05 + 0.2 * talk), 0, 0, TAU); g.fill(); }
  else switch (ex.mouth) {
    case 'grin': g.beginPath(); g.moveTo(mx - r * 0.3, my - r * 0.06); g.quadraticCurveTo(mx, my + r * 0.42, mx + r * 0.3, my - r * 0.06); g.closePath(); g.fill(); break;
    case 'smile': g.beginPath(); g.arc(mx, my - r * 0.2, r * 0.27, 0.35, Math.PI - 0.35); g.stroke(); break;
    case 'smallSmile': g.beginPath(); g.arc(mx, my - r * 0.14, r * 0.18, 0.4, Math.PI - 0.4); g.stroke(); break;
    case 'o': g.beginPath(); g.ellipse(mx, my, r * 0.11, r * 0.15, 0, 0, TAU); g.fill(); break;
    case 'oBig': g.beginPath(); g.ellipse(mx, my + r * 0.04, r * 0.15, r * 0.2, 0, 0, TAU); g.fill(); break;
    case 'flat': seg(g, [[mx - r * 0.2, my], [mx + r * 0.2, my]], r * 0.08, DARK); break;
    case 'smallFlat': seg(g, [[mx - r * 0.12, my], [mx + r * 0.12, my]], r * 0.08, DARK); break;
    case 'frown': g.beginPath(); g.arc(mx, my + r * 0.2, r * 0.2, Math.PI + 0.5, TAU - 0.5); g.stroke(); break;
    case 'smirk': g.beginPath(); g.moveTo(mx - r * 0.16, my); g.quadraticCurveTo(mx + r * 0.05, my + r * 0.06, mx + r * 0.22, my - r * 0.1); g.stroke(); break;
    case 'wavy': g.beginPath(); for (let i = 0; i <= 16; i++) { const u = i / 16, x = mx - r * 0.24 + u * r * 0.48, y = my + Math.sin(u * TAU + (o.tt || 0) * 14) * r * 0.05; i ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); break;
  }
  if (ex.sweat) { g.fillStyle = '#9fd8ff'; g.beginPath(); g.ellipse(hx - r * 0.6, hy - r * 0.45, r * 0.08, r * 0.13, 0, 0, TAU); g.fill(); }
  g.restore();
}
function zombieFace(g, hx, hy, r, o = {}) {
  const fx = hx + (o.front ? 0 : r * 0.3), fy = hy - r * 0.05;
  g.save(); g.fillStyle = '#ff3b30'; g.shadowColor = '#ff2a1a'; g.shadowBlur = r * 0.6;
  [fx - r * 0.28, fx + r * 0.34].forEach((x) => { g.beginPath(); g.arc(x, fy - r * 0.08, r * 0.15, 0, TAU); g.fill(); });
  g.shadowBlur = 0; g.fillStyle = '#220808'; const open = 0.2 + 0.1 * Math.abs(Math.sin((o.tt || 0) * 3));
  g.beginPath(); g.ellipse(fx + r * 0.05, fy + r * 0.42, r * 0.22, r * open + r * 0.06, 0, 0, TAU); g.fill();
  g.strokeStyle = '#c8d4c0'; g.lineWidth = r * 0.04; g.beginPath(); g.moveTo(fx - r * 0.12, fy + r * 0.34); g.lineTo(fx - r * 0.05, fy + r * 0.44); g.lineTo(fx + r * 0.02, fy + r * 0.34); g.lineTo(fx + r * 0.09, fy + r * 0.44); g.lineTo(fx + r * 0.16, fy + r * 0.34); g.stroke();
  g.restore();
}
const noFace = () => { };

/* ---------- poses ---------- */
const ZARMS = { head: [20, -198], sh: [10, -170], eF: [34, -150], hF: [68, -154], eB: [26, -138], hB: [60, -140] };
function posePack(kind, pose, name, t, ph, talk, poseT) {
  const P = R.POSES; let p, rot = 0, lift = 0;
  if (kind === 'zombie') { const w = R.walkPose(t * 3.2 + ph, { stride: 16, lift: 6, bob: 2, arm: 0 }); p = { ...w, ...ZARMS }; p.hip = w.hip; p.sh = [ZARMS.sh[0], w.hip[1] - 70]; p.head = [ZARMS.head[0], w.hip[1] - 98]; return { p: R.breathe(p, t, 1.5, ph), rot, lift }; }
  if (kind === 'silhouette') { p = R.breathe(P.stand, t, 1, ph); return { p, rot, lift }; }
  switch (pose) {
    case 'walk': p = R.walkPose(t * 5.6 + ph); break;
    case 'run': p = R.walkPose(t * 10.2 + ph, { run: true }); break;
    case 'scared': { const sh = Math.sin(t * 38 + ph); p = R.blendPose(P.ready, P.handsOnHead, 0.5 + 0.5 * Math.sin(t * 1.3)); p = R.breathe(p, t * 4, 1.1 + sh * 0.3, ph); break; }
    case 'crouch': case 'hide': p = R.breathe(P.crouch, t, 1, ph); break;
    case 'sit': p = R.breathe(P.sitBack, t, 1, ph); break;
    case 'point': p = R.breathe(P.point, t, 1, ph); break;
    case 'fall': case 'collapse': case 'dead': { const u = ease.inOut(clamp((t - poseT) / 0.7)); p = R.blendPose(P.fall, P.lie, u); rot = -u * (Math.PI / 2) * 0.96; lift = 0; break; }
    default: {
      const base = R.breathe(P.stand, t, 1, ph);
      if (talk > 0.02) { const k = Math.floor(t * 1.15 + ph) % 3, g = [P.talk, P.explain, P.holdFront][k]; p = R.breathe(R.blendPose(P.stand, g, clamp(talk * 1.3)), t, 1, ph); } else p = base;
    }
  }
  return { p, rot, lift };
}
const EXPR_ALIAS = { shock: 'shocked', afraid: 'scared', terrified: 'scared', panic: 'scared', calm: 'neutral', tired: 'sleepy', anxious: 'nervous', fear: 'scared', serious: 'determined' };
const exprOf = (e) => { e = String(e || 'neutral').toLowerCase(); e = EXPR_ALIAS[e] || e; return R.EXPR[e] ? e : 'neutral'; };

/* ---------- design / outfit ---------- */
function outfitOf(d) {
  if (d.isHero) return { top: 'none' };
  const a = d.accent || '#6a8acf';
  return { top: 'hoodie', color: shade(a, -0.25), legs: '#1c2336', head: d.hat ? 'beanie' : d.hair === 'bun' ? 'bun' : d.hair === 'spiky' ? 'spiky' : 'none', headColor: a };
}

/* ---------- plan (shot composition) ---------- */
const CYCLE = ['medium', 'wide', 'over', 'close', 'low', 'medium', 'wide', 'over'];
function planFor(sc, comp) {
  if (sc._plan) return sc._plan;
  const txt = sc.lines.map((l) => l.text).join(' ').toLowerCase();
  const prev = sc.index > 0 ? comp.scenes[sc.index - 1]._plan : null;
  const emph = sc.lines.some((l) => l.emph);
  const hasZ = sc.events.some((e) => e.type === 'zombies' && e.count > 0);
  const speakers = new Set(sc.lines.map((l) => l.speaker));
  const dialog = sc.cast.filter((c) => !c.isNarrator).length >= 2;
  const bgt = sc.bg.type;
  let kind;
  if (sc.index === 0) kind = emph ? 'close' : 'wide';
  else if (/handle|knob/.test(txt) && /door/.test(txt)) kind = 'handle';
  else if (/peephole/.test(txt)) kind = 'peephole';
  else if (/footstep|walking|climbing|\bsteps\b/.test(txt) && !/\bno footsteps\b/.test(txt) && bgt !== 'stairs' && (sc.seed & 1)) kind = 'feet';
  else if (dialog) kind = 'dialog';
  else if (hasZ) kind = (sc.seed >> 2) & 1 ? 'over' : 'wide';
  else if (emph || /heartbeat|hear your|stopped breathing/.test(txt)) kind = 'close';
  else { let i = (sc.index * 3 + (sc.seed & 7)) % CYCLE.length; kind = CYCLE[i]; for (let k = 0; k < 4 && prev && kind === prev.kind; k++) kind = CYCLE[(++i) % CYCLE.length]; }
  if (prev && prev.kind === kind && kind !== 'dialog' && kind !== 'wide') kind = kind === 'close' ? 'medium' : 'wide';
  let side = ((sc.seed >> 3) & 1) ? 1 : -1; if (prev && prev.side === side) side = -side;
  const insideLift = /(inside|into|enter|stepped in|step into|ride|doors closed|going down|descend)/.test(txt) && /elevator/.test(txt);
  return (sc._plan = { kind, side, inside: insideLift, txt, open: /slightly open|was open|open door|door was open/.test(txt) ? 0.16 : 0, shadows: /someone|inside your|behind you/.test(txt) });
}

/* ---------- buffers ---------- */
let buf = null, grain = null;
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
function ensureBuf(w, h) { if (!buf || buf.width !== w || buf.height !== h) buf = mk(w, h); return buf; }
function grainTiles() {
  if (grain) return grain; grain = [];
  for (let k = 0; k < 4; k++) { const c = mk(270, 480), x = c.getContext('2d'), id = x.createImageData(270, 480); let s = 1234 + k * 999; for (let i = 0; i < id.data.length; i += 4) { s = (s * 1664525 + 1013904223) >>> 0; const v = s >>> 24; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; } x.putImageData(id, 0, 0); grain.push(c); }
  return grain;
}

/* ---------- mood ---------- */
function moodFor(sc, st) {
  const t = sc.bg.type, m = sc.bg.mood || 'night', indoor = ['room', 'door', 'hallway', 'elevator', 'stairs', 'bunker'].includes(t);
  let name = indoor ? (m === 'dusk' || m === 'day' ? 'interiorWarm' : 'interiorCool') : m === 'dusk' ? 'dusk' : m === 'day' ? 'day' : /storm/.test(st.weather || '') ? 'storm' : 'night';
  if (t === 'bunker') name = 'interiorWarm';
  let M = { ...C.mood(name) };
  if (m === 'red') { M.wall = mix(M.wall, '#7a1a1a', 0.45); M.floor = mix(M.floor, '#3a0a0a', 0.4); M.sky = M.sky.map((c) => mix(c, '#7a1a1a', 0.5)); M.practical = '#ff8a6a'; M.rim = '#ff6a5a'; M.fog = mix(M.fog, '#7a1a1a', 0.4); }
  if (m === 'fog') { M.fog = mix(M.fog, '#c0cad8', 0.4); }
  return M;
}

/* ---------- main ---------- */
const OV = () => SV._ov;
let lastStyle = null;
SV.studio = {
  drawFrame(ctx, comp, t, opt) {
    opt = opt || {}; t = clamp(t, 0, Math.max(0, comp.duration - 1e-4));
    const S = comp.settings || {}, styleId = S.style || 'silent';
    if (styleId !== lastStyle) { C.setStyle(styleId); lastStyle = styleId; }
    const sc = SV.sceneAt(comp, t); if (!sc) { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); return; }
    const st = SV.sceneState(sc, t), cam0 = OV().cameraAt(sc, t), plan = planFor(sc, comp), lt = t - sc.start, dur = sc.end - sc.start;
    const cw = ctx.canvas.width, ch = ctx.canvas.height, PX = cw / W; E.PX = PX;
    const b = ensureBuf(cw, ch), g = b.getContext('2d');
    g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.filter = 'none'; g.fillStyle = '#000'; g.fillRect(0, 0, cw, ch); g.setTransform(PX, 0, 0, PX, 0, 0);
    drawScene(g, comp, sc, st, cam0, plan, t, lt, dur);

    // ---- compose to the target with colour grade ----
    const gr = (E.style && E.style.grade) || {};
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.filter = `contrast(${gr.contrast || 1}) saturate(${gr.sat || 1})`; ctx.drawImage(b, 0, 0); ctx.filter = 'none'; ctx.restore();
    // vignette
    ctx.save(); const v = ctx.createRadialGradient(W / 2, H / 2, 420, W / 2, H / 2, 1250); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, `rgba(0,0,0,${gr.vignette ?? 0.55})`); ctx.fillStyle = v; ctx.fillRect(0, 0, W, H); ctx.restore();
    // heartbeat pulse
    const bpm = parseFloat(st.hud.HEART);
    if (bpm > 0) { const env = Math.exp(-(((t * bpm) / 60) % 1) * 7), a = clamp((bpm - 85) / 90) * 0.5 * env; if (a > 0.01) { ctx.save(); const r = ctx.createRadialGradient(W / 2, H / 2, 360, W / 2, H / 2, 1200); r.addColorStop(0, 'rgba(220,10,20,0)'); r.addColorStop(1, 'rgba(220,10,20,.95)'); ctx.globalAlpha = a; ctx.fillStyle = r; ctx.fillRect(0, 0, W, H); ctx.restore(); } }
    if (/storm|lightning/.test(st.weather || '')) { const a = lightningAmt(t, sc.seed); if (a > 0.01) { ctx.fillStyle = `rgba(210,230,255,${0.45 * a})`; ctx.fillRect(0, 0, W, H); } }
    st.flashes.forEach((f) => { const k = 1 - (t - f.t) / f.dur; ctx.fillStyle = f.color; ctx.globalAlpha = clamp(f.amp * k * k); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; });
    if ((gr.grain || 0) > 0) { ctx.save(); ctx.globalAlpha = gr.grain; ctx.globalCompositeOperation = 'overlay'; ctx.drawImage(grainTiles()[Math.floor(t * 30) % 4], 0, 0, W, H); ctx.restore(); }

    OV().drawChoices(ctx, comp, t);
    if (opt.hud !== false) OV().drawHUD(ctx, st, t);
    st.titles.forEach((ev) => OV().drawTitle(ctx, ev, t));
    if (opt.captions !== false) drawCaption(ctx, comp, t);

    // transitions
    if (sc.transition !== 'cut' && lt < 0.32) {
      const k = 1 - lt / 0.32;
      if (sc.transition === 'flash') { ctx.fillStyle = '#fff'; ctx.globalAlpha = k * k; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
      else if (sc.transition === 'glitch' || sc.transition === 'whip') { ctx.globalAlpha = k * 0.7; ctx.fillStyle = '#000'; for (let i = 0; i < 7; i++) { const y = SV.hash(i + Math.floor(t * 30)) * H; ctx.fillRect(0, y, W, 20 + SV.hash(i + 5) * 120); } ctx.globalAlpha = 1; }
      else { ctx.fillStyle = '#000'; ctx.globalAlpha = k; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
    }
    if (t > comp.duration - 0.35) { ctx.fillStyle = '#000'; ctx.globalAlpha = clamp((t - (comp.duration - 0.35)) / 0.35); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
  },
};
function lightningAmt(t, seed) { let a = 0; for (let s = 0; s < 5; s++) { const dt = t - (s * 3.6 + SV.hash(s + 3 + (seed & 15)) * 2.2); if (dt >= 0 && dt < 1.2) a = Math.max(a, Math.exp(-dt * 6.5) * (0.75 + 0.25 * Math.sin(dt * 55))); } return a; }

/* ---------- scene composition ---------- */
function drawScene(g, comp, sc, st, cam0, plan, t, lt, dur) {
  const M = moodFor(sc, st), type = sc.bg.type, seed = sc.seed & 0xffff;
  const base = cam0.z / 1.1, kind = plan.kind;
  // per-shot camera: slow drift always, plus director camera events
  const drift = clamp(lt / Math.max(0.5, dur));
  let zoom = base, cx = -cam0.x, cy = -cam0.y, roll = cam0.rot;
  const A = { wide: [1.0, 0.1], medium: [1.02, 0.12], close: [1.0, 0.14], over: [1.04, 0.08], low: [1.08, 0.1], dialog: [1.0, 0.08], feet: [1.05, 0.1], handle: [1.1, 0.16], peephole: [1.0, 0.1] }[kind] || [1, 0.1];
  zoom *= A[0] + A[1] * ease.inOut(drift) * (plan.side > 0 ? 1 : 0.85); cx += Math.sin(t * 0.6 + seed) * 6 + plan.side * -16 * drift;
  if (kind === 'low') { roll += 0.045 * plan.side; cy += 40; }
  const cam = { x: cx, y: cy, z: zoom, r: roll };
  const L = (d, fn) => layer(g, cam, d, fn);
  const scroll = st.scroll;
  const so = { M, t, lt, seed, FY, scroll, weather: st.weather, sc, st, image: SV.bgImages && sc.bg.name ? SV.bgImages[sc.bg.name] : null };
  const knocks = (comp.sfx || []).filter((s) => /knock|door_slam|bang|hit/.test(s.name));
  so.knock = knocks.reduce((a, k) => { const dt = t - k.t; return dt >= 0 && dt < 0.6 ? a + Math.exp(-dt * 12) * Math.sin(dt * 70) * 6 : a; }, 0);
  so.openAmt = type === 'door' ? plan.open * ease.inOut(prog(lt, 0.1, 0.9)) : 0; so.shadowsBehind = plan.shadows && type === 'door';
  so.inside = plan.inside; so.blinds = (seed & 1) === 0;
  so.floorOffset = 0;
  if (type === 'elevator') so.openAmt = plan.inside ? 1 : /open|waiting|doors/.test(plan.txt) ? ease.inOut(prog(lt, 0.3, 1.4)) : ease.inOut(prog(lt, 0.5, 1.8)) * 0.65;

  const setFn = (kind === 'handle' || kind === 'peephole') ? null : SETS[type] || SETS.room;
  const blurAmt = kind === 'close' ? 14 : kind === 'over' ? 3.5 : kind === 'feet' ? 8 : 0;
  const drawSetOnly = (gg) => { gg.save(); const LL = (d, fn) => layer(gg, cam, d, fn); if (setFn) { if (type === 'custom') SETS.custom(gg, LL, so); else setFn(gg, LL, so); } gg.restore(); };
  if (kind === 'handle') drawHandleShot(g, so, plan, cam, lt, dur);
  else if (kind === 'peephole') drawPeephole(g, so, plan, cam, lt, dur, st);
  else if (blurAmt > 0) blurLayer(g, blurAmt, (gg) => drawSetOnly(gg)); else drawSetOnly(g);

  // atmosphere on the set (behind characters)
  const indoor = ['room', 'door', 'hallway', 'elevator', 'stairs', 'bunker'].includes(type);
  if (/fog|mist/.test(st.weather || '') || (!indoor && type !== 'custom')) FX.fog(g, 1000, 520, M.fog, /fog|mist/.test(st.weather || '') ? 0.5 : 0.22);
  if (indoor) FX.dust(g, t, { seed, count: 40, a: 0.12 });

  // ----- characters -----
  if (kind !== 'handle' && kind !== 'peephole') drawCast(g, comp, sc, st, cam, plan, t, lt, M, so);

  if (!indoor && /rain|storm/.test(st.weather || '')) { FX.rain(g, t, { seed, count: 320, a: 0.28 }); }
  else if (indoor && /storm|rain/.test(st.weather || '')) { /* muffled: none */ }
  if (!indoor && st.weather && /fog|mist/.test(st.weather)) FX.fog(g, 1200, 420, M.fog, 0.45);
}

function castSlots(cast, plan) {
  const n = cast.length;
  if (plan.kind === 'dialog' || n >= 2) return n === 2 ? [{ x: 300, f: 1 }, { x: 780, f: -1 }] : [{ x: 200, f: 1 }, { x: 540, f: 1 }, { x: 880, f: -1 }].slice(0, n);
  return [{ x: 540 + plan.side * (plan.kind === 'wide' ? 220 : plan.kind === 'over' ? -300 : 130), f: plan.side > 0 ? -1 : 1 }];
}

function drawCast(g, comp, sc, st, cam, plan, t, lt, M, so) {
  const S = comp.settings || {}, kind = plan.kind;
  const line = sc.lines.find((l) => t >= l.start && t <= l.end + 0.08);
  const env = line ? clamp((t - line.start) / 0.12) * clamp((line.end + 0.08 - t) / 0.12) : 0, narr = line && line.kind === 'NARRATOR';
  const zl = OV().zombieList(sc, st, t), zSide = st.zombies.length ? (st.zombies[0].side === 'left' ? -1 : 1) : 0;
  const cast = sc.cast.filter((d) => !d.isNarrator || S.narratorOnScreen);
  const slots = castSlots(cast, plan), L = (d, fn) => layer(g, cam, d, fn);
  const items = [];
  cast.forEach((d, i) => {
    const poseEv = st.pose.by[d.name] || st.pose.all;
    const expr = exprOf(st.expr[d.name] || (st.zombies.length ? 'worried' : 'neutral'));
    const speaking = line && (line.speaker === d.name || (d.isNarrator && narr) || (narr && S.narratorLips !== false && !S.narratorOnScreen && d.isHero));
    const talk = speaking ? env : 0, sl = slots[i] || slots[0];
    const facing = zSide && cast.length === 1 ? (zSide < 0 ? -1 : 1) : sl.f;
    const asset = SV.charAssets[d.name];
    items.push({ depth: 5000 + i, fn: () => drawHero(g, { d, i, sl, facing, expr, talk, pose: poseEv.v, poseT: poseEv.t, asset, plan, t, lt, M, L, kind, so }) });
  });
  if (kind !== 'close' && kind !== 'feet' && kind !== 'over') {
    zl.forEach((z) => items.push({ depth: z.depth, fn: () => L(1, (gg) => drawZombie(gg, z, t, M, plan)) }));
  } else if (kind === 'over' || kind === 'close') {
    zl.forEach((z) => items.push({ depth: z.depth, fn: () => L(0.92, (gg) => drawZombie(gg, z, t, M, plan)) }));
  }
  items.sort((a, b) => a.depth - b.depth).forEach((it) => it.fn());
}

function drawZombie(g, z, t, M, plan) {
  const sil = z.kind === 'silhouette', s = z.scale * 3.0, y = z.y + 150 + (plan.kind === 'wide' ? 40 : 0);
  const ink = sil ? '#04070c' : '#8fb59a';
  R.drawFigure(g, { x: z.x, y, s, facing: z.facing, pose: R.POSES.stand, t, ...zpose(z, t), outfit: { top: 'none' }, ink, inkFar: sil ? '#04070c' : '#5c7a66', headInk: ink, outline: sil ? null : 'rgba(3,6,12,.8)', faceFn: sil ? noFace : (gg, a, b, r, o) => zombieFace(gg, a, b, r, { ...o, tt: t + z.phase }), rim: { color: sil ? alpha(M.rim, 0.55) : M.rim, dir: [-0.7, -0.5], w: 3.5 }, shadow: !sil, alpha: sil ? 0.96 : 1 });
}
function zpose(z, t) { const k = posePack(z.kind === 'silhouette' ? 'silhouette' : 'zombie', 'walk', 'z', t, z.phase, 0, 0); if (z.kind === 'silhouette') { const w = R.walkPose(t * 2.2 + z.phase, { stride: 12, lift: 5, bob: 1 }); return { pose: { ...w, ...ZARMS, head: [8, w.hip[1] - 100], sh: [3, w.hip[1] - 72] } }; } return { pose: k.p }; }

function drawHero(g, a) {
  const { d, sl, facing, expr, talk, pose, poseT, asset, plan, t, lt, M, L, kind } = a;
  const hero = !!d.isHero, scarf = hero ? '#d8323a' : null;
  const multi = a.sl && plan.kind === 'dialog';
  const cfg = {
    wide: { s: 1.6, y: 1390 }, medium: { s: 2.55, y: 1560 }, low: { s: 2.9, y: 1790 }, over: { s: 3.3, y: 1930 }, dialog: { s: 2.3, y: 1500 }, feet: { s: 5.6, y: 1760 }, close: { s: 0, y: 0 },
  }[kind] || { s: 2.4, y: 1520 };
  const sc = (d.scale || 1) * cfg.s;
  const ink = hero ? '#f3f7ff' : '#d5deef', dim = kind === 'over';
  const ph = a.i * 1.7;
  const k = posePack('human', pose, d.name, t, ph, talk, poseT);
  if (kind === 'close') {
    if (asset && asset.slots && asset.slots.idle) { L(1, (gg) => { gg.save(); OV().drawSprite(gg, { x: 540, y: 2150, scale: 2.4, facing: 1, design: d, kind: 'hero', pose, poseT, t, phase: ph, expr: expr, talk }, asset); gg.restore(); }); return; }
    L(1, (gg) => {
      const rim = M.rim, bob = Math.sin(t * 1.6) * 6 + (pose === 'scared' ? Math.sin(t * 40) * 4 : 0);
      R.bigFace(gg, 540 + plan.side * -30, 960 + bob, 330, { outfit: outfitOf(d), expr, talk, blink: (t % 3.4) < 0.11, look: [Math.sin(t * 0.7) * 0.4, 0], rimColor: alpha(rim, 0.9), rimSide: plan.side, tilt: Math.sin(t * 0.5) * 0.03 + (pose === 'scared' ? Math.sin(t * 30) * 0.01 : 0), ink, faceFn: (g2, x, y, r, o) => heroFace(g2, x, y, r, { ...o, tt: t }), scarf });
    });
    return;
  }
  if (asset && asset.slots && asset.slots.idle) { L(1, (gg) => { OV().drawSprite(gg, { x: sl.x, y: cfg.y, scale: sc * 0.4, facing, design: d, kind: 'hero', pose, poseT, t, phase: ph, expr, talk }, asset); }); return; }
  L(kind === 'over' ? 1.18 : 1, (gg) => {
    const dimAlpha = dim ? 0.82 : 1;
    gg.save(); if (dim) { gg.globalAlpha = 1; }
    R.drawFigure(gg, { x: sl.x, y: cfg.y, s: sc, facing, pose: k.p, rot: k.rot, t, outfit: outfitOf(d), expr, talk, blink: (t + ph) % 3.4 < 0.11, ink: dim ? '#2c3652' : ink, inkFar: dim ? '#1c2438' : '#aab8d2', headInk: dim ? '#2c3652' : ink, outline: 'rgba(3,6,12,.85)', faceFn: (g2, x, y, r, o) => heroFace(g2, x, y, r, { ...o, tt: t + ph }), scarf, rim: { color: alpha(M.rim, 0.9), dir: [-0.8, -0.5], w: 4.5 }, shadow: kind !== 'over' });
    gg.restore();
  });
}

/* ---------- insert shots ---------- */
function drawHandleShot(g, so, plan, cam, lt, dur) {
  const { M, t, seed } = so, L = (d, fn) => layer(g, cam, d, fn);
  L(0.9, (gg) => {
    const col = mix(M.wall, '#7a573a', 0.55);
    gg.fillStyle = linGrad(gg, 0, 0, W, 0, [shade(col, -0.25), col, shade(col, -0.1)]); gg.fillRect(-W, -H, W * 3, H * 3);
    gg.fillStyle = alpha('#000', 0.18); for (let y = -400; y < 2400; y += 18) gg.fillRect(-W, y + Math.sin(y * 0.13) * 3, W * 3, 2);
    rr(gg, 120, 320, 840, 1180, 18); gg.fillStyle = shade(col, -0.1); gg.fill(); gg.strokeStyle = shade(col, 0.2); gg.lineWidth = 6; gg.stroke();
    const u = ease.inOut(prog(lt, dur * 0.3, dur * 0.55)), hx = 760, hy = 940;
    // gap of light opening at the door edge
    if (plan.open > 0) { const gw = 8 + 70 * u; gg.fillStyle = linGrad(gg, 960, 0, 960 + gw, 0, [alpha(M.practical, 0.9), alpha(M.dark, 1)]); gg.fillRect(960, 320, gw, 1180); glow(gg, 970, 900, 700, M.practical, 0.25 * u); }
    circle(gg, hx, hy, 74, '#b89a4a'); ring(gg, hx, hy, 74, 8, '#7a622a');
    gg.save(); gg.translate(hx, hy); gg.rotate(u * 0.5); rr(gg, -250, -26, 290, 52, 26); gg.fillStyle = '#d8bb6a'; gg.fill(); gg.fillStyle = 'rgba(255,255,255,.35)'; gg.fillRect(-230, -18, 250, 8); gg.restore();
    circle(gg, hx, hy + 190, 30, '#a88a3a'); rr(gg, hx - 8, hy + 190, 16, 26, 4); gg.fillStyle = '#05080e'; gg.fill();
    glow(gg, 300, 500, 900, M.practical, 0.14);
  });
}
function drawPeephole(g, so, plan, cam, lt, dur, st) {
  const { M, t, seed } = so, L = (d, fn) => layer(g, cam, d, fn);
  L(0.9, (gg) => {
    gg.fillStyle = shade(M.wall, -0.4); gg.fillRect(-W, -H, W * 3, H * 3);
    gg.save(); gg.beginPath(); gg.arc(540, 900, 430, 0, TAU); gg.clip();
    gg.fillStyle = linGrad(gg, 0, 460, 0, 1340, [shade(M.wall, -0.1), M.practical]); gg.fillRect(100, 460, 880, 880);
    // far hallway end
    glow(gg, 540, 880, 420, M.practical, 0.5); const x = 540 + Math.sin(t * 0.7) * 160;
    gg.fillStyle = '#05070c'; gg.beginPath(); gg.ellipse(x, 960, 60, 190, 0, 0, TAU); gg.fill(); circle(gg, x, 760, 46, '#05070c');
    gg.restore(); ring(gg, 540, 900, 430, 36, '#8a7a4a'); ring(gg, 540, 900, 470, 10, '#05080e');
  });
}

/* ---------- captions (GrowKaz style: Fredoka, 3-4 word groups, gold active word) ---------- */
function drawCaption(ctx, comp, t) {
  const ch = comp.captionChunks; let lo = 0, hi = ch.length - 1, f = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (ch[m].start <= t) { f = m; lo = m + 1; } else hi = m - 1; }
  if (f < 0 || t >= ch[f].end + 0.05) return;
  const c = ch[f], words = c.words.map((w) => w.w.toUpperCase()), ui = C.S().ui;
  const size = c.emph ? 90 : 78, hiCol = ui.gold, base = c.emph ? '#ff5a4d' : '#ffffff';
  ctx.save();
  let rows = [words.map((_, i) => i)];
  const width = (row, sz) => row.reduce((a, i) => a + measure(ctx, words[i], sz), 0) + sz * 0.42 * (row.length - 1);
  if (width(rows[0], size) > W * 0.9 && words.length > 1) { let best = 1, diff = 1e9; for (let k = 1; k < words.length; k++) { const a = width(words.slice(0, k).map((_, i) => i), size), b = width(words.slice(k).map((_, i) => i + k), size); if (Math.abs(a - b) < diff) { diff = Math.abs(a - b); best = k; } } rows = [words.slice(0, best).map((_, i) => i), words.slice(best).map((_, i) => i + best)]; }
  const sz = size * Math.min(1, (W * 0.9) / Math.max(...rows.map((r) => width(r, size))));
  const cy = H * 0.79, pop = 0.92 + 0.08 * ease.inOut(prog(t, c.start, c.start + 0.12));
  ctx.translate(W / 2, cy); ctx.scale(pop, pop);
  rows.forEach((row, ri) => {
    const y = (ri - (rows.length - 1) / 2) * sz * 1.18, tw = width(row, sz); let x = -tw / 2;
    row.forEach((i) => {
      const w = c.words[i], act = t >= w.start && t < w.end, ww = measure(ctx, words[i], sz), p = act ? 1 + 0.1 * ease.inOut(prog(t, w.start, w.start + 0.1)) : 1;
      ctx.save(); ctx.translate(x + ww / 2, y); ctx.scale(p, p); text(ctx, words[i], 0, 0, { size: sz, color: act ? hiCol : base, stroke: sz * 0.17, strokeColor: 'rgba(0,0,0,.88)', glow: act ? 18 : 0, glowColor: alpha(hiCol, 0.55) }); ctx.restore();
      x += ww + sz * 0.42;
    });
  });
  ctx.restore();
}

loadFonts().then(() => { SV.studioReady = true; (SV._studioWaiters || []).forEach((r) => r()); SV._studioWaiters = []; });
