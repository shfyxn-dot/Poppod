PodPop v5 - bottom AirPods connection popup.

Build on GitHub (no computer): commit this zip + .github/workflows/build.yml, then open the
repo's Releases page and download app-debug.apk.

Local build: gradle assembleDebug  (JDK 17, Gradle 8.9, AGP 8.7.3)

Popup: bundled pro2.png (no network at runtime), light/dark follows the system, shown near the
bottom, X button closes it, auto-dismiss after MonitorService.POPUP_TIMEOUT_MS (3 s).
Connection = real A2DP/Headset profile connection to 41:42:84:7B:08:D6. "Test popup now" checks
the live connection and shows "AirPods not connected" otherwise.
Battery shows only values Android reports; unavailable = empty outline. Case is never invented.
