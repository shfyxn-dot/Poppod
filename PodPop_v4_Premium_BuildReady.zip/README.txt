PodPop v2.6 - animated bottom AirPods connection popup.

Build on GitHub (no computer): commit this zip + .github/workflows/build.yml, then open the
repo's Releases page and download app-debug.apk.
Local build: gradle assembleDebug  (JDK 17, Gradle 8.9, AGP 8.7.3)

Popup: bundled pro2.png, light/dark follows the system, bottom of the screen, X closes it,
auto-dismiss after MonitorService.POPUP_TIMEOUT_MS (3 s). Hold the popup to pause the timer,
swipe it down to dismiss. Connection = real A2DP/Headset profile connection to 41:42:84:7B:08:D6.
Battery shows only values Android reports; unavailable = empty outline. The case is never invented.
