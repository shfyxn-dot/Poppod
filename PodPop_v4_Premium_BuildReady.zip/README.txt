PodPop v2.7

Based on the v2.4 popup (small iOS-style card at the bottom, auto-dismiss 3 s).
- Floating AirPods: pro2_cutout.png (transparent cut-out of pro2.png) floats gently over a fixed
  gradient backdrop, so no edge of the picture ever moves against the card.
- Stop button in the app and a Stop action in the notification: stops monitoring, removes the
  notification, and stays stopped after a reboot until you press Start again.
- Status line on the main screen shows whether PodPop is running.

Build on GitHub: commit this zip + .github/workflows/build.yml, then download app-debug.apk from Releases.
