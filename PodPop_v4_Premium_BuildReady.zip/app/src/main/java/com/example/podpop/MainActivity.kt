package com.example.podpop

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private var pendingTest = false
    private val statusView: TextView by lazy { TextView(this) }

    @Suppress("DEPRECATION")
    private fun isServiceRunning(): Boolean {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        return am.getRunningServices(Int.MAX_VALUE).any { it.service.className == MonitorService::class.java.name }
    }

    private fun refreshStatus() {
        if (isServiceRunning()) {
            statusView.text = "● PodPop is running"
            statusView.setTextColor(Color.rgb(48, 209, 88))
        } else {
            statusView.text = "● PodPop is stopped"
            statusView.setTextColor(Color.rgb(255, 159, 10))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val foreground = if (isDark) Color.WHITE else Color.rgb(30, 30, 34)
        val muted = if (isDark) Color.rgb(170, 170, 178) else Color.rgb(100, 100, 108)
        val background = if (isDark) Color.rgb(12, 12, 14) else Color.rgb(248, 248, 250)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(20), dp(28), dp(20), dp(24))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.podpop_logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        logo.contentDescription = "PodPop logo"
        val logoLp = LinearLayout.LayoutParams(dp(110), dp(110))
        logoLp.bottomMargin = dp(10)
        root.addView(logo, logoLp)

        val title = TextView(this)
        title.text = "PodPop"
        title.textSize = 30f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(foreground)
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "A premium AirPods connection popup."
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER
        subtitle.setTextColor(muted)
        subtitle.setPadding(0, dp(6), 0, dp(20))
        root.addView(subtitle)

        statusView.textSize = 14f
        statusView.gravity = Gravity.CENTER
        statusView.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        statusView.setPadding(0, 0, 0, dp(14))
        root.addView(statusView)

        addAction(root, "1. Allow display over other apps", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addAction(root, "2. Allow Bluetooth access", false) {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12)
            } else {
                startMonitor()
            }
        }
        addAction(root, "3. Start PodPop", false) { startMonitor() }
        addAction(root, "4. Allow background activity (battery)", false) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                // Settings screen not available on this phone.
            }
        }
        addAction(root, "Test popup now", true) { startMonitor(true) }
        addAction(root, "Stop PodPop", false, Color.rgb(176, 48, 48)) {
            PodPrefs.setAutoStart(this, false)
            stopService(Intent(this, MonitorService::class.java))
            statusView.postDelayed({ refreshStatus() }, 400)
        }

        val info = TextView(this)
        info.text = "Selected device: AirPods Pro\nBluetooth ID: 41:42:84:7B:08:D6\n\n" +
            "Battery is shown only when Android receives it from your earbuds. " +
            "The case battery is shown as empty because these earbuds don't report it."
        info.textSize = 13f
        info.setTextColor(Color.rgb(145, 145, 153))
        info.setPadding(dp(2), dp(18), dp(2), 0)
        root.addView(info)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(background)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addAction(root: LinearLayout, label: String, primary: Boolean, tint: Int = 0, action: () -> Unit) {
        val button = Button(this)
        button.text = label
        button.isAllCaps = false
        button.textSize = 14f
        button.setTextColor(if (primary) Color.WHITE else Color.rgb(235, 235, 240))
        button.backgroundTintList = ColorStateList.valueOf(
            if (tint != 0) tint else if (primary) Color.rgb(48, 112, 245) else Color.rgb(58, 58, 64)
        )
        button.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
        lp.bottomMargin = dp(9)
        root.addView(button, lp)
    }

    private fun startMonitor(test: Boolean = false) {
        pendingTest = test
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12)
            return
        }
        PodPrefs.setAutoStart(this, true)
        val i = Intent(this, MonitorService::class.java).putExtra(MonitorService.EXTRA_TEST, test)
        startForegroundService(i)
        statusView.postDelayed({ refreshStatus() }, 600)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 12 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startMonitor(pendingTest)
        }
    }
}
