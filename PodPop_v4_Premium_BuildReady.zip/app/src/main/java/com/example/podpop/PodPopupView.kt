package com.example.podpop

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Bottom connection popup. Uses the bundled pro2.png artwork (no network at runtime).
 * Follows the system light/dark theme. Battery values are shown only when Android reports them;
 * the case level is never available from these earbuds, so it is always shown as empty.
 */
class PodPopupView(context: Context, initialBattery: Int, private val onClose: () -> Unit) : FrameLayout(context) {

    private val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val card = FrameLayout(context)
    private val earBattery = BatteryView(context, dark)
    private val earText = TextView(context)
    private var floatAnimator: ValueAnimator? = null
    private lateinit var floatTarget: View

    init {
        val cardColor = if (dark) Color.rgb(46, 45, 51) else Color.rgb(247, 247, 249)
        val primary = if (dark) Color.WHITE else Color.rgb(28, 28, 32)
        val secondary = if (dark) Color.rgb(165, 165, 173) else Color.rgb(110, 110, 118)

        // Transparent margin so the card shadow is not clipped by the overlay window.
        setPadding(dp(16f), dp(10f), dp(16f), dp(22f))
        clipToPadding = false
        clipChildren = false

        card.background = GradientDrawable().apply {
            setColor(cardColor)
            cornerRadius = dp(28f).toFloat()
            setStroke(dp(1f), if (dark) 0x26FFFFFF else 0x14000000)
        }
        card.elevation = dp(10f).toFloat()
        card.clipToOutline = true

        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

        // --- Artwork ---
        // The backdrop lives on the hero panel; only the transparent cut-out floats above it,
        // so no edge of the picture ever slides against the card.
        val image = ImageView(context).apply {
            setImageResource(R.drawable.pro2_cutout)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "AirPods and charging case"
        }
        floatTarget = image
        val hero = FrameLayout(context)
        hero.clipChildren = false
        hero.setPadding(0, dp(8f), 0, dp(6f))
        hero.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(70, 69, 75), if (dark) cardColor else Color.rgb(54, 53, 59))
        )
        hero.addView(image, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        if (dark) {
            column.addView(hero, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        } else {
            // Light theme: show the hero as a rounded inset panel.
            hero.clipToOutline = true
            hero.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(20f).toFloat())
                }
            }
            val lp = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(12f), dp(12f), dp(12f), 0)
            column.addView(hero, lp)
        }

        // --- Title ---
        column.addView(TextView(context).apply {
            text = "AirPods Pro"
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(primary)
            gravity = Gravity.CENTER
            setPadding(0, dp(6f), 0, 0)
        })
        column.addView(TextView(context).apply {
            text = "Connected"
            textSize = 12f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            setPadding(0, dp(1f), 0, dp(10f))
        })

        // --- Batteries, centred below the artwork ---
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12f), 0, dp(12f), dp(18f))
        }
        earText.apply {
            textSize = 15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(primary)
            setPadding(dp(8f), 0, 0, 0)
        }
        row.addView(batteryItem("Earbuds", earBattery, earText, secondary))

        val caseBattery = BatteryView(context, dark)
        val caseText = TextView(context).apply {
            text = "—"
            textSize = 15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(secondary)
            setPadding(dp(8f), 0, 0, 0)
        }
        val caseItem = batteryItem("Case", caseBattery, caseText, secondary)
        val caseLp = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        caseLp.leftMargin = dp(26f)
        row.addView(caseItem, caseLp)
        column.addView(row)

        card.addView(column, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        // --- Close button (top right) ---
        val close = CloseButton(context)
        close.contentDescription = "Close popup"
        close.isClickable = true
        close.setOnClickListener { onClose() }
        card.addView(close, LayoutParams(dp(44f), dp(44f), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4f)
            rightMargin = dp(4f)
        })

        addView(card, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        setBattery(initialBattery)
    }

    private fun batteryItem(label: String, battery: BatteryView, value: TextView, labelColor: Int): LinearLayout {
        val item = LinearLayout(context)
        item.orientation = LinearLayout.HORIZONTAL
        item.gravity = Gravity.CENTER_VERTICAL
        item.addView(TextView(context).apply {
            text = label
            textSize = 12f
            setTextColor(labelColor)
            setPadding(0, 0, dp(8f), 0)
        })
        item.addView(battery, LinearLayout.LayoutParams(dp(30f), dp(14f)))
        item.addView(value)
        return item
    }

    /** level 0..100 = real reading; anything else = unavailable (empty outline, no percentage). */
    fun setBattery(level: Int) {
        val valid = level in 0..100
        earBattery.level = if (valid) level else -1
        earText.text = if (valid) "$level%" else "—"
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        card.alpha = 0f
        card.translationY = dp(28f).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(260).start()

        // Gentle floating motion: a sine wave, so it starts at rest and loops without any jump.
        floatAnimator?.cancel()
        val bob = ValueAnimator.ofFloat(0f, (2.0 * Math.PI).toFloat())
        bob.duration = 3200
        bob.startDelay = 250
        bob.repeatCount = ValueAnimator.INFINITE
        bob.interpolator = LinearInterpolator()
        bob.addUpdateListener { a ->
            val phase = a.animatedValue as Float
            floatTarget.translationY = dp(4f).toFloat() * kotlin.math.sin(phase)
        }
        floatAnimator = bob
        bob.start()
    }

    override fun onDetachedFromWindow() {
        floatAnimator?.cancel()
        floatAnimator = null
        card.animate().cancel()
        super.onDetachedFromWindow()
    }
}

/** Battery outline with fill. level < 0 draws an empty outline. */
private class BatteryView(context: Context, private val dark: Boolean) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    var level: Int = -1
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val stroke = 1.6f * d
        val nubW = 2.6f * d
        val bodyRight = w - nubW - 0.8f * d
        val outline = if (dark) Color.argb(205, 255, 255, 255) else Color.argb(185, 40, 40, 46)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        paint.color = outline
        rect.set(stroke / 2f, stroke / 2f, bodyRight - stroke / 2f, h - stroke / 2f)
        canvas.drawRoundRect(rect, 4.2f * d, 4.2f * d, paint)

        paint.style = Paint.Style.FILL
        rect.set(bodyRight + 0.8f * d, h * 0.34f, w, h * 0.66f)
        canvas.drawRoundRect(rect, 1.3f * d, 1.3f * d, paint)

        if (level in 0..100) {
            val pad = stroke + 1.3f * d
            val left = pad
            val maxRight = bodyRight - pad
            val right = left + (maxRight - left) * level / 100f
            paint.color = if (level <= 20) Color.rgb(255, 69, 58) else Color.rgb(48, 209, 88)
            rect.set(left, pad, kotlin.math.max(right, left + 1.5f * d), h - pad)
            canvas.drawRoundRect(rect, 2.4f * d, 2.4f * d, paint)
        }
    }
}

/** Round close button with a drawn X, so it never depends on a font glyph. */
private class CloseButton(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(150, 20, 20, 24)
        canvas.drawCircle(cx, cy, 13f * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 1.8f * d
        paint.color = Color.WHITE
        val a = 4.2f * d
        canvas.drawLine(cx - a, cy - a, cx + a, cy + a, paint)
        canvas.drawLine(cx - a, cy + a, cx + a, cy - a, paint)
    }
}
