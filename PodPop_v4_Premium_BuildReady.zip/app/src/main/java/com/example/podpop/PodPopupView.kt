package com.example.podpop

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Bottom connection popup styled like the iOS AirPods card.
 *
 * - Bundled pro2.png artwork (no network at runtime), light/dark follows the system theme.
 * - Battery values are shown only when Android reports them; the case level is never reported by
 *   these earbuds, so it is always shown as empty.
 * - Animations: springy entrance with staggered content, floating artwork, one-time light sweep,
 *   battery fill + count-up, smooth exit, swipe-down to dismiss, timer line that pauses on touch.
 */
class PodPopupView(
    context: Context,
    initialBattery: Int,
    private val timeoutMs: Long,
    private val onClose: () -> Unit,
    private val onHold: (Boolean) -> Unit
) : FrameLayout(context) {

    private val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val card = FrameLayout(context)
    private val titleView = TextView(context)
    private val artTarget: View
    private val shine: ShineView? 
    private val batteryRow = LinearLayout(context)
    private val earBattery = BatteryView(context, dark)
    private val earText = TextView(context)
    private val timerLine = TimerLine(context, dark)

    private var floatAnimator: ValueAnimator? = null
    private var batteryAnimator: ValueAnimator? = null
    private var timerAnimator: ValueAnimator? = null
    private var shownLevel = -1f
    private var dismissing = false
    private var detached = false

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var downY = 0f
    private var dragging = false

    init {
        // Dark card colours are sampled from pro2.png: lighter at the top, darker at the bottom.
        val cardColor = if (dark) Color.rgb(71, 70, 76) else Color.rgb(247, 247, 249)
        val primary = if (dark) Color.WHITE else Color.rgb(28, 28, 32)
        val secondary = if (dark) Color.rgb(165, 165, 173) else Color.rgb(110, 110, 118)

        // Transparent margin so the card shadow is not clipped by the overlay window.
        setPadding(dp(14f), dp(8f), dp(14f), dp(20f))
        clipToPadding = false
        clipChildren = false

        card.background = GradientDrawable().apply {
            setColor(cardColor)
            cornerRadius = dp(30f).toFloat()
            setStroke(dp(1f), if (dark) 0x22FFFFFF else 0x14000000)
        }
        card.elevation = dp(12f).toFloat()
        card.clipToOutline = true

        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

        // --- Title ---
        titleView.apply {
            text = "AirPods Pro"
            textSize = 22f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(primary)
            gravity = Gravity.CENTER
            setPadding(0, dp(20f), 0, dp(4f))
        }
        column.addView(titleView)

        // --- Artwork ---
        val image = ImageView(context).apply {
            setImageResource(R.drawable.pro2)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "AirPods and charging case"
        }
        if (dark) {
            // Feather the artwork's left/right edges into the card so no hard border shows.
            val art = FrameLayout(context)
            art.addView(image, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
            val solid = Color.rgb(64, 63, 68)
            val clear = Color.argb(0, 64, 63, 68)
            art.addView(edge(GradientDrawable.Orientation.LEFT_RIGHT, solid, clear),
                LayoutParams(dp(18f), LayoutParams.MATCH_PARENT, Gravity.START))
            art.addView(edge(GradientDrawable.Orientation.RIGHT_LEFT, solid, clear),
                LayoutParams(dp(18f), LayoutParams.MATCH_PARENT, Gravity.END))
            val sheen = ShineView(context)
            art.addView(sheen, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            shine = sheen
            artTarget = art
            column.addView(art, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        } else {
            // Light theme: show the artwork as a rounded inset panel.
            image.clipToOutline = true
            image.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(20f).toFloat())
                }
            }
            val lp = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(14f), dp(8f), dp(14f), 0)
            column.addView(image, lp)
            shine = null
            artTarget = image
        }

        // --- Batteries: one under the earbuds (left), one under the case (right) ---
        batteryRow.apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 1f
            setPadding(0, dp(6f), 0, dp(20f))
        }
        if (dark) {
            batteryRow.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(55, 55, 59), Color.rgb(44, 43, 48))
            )
        }
        earText.apply {
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(primary)
            gravity = Gravity.CENTER
            setPadding(0, dp(6f), 0, 0)
        }
        batteryRow.addView(batteryColumn(earBattery, earText),
            LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 0.62f))

        val caseBattery = BatteryView(context, dark)
        val caseText = TextView(context).apply {
            text = "—"
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(secondary)
            gravity = Gravity.CENTER
            setPadding(0, dp(6f), 0, 0)
        }
        batteryRow.addView(batteryColumn(caseBattery, caseText),
            LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 0.20f))
        batteryRow.addView(View(context), LinearLayout.LayoutParams(0, 1, 0.18f))
        column.addView(batteryRow)

        card.addView(column, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        // --- Remaining-time line along the bottom edge ---
        card.addView(timerLine, LayoutParams(LayoutParams.MATCH_PARENT, dp(2.5f), Gravity.BOTTOM))

        // --- Close button (top right) ---
        val close = CloseButton(context, dark)
        close.contentDescription = "Close popup"
        close.isClickable = true
        close.setOnClickListener { onClose() }
        card.addView(close, LayoutParams(dp(48f), dp(48f), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(8f)
            rightMargin = dp(8f)
        })

        addView(card, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        // Start hidden; onAttachedToWindow plays the entrance.
        card.alpha = 0f
        card.translationY = dp(140f).toFloat()
        card.scaleX = 0.94f
        card.scaleY = 0.94f
        titleView.alpha = 0f
        titleView.translationY = dp(10f).toFloat()
        artTarget.alpha = 0f
        artTarget.scaleX = 0.9f
        artTarget.scaleY = 0.9f
        batteryRow.alpha = 0f

        // Show the first reading with a count-up once the row has appeared.
        if (initialBattery in 0..100) {
            earBattery.level = 0f
            earText.text = "0 %"
        } else {
            earText.text = "—"
        }
        applyBattery(initialBattery, 420L)
    }

    private fun edge(orientation: GradientDrawable.Orientation, from: Int, to: Int): View {
        val v = View(context)
        v.background = GradientDrawable(orientation, intArrayOf(from, to))
        return v
    }

    private fun batteryColumn(battery: BatteryView, value: TextView): LinearLayout {
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(battery, LinearLayout.LayoutParams(dp(38f), dp(18f)))
        col.addView(value, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        return col
    }

    // ---------- battery ----------

    /** level 0..100 = real reading; anything else = unavailable (empty outline, no percentage). */
    fun setBattery(level: Int) {
        applyBattery(level, 0L)
    }

    private fun applyBattery(level: Int, delayMs: Long) {
        batteryAnimator?.cancel()
        if (level !in 0..100) {
            shownLevel = -1f
            earBattery.level = -1f
            earText.text = "—"
            return
        }
        val from = if (shownLevel < 0f) 0f else shownLevel
        val anim = ValueAnimator.ofFloat(from, level.toFloat())
        anim.duration = 750
        anim.startDelay = delayMs
        anim.interpolator = DecelerateInterpolator(1.6f)
        anim.addUpdateListener { a ->
            val v = a.animatedValue as Float
            shownLevel = v
            earBattery.level = v
            earText.text = "${v.toInt()} %"
        }
        batteryAnimator = anim
        anim.start()
    }

    // ---------- timer line ----------

    /** Restarts the visual countdown. The service owns the real dismissal timer. */
    fun restartTimer(ms: Long) {
        timerAnimator?.cancel()
        val anim = ValueAnimator.ofFloat(1f, 0f)
        anim.duration = ms
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener { a -> timerLine.value = a.animatedValue as Float }
        timerAnimator = anim
        anim.start()
    }

    fun holdTimer() {
        timerAnimator?.cancel()
    }

    // ---------- show / hide animations ----------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        detached = false
        card.animate().cancel()
        card.animate()
            .alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(480)
            .setInterpolator(OvershootInterpolator(0.85f))
            .start()
        titleView.animate().alpha(1f).translationY(0f)
            .setStartDelay(150).setDuration(340).setInterpolator(DecelerateInterpolator()).start()
        artTarget.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setStartDelay(110).setDuration(520).setInterpolator(DecelerateInterpolator(1.4f)).start()
        batteryRow.animate().alpha(1f)
            .setStartDelay(300).setDuration(360).setInterpolator(DecelerateInterpolator()).start()

        // Gentle floating motion on the artwork.
        floatAnimator?.cancel()
        val bob = ValueAnimator.ofFloat(0f, 1f)
        bob.duration = 2600
        bob.repeatCount = ValueAnimator.INFINITE
        bob.repeatMode = ValueAnimator.REVERSE
        bob.interpolator = AccelerateDecelerateInterpolator()
        bob.addUpdateListener { a ->
            val v = a.animatedValue as Float
            artTarget.translationY = dp(3f).toFloat() * (v - 0.5f) * 2f
        }
        floatAnimator = bob
        bob.start()

        // One light sweep across the artwork (dark theme).
        shine?.let { s ->
            val sweep = ValueAnimator.ofFloat(0f, 1f)
            sweep.duration = 1000
            sweep.startDelay = 560
            sweep.interpolator = AccelerateDecelerateInterpolator()
            sweep.addUpdateListener { a -> s.progress = a.animatedValue as Float }
            sweep.start()
        }

        restartTimer(timeoutMs)
    }

    /** Slides the popup away, then runs [endAction] (which removes the window). */
    fun dismissAnimated(endAction: () -> Unit) {
        if (dismissing) return
        dismissing = true
        timerAnimator?.cancel()
        floatAnimator?.cancel()
        card.animate().cancel()
        card.animate()
            .translationY(card.translationY + dp(150f))
            .alpha(0f).scaleX(0.97f).scaleY(0.97f)
            .setStartDelay(0)
            .setDuration(240)
            .setInterpolator(AccelerateInterpolator(1.3f))
            .withEndAction { if (!detached) endAction() }
            .start()
    }

    override fun onDetachedFromWindow() {
        detached = true
        floatAnimator?.cancel()
        batteryAnimator?.cancel()
        timerAnimator?.cancel()
        card.animate().cancel()
        titleView.animate().cancel()
        artTarget.animate().cancel()
        batteryRow.animate().cancel()
        super.onDetachedFromWindow()
    }

    // ---------- touch: hold to pause the timer, swipe down to dismiss ----------

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downY = ev.rawY
                dragging = false
                onHold(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && ev.rawY - downY > touchSlop) dragging = true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) onHold(false)
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downY = ev.rawY
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dy = kotlin.math.max(0f, ev.rawY - downY)
                if (dy > touchSlop) dragging = true
                if (dragging) {
                    card.translationY = dy
                    card.alpha = (1f - dy / dp(260f)).coerceIn(0.25f, 1f)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val dy = card.translationY
                val wasDragging = dragging
                dragging = false
                if (wasDragging && ev.actionMasked == MotionEvent.ACTION_UP && dy > dp(60f)) {
                    onClose()
                } else {
                    card.animate().translationY(0f).alpha(1f).setDuration(220)
                        .setInterpolator(OvershootInterpolator(1.2f)).start()
                    onHold(false)
                }
                return true
            }
        }
        return true
    }
}

/** Battery outline with fill. level < 0 draws an empty outline. */
private class BatteryView(context: Context, private val dark: Boolean) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    var level: Float = -1f
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val stroke = 1.5f * d
        val nubW = 2.8f * d
        val bodyRight = w - nubW - 0.8f * d
        val outline = if (dark) Color.argb(150, 255, 255, 255) else Color.argb(150, 40, 40, 46)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        paint.color = outline
        rect.set(stroke / 2f, stroke / 2f, bodyRight - stroke / 2f, h - stroke / 2f)
        canvas.drawRoundRect(rect, 5f * d, 5f * d, paint)

        paint.style = Paint.Style.FILL
        rect.set(bodyRight + 0.8f * d, h * 0.34f, w, h * 0.66f)
        canvas.drawRoundRect(rect, 1.4f * d, 1.4f * d, paint)

        if (level >= 0f) {
            val pad = stroke + 1.4f * d
            val left = pad
            val maxRight = bodyRight - pad
            val right = left + (maxRight - left) * level / 100f
            paint.color = if (level <= 20f) Color.rgb(255, 69, 58) else Color.rgb(48, 209, 88)
            rect.set(left, pad, kotlin.math.max(right, left + 1.5f * d), h - pad)
            canvas.drawRoundRect(rect, 3f * d, 3f * d, paint)
        }
    }
}

/** Round grey close button with a drawn X; shrinks slightly while pressed. */
private class CloseButton(context: Context, private val dark: Boolean) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        animate().scaleX(if (pressed) 0.86f else 1f).scaleY(if (pressed) 0.86f else 1f).setDuration(110).start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        paint.style = Paint.Style.FILL
        paint.color = if (dark) Color.rgb(78, 78, 84) else Color.rgb(226, 226, 231)
        canvas.drawCircle(cx, cy, 14f * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 2f * d
        paint.color = if (dark) Color.rgb(215, 215, 220) else Color.rgb(90, 90, 98)
        val a = 4.6f * d
        canvas.drawLine(cx - a, cy - a, cx + a, cy + a, paint)
        canvas.drawLine(cx - a, cy + a, cx + a, cy - a, paint)
    }
}

/** A single soft diagonal-free light band that sweeps across the artwork once. */
private class ShineView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    var progress: Float = -1f
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (progress < 0f || progress > 1f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val band = w * 0.35f
        val x = -band + (w + band * 2f) * progress
        paint.shader = LinearGradient(
            x, 0f, x + band, 0f,
            intArrayOf(0x00FFFFFF, 0x2EFFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
    }
}

/** Thin line showing how long until the popup closes. */
private class TimerLine(context: Context, private val dark: Boolean) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    var value: Float = 1f
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        paint.color = if (dark) Color.argb(90, 255, 255, 255) else Color.argb(60, 0, 0, 0)
        canvas.drawRect(0f, 0f, width * value, height.toFloat(), paint)
    }
}
